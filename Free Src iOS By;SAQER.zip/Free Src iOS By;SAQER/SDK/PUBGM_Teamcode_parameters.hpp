#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function Teamcode.Teamcode_C.SetData
struct UTeamcode_C_SetData_Params
{
	struct FString code; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor)
	bool isShowClose; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

