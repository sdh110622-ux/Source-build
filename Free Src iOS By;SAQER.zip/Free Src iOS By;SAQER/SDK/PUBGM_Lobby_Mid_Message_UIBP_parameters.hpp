#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function Lobby_Mid_Message_UIBP.Lobby_Mid_Message_UIBP_C.PreConstruct
struct ULobby_Mid_Message_UIBP_C_PreConstruct_Params
{
	bool* IsDesignTime; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Lobby_Mid_Message_UIBP.Lobby_Mid_Message_UIBP_C.ExecuteUbergraph_Lobby_Mid_Message_UIBP
struct ULobby_Mid_Message_UIBP_C_ExecuteUbergraph_Lobby_Mid_Message_UIBP_Params
{
	int EntryPoint; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

