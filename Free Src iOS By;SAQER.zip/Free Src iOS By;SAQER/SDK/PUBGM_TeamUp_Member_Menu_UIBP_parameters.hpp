#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function TeamUp_Member_Menu_UIBP.TeamUp_Member_Menu_UIBP_C.Construct
struct UTeamUp_Member_Menu_UIBP_C_Construct_Params
{
};

// Function TeamUp_Member_Menu_UIBP.TeamUp_Member_Menu_UIBP_C.ExecuteUbergraph_TeamUp_Member_Menu_UIBP
struct UTeamUp_Member_Menu_UIBP_C_ExecuteUbergraph_TeamUp_Member_Menu_UIBP_Params
{
	int EntryPoint; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

