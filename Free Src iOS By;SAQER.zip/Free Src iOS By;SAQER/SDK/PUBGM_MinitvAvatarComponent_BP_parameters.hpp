#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function MinitvAvatarComponent_BP.MinitvAvatarComponent_BP_C.RayEquipItemById
struct UMinitvAvatarComponent_BP_C_RayEquipItemById_Params
{
	int ID; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

