#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function Engine.ActorComponent.ToggleActive
struct UActorComponent_ToggleActive_Params
{
};

// Function Engine.ActorComponent.SetTickGroup
struct UActorComponent_SetTickGroup_Params
{
	TEnumAsByte<enum ETickingGroup> NewTickGroup; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.SetTickableWhenPaused
struct UActorComponent_SetTickableWhenPaused_Params
{
	bool bTickableWhenPaused; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.SetIsReplicated
struct UActorComponent_SetIsReplicated_Params
{
	bool ShouldReplicate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.SetComponentTickInterval
struct UActorComponent_SetComponentTickInterval_Params
{
	float TickInterval; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.SetComponentTickEnabled
struct UActorComponent_SetComponentTickEnabled_Params
{
	bool bEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.SetAutoActivate
struct UActorComponent_SetAutoActivate_Params
{
	bool bNewAutoActivate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.SetActive
struct UActorComponent_SetActive_Params
{
	bool bNewActive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bReset; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.RemoveTickPrerequisiteComponent
struct UActorComponent_RemoveTickPrerequisiteComponent_Params
{
	class UActorComponent* PrerequisiteComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.ActorComponent.RemoveTickPrerequisiteActor
struct UActorComponent_RemoveTickPrerequisiteActor_Params
{
	class AActor* PrerequisiteActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.ReceiveTick
struct UActorComponent_ReceiveTick_Params
{
	float DeltaSeconds; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.ReceivePostReplayRecover
struct UActorComponent_ReceivePostReplayRecover_Params
{
};

// Function Engine.ActorComponent.ReceiveEndPlay
struct UActorComponent_ReceiveEndPlay_Params
{
	TEnumAsByte<enum EEndPlayReason> EndPlayReason; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.ReceiveBeginPlay
struct UActorComponent_ReceiveBeginPlay_Params
{
};

// Function Engine.ActorComponent.OnRep_Replicates
struct UActorComponent_OnRep_Replicates_Params
{
};

// Function Engine.ActorComponent.OnRep_IsActive
struct UActorComponent_OnRep_IsActive_Params
{
};

// Function Engine.ActorComponent.MarkNetDormancyForReplay
struct UActorComponent_MarkNetDormancyForReplay_Params
{
	bool bInDormancyForReplay; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bForceNetUpdate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.K2_DestroyComponent
struct UActorComponent_K2_DestroyComponent_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.IsComponentTickEnabled
struct UActorComponent_IsComponentTickEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ActorComponent.IsBeingDestroyed
struct UActorComponent_IsBeingDestroyed_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ActorComponent.IsActive
struct UActorComponent_IsActive_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ActorComponent.GetOwner
struct UActorComponent_GetOwner_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ActorComponent.GetComponentTickInterval
struct UActorComponent_GetComponentTickInterval_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ActorComponent.ForceNetUpdate
struct UActorComponent_ForceNetUpdate_Params
{
};

// Function Engine.ActorComponent.FlushNetDormancyOnceForReplay
struct UActorComponent_FlushNetDormancyOnceForReplay_Params
{
};

// Function Engine.ActorComponent.Deactivate
struct UActorComponent_Deactivate_Params
{
};

// Function Engine.ActorComponent.ComponentHasTag
struct UActorComponent_ComponentHasTag_Params
{
	struct FName Tag; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ActorComponent.AddTickPrerequisiteComponent
struct UActorComponent_AddTickPrerequisiteComponent_Params
{
	class UActorComponent* PrerequisiteComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.ActorComponent.AddTickPrerequisiteActor
struct UActorComponent_AddTickPrerequisiteActor_Params
{
	class AActor* PrerequisiteActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ActorComponent.Activate
struct UActorComponent_Activate_Params
{
	bool bReset; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.ToggleVisibility
struct USceneComponent_ToggleVisibility_Params
{
	bool bPropagateToChildren; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.SnapTo
struct USceneComponent_SnapTo_Params
{
	class USceneComponent* InParent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.SetWorldScale3D
struct USceneComponent_SetWorldScale3D_Params
{
	struct FVector NewScale; // (Parm, IsPlainOldData)
};

// Function Engine.SceneComponent.SetVisibility
struct USceneComponent_SetVisibility_Params
{
	bool bNewVisibility; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPropagateToChildren; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.SetSkipUpdateChildTransforms
struct USceneComponent_SetSkipUpdateChildTransforms_Params
{
	bool EnableSkipUpdateChildTransforms; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.SetSkipTransformUpdateWhenHidden
struct USceneComponent_SetSkipTransformUpdateWhenHidden_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.SetRelativeScale3D
struct USceneComponent_SetRelativeScale3D_Params
{
	struct FVector NewScale3D; // (Parm, IsPlainOldData)
};

// Function Engine.SceneComponent.SetHiddenInGame
struct USceneComponent_SetHiddenInGame_Params
{
	bool NewHidden; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPropagateToChildren; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.SetAbsolute
struct USceneComponent_SetAbsolute_Params
{
	bool bNewAbsoluteLocation; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bNewAbsoluteRotation; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bNewAbsoluteScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.ResetRelativeTransform
struct USceneComponent_ResetRelativeTransform_Params
{
};

// Function Engine.SceneComponent.OnRep_Visibility
struct USceneComponent_OnRep_Visibility_Params
{
	bool OldValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.OnRep_Transform
struct USceneComponent_OnRep_Transform_Params
{
};

// Function Engine.SceneComponent.OnRep_AttachSocketName
struct USceneComponent_OnRep_AttachSocketName_Params
{
};

// Function Engine.SceneComponent.OnRep_AttachParent
struct USceneComponent_OnRep_AttachParent_Params
{
};

// Function Engine.SceneComponent.OnRep_AttachChildren
struct USceneComponent_OnRep_AttachChildren_Params
{
};

// Function Engine.SceneComponent.K2_SetWorldTransform
struct USceneComponent_K2_SetWorldTransform_Params
{
	struct FTransform NewTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_SetWorldRotation
struct USceneComponent_K2_SetWorldRotation_Params
{
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_SetWorldLocationAndRotation
struct USceneComponent_K2_SetWorldLocationAndRotation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_SetWorldLocation
struct USceneComponent_K2_SetWorldLocation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_SetRelativeTransform
struct USceneComponent_K2_SetRelativeTransform_Params
{
	struct FTransform NewTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_SetRelativeRotation
struct USceneComponent_K2_SetRelativeRotation_Params
{
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_SetRelativeLocationAndRotation
struct USceneComponent_K2_SetRelativeLocationAndRotation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_SetRelativeLocation
struct USceneComponent_K2_SetRelativeLocation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_GetComponentToWorld
struct USceneComponent_K2_GetComponentToWorld_Params
{
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_GetComponentScale
struct USceneComponent_K2_GetComponentScale_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_GetComponentRotation
struct USceneComponent_K2_GetComponentRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_GetComponentLocation
struct USceneComponent_K2_GetComponentLocation_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_DetachFromComponent
struct USceneComponent_K2_DetachFromComponent_Params
{
	EDetachmentRule LocationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EDetachmentRule RotationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EDetachmentRule ScaleRule; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bCallModify; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AttachToComponent
struct USceneComponent_K2_AttachToComponent_Params
{
	class USceneComponent* Parent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName SocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule LocationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule RotationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule ScaleRule; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bWeldSimulatedBodies; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AttachTo
struct USceneComponent_K2_AttachTo_Params
{
	class USceneComponent* InParent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> AttachType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bWeldSimulatedBodies; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddWorldTransform
struct USceneComponent_K2_AddWorldTransform_Params
{
	struct FTransform DeltaTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddWorldRotation
struct USceneComponent_K2_AddWorldRotation_Params
{
	struct FRotator DeltaRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddWorldOffset
struct USceneComponent_K2_AddWorldOffset_Params
{
	struct FVector DeltaLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddRelativeRotation
struct USceneComponent_K2_AddRelativeRotation_Params
{
	struct FRotator DeltaRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddRelativeLocation
struct USceneComponent_K2_AddRelativeLocation_Params
{
	struct FVector DeltaLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddLocalTransform
struct USceneComponent_K2_AddLocalTransform_Params
{
	struct FTransform DeltaTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddLocalRotation
struct USceneComponent_K2_AddLocalRotation_Params
{
	struct FRotator DeltaRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.K2_AddLocalOffset
struct USceneComponent_K2_AddLocalOffset_Params
{
	struct FVector DeltaLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneComponent.IsVisible
struct USceneComponent_IsVisible_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.IsSimulatingPhysics
struct USceneComponent_IsSimulatingPhysics_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.IsAnySimulatingPhysics
struct USceneComponent_IsAnySimulatingPhysics_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetUpVector
struct USceneComponent_GetUpVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetSocketTransform
struct USceneComponent_GetSocketTransform_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ERelativeTransformSpace> TransformSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetSocketRotation
struct USceneComponent_GetSocketRotation_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetSocketQuaternion
struct USceneComponent_GetSocketQuaternion_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FQuat ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetSocketLocation
struct USceneComponent_GetSocketLocation_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetSkipTransformUpdateWhenHidden
struct USceneComponent_GetSkipTransformUpdateWhenHidden_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetRightVector
struct USceneComponent_GetRightVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetRelativeTransform
struct USceneComponent_GetRelativeTransform_Params
{
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetPhysicsVolume
struct USceneComponent_GetPhysicsVolume_Params
{
	class APhysicsVolume* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetParentComponents
struct USceneComponent_GetParentComponents_Params
{
	TArray<class USceneComponent*> Parents; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.SceneComponent.GetNumChildrenComponents
struct USceneComponent_GetNumChildrenComponents_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetForwardVector
struct USceneComponent_GetForwardVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetComponentVelocity
struct USceneComponent_GetComponentVelocity_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetComponentTransformViewTranslatedBP
struct USceneComponent_GetComponentTransformViewTranslatedBP_Params
{
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetComponentLocal
struct USceneComponent_GetComponentLocal_Params
{
	struct FTransform LocalTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetChildrenComponents
struct USceneComponent_GetChildrenComponents_Params
{
	bool bIncludeAllDescendants; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class USceneComponent*> Children; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.SceneComponent.GetChildComponent
struct USceneComponent_GetChildComponent_Params
{
	int ChildIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class USceneComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.SceneComponent.GetAttachSocketName
struct USceneComponent_GetAttachSocketName_Params
{
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.GetAttachParent
struct USceneComponent_GetAttachParent_Params
{
	class USceneComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.SceneComponent.GetAllSocketNames
struct USceneComponent_GetAllSocketNames_Params
{
	TArray<struct FName> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.SceneComponent.DoesSocketExist
struct USceneComponent_DoesSocketExist_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SceneComponent.DetachFromParent
struct USceneComponent_DetachFromParent_Params
{
	bool bMaintainWorldPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bCallModify; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.WasRecentlyRendered
struct UPrimitiveComponent_WasRecentlyRendered_Params
{
	float Tolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.WakeRigidBody
struct UPrimitiveComponent_WakeRigidBody_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.WakeAllRigidBodies
struct UPrimitiveComponent_WakeAllRigidBodies_Params
{
};

// Function Engine.PrimitiveComponent.SetWalkableSlopeOverride
struct UPrimitiveComponent_SetWalkableSlopeOverride_Params
{
	struct FWalkableSlopeOverride NewOverride; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetVisibleDyeingColor
struct UPrimitiveComponent_SetVisibleDyeingColor_Params
{
	struct FLinearColor InColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetUnderWater
struct UPrimitiveComponent_SetUnderWater_Params
{
	bool bNewUnderWater; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetTwoPassTranslucent
struct UPrimitiveComponent_SetTwoPassTranslucent_Params
{
	bool bNewTwoPassTranslucent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetTranslucentSortPriority
struct UPrimitiveComponent_SetTranslucentSortPriority_Params
{
	int NewTranslucentSortPriority; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetTranslucentSortGroupPriority
struct UPrimitiveComponent_SetTranslucentSortGroupPriority_Params
{
	int NewTranslucentSortGroupPriority; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetTranslucentDepthWriteInTwoPass
struct UPrimitiveComponent_SetTranslucentDepthWriteInTwoPass_Params
{
	bool bNewTranslucentDepthWriteInTwoPass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetTranslucentDepthWrite
struct UPrimitiveComponent_SetTranslucentDepthWrite_Params
{
	bool bNewTranslucentDepthWrite; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetSingleSampleShadowFromStationaryLights
struct UPrimitiveComponent_SetSingleSampleShadowFromStationaryLights_Params
{
	bool bNewSingleSampleShadowFromStationaryLights; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetSimulatePhysics
struct UPrimitiveComponent_SetSimulatePhysics_Params
{
	bool bSimulate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetRenderInMono
struct UPrimitiveComponent_SetRenderInMono_Params
{
	bool bValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetRenderInMainPass
struct UPrimitiveComponent_SetRenderInMainPass_Params
{
	bool bValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetRenderCustomDepth
struct UPrimitiveComponent_SetRenderCustomDepth_Params
{
	bool bValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetReceivesDecals
struct UPrimitiveComponent_SetReceivesDecals_Params
{
	bool bNewReceivesDecals; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysMaterialOverride
struct UPrimitiveComponent_SetPhysMaterialOverride_Params
{
	class UPhysicalMaterial* NewPhysMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysicsMaxAngularVelocityInRadians
struct UPrimitiveComponent_SetPhysicsMaxAngularVelocityInRadians_Params
{
	float NewMaxAngVel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysicsMaxAngularVelocityInDegrees
struct UPrimitiveComponent_SetPhysicsMaxAngularVelocityInDegrees_Params
{
	float NewMaxAngVel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysicsMaxAngularVelocity
struct UPrimitiveComponent_SetPhysicsMaxAngularVelocity_Params
{
	float NewMaxAngVel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysicsLinearVelocity
struct UPrimitiveComponent_SetPhysicsLinearVelocity_Params
{
	struct FVector NewVel; // (Parm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysicsAngularVelocityInRadians
struct UPrimitiveComponent_SetPhysicsAngularVelocityInRadians_Params
{
	struct FVector NewAngVel; // (Parm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysicsAngularVelocityInDegrees
struct UPrimitiveComponent_SetPhysicsAngularVelocityInDegrees_Params
{
	struct FVector NewAngVel; // (Parm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetPhysicsAngularVelocity
struct UPrimitiveComponent_SetPhysicsAngularVelocity_Params
{
	struct FVector NewAngVel; // (Parm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetOwnerNoSee
struct UPrimitiveComponent_SetOwnerNoSee_Params
{
	bool bNewOwnerNoSee; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetOverrideOccludedDyeingColorMaterial
struct UPrimitiveComponent_SetOverrideOccludedDyeingColorMaterial_Params
{
	class UMaterialInterface* InMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetOnlyOwnerSee
struct UPrimitiveComponent_SetOnlyOwnerSee_Params
{
	bool bNewOnlyOwnerSee; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetOccludedDyeingColor
struct UPrimitiveComponent_SetOccludedDyeingColor_Params
{
	struct FLinearColor InColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetNotifyRigidBodyCollision
struct UPrimitiveComponent_SetNotifyRigidBodyCollision_Params
{
	bool bNewNotifyRigidBodyCollision; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetMaterialByNameAsyncCallBack
struct UPrimitiveComponent_SetMaterialByNameAsyncCallBack_Params
{
	struct FName MaterialSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetMaterialByNameAsync
struct UPrimitiveComponent_SetMaterialByNameAsync_Params
{
	struct FName MaterialSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString MaterialPath; // (Parm, ZeroConstructor)
};

// Function Engine.PrimitiveComponent.SetMaterialByName
struct UPrimitiveComponent_SetMaterialByName_Params
{
	struct FName MaterialSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetMaterial
struct UPrimitiveComponent_SetMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetMassScale
struct UPrimitiveComponent_SetMassScale_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	float InMassScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetMassOverrideInKg
struct UPrimitiveComponent_SetMassOverrideInKg_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	float MassInKg; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bOverrideMass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetMaskFilter
struct UPrimitiveComponent_SetMaskFilter_Params
{
	int InMaskFilter; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetLODDefault
struct UPrimitiveComponent_SetLODDefault_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* LODMat; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetLockedAxis
struct UPrimitiveComponent_SetLockedAxis_Params
{
	TEnumAsByte<enum EDOFMode> LockedAxis; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetLinearDamping
struct UPrimitiveComponent_SetLinearDamping_Params
{
	float InDamping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetLastRenderInOpaque
struct UPrimitiveComponent_SetLastRenderInOpaque_Params
{
	bool bNewLastRenderInOpaque; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetIdeaOverrideOutlineAndOcclusion
struct UPrimitiveComponent_SetIdeaOverrideOutlineAndOcclusion_Params
{
	bool bOutlineAndOcclusion; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetIdeaOutlineUseNormalInVertexColor
struct UPrimitiveComponent_SetIdeaOutlineUseNormalInVertexColor_Params
{
	bool bNewUseNormalInVertexColor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetIdeaOutlineOcclusionHighlight
struct UPrimitiveComponent_SetIdeaOutlineOcclusionHighlight_Params
{
	bool bOcclusionHighlight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetIdeaOutlineOcclusionColor
struct UPrimitiveComponent_SetIdeaOutlineOcclusionColor_Params
{
	struct FLinearColor InOcclusionColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetIdeaOutlineNew
struct UPrimitiveComponent_SetIdeaOutlineNew_Params
{
	bool bNew; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetHighlightCanBeOccluded
struct UPrimitiveComponent_SetHighlightCanBeOccluded_Params
{
	bool bInCanBeOccluded; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetEnableGravity
struct UPrimitiveComponent_SetEnableGravity_Params
{
	bool bGravityEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetDyeingColorMinMaxDistance
struct UPrimitiveComponent_SetDyeingColorMinMaxDistance_Params
{
	float InMinDistance; // (Parm, ZeroConstructor, IsPlainOldData)
	float InMaxDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetDyeingColorFadeDistance
struct UPrimitiveComponent_SetDyeingColorFadeDistance_Params
{
	float InFadeDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetDrawIdeaOutline
struct UPrimitiveComponent_SetDrawIdeaOutline_Params
{
	bool bNewDrawOutline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetDrawHighlight
struct UPrimitiveComponent_SetDrawHighlight_Params
{
	bool bNewDrawHighlight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetDrawDyeingMode
struct UPrimitiveComponent_SetDrawDyeingMode_Params
{
	EDrawDyeingMode InDrawDyeingMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetDrawDyeing
struct UPrimitiveComponent_SetDrawDyeing_Params
{
	bool bNewDrawOutline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCustomDepthStencilWriteMask
struct UPrimitiveComponent_SetCustomDepthStencilWriteMask_Params
{
	ERendererStencilMask WriteMaskBit; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCustomDepthStencilValue
struct UPrimitiveComponent_SetCustomDepthStencilValue_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCullDistance
struct UPrimitiveComponent_SetCullDistance_Params
{
	float NewCullDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetConstraintMode
struct UPrimitiveComponent_SetConstraintMode_Params
{
	TEnumAsByte<enum EDOFMode> ConstraintMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCollisionResponseToChannel
struct UPrimitiveComponent_SetCollisionResponseToChannel_Params
{
	TEnumAsByte<enum ECollisionChannel> Channel; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionResponse> NewResponse; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCollisionResponseToAllChannels
struct UPrimitiveComponent_SetCollisionResponseToAllChannels_Params
{
	TEnumAsByte<enum ECollisionResponse> NewResponse; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCollisionProfileName
struct UPrimitiveComponent_SetCollisionProfileName_Params
{
	struct FName InCollisionProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCollisionObjectType
struct UPrimitiveComponent_SetCollisionObjectType_Params
{
	TEnumAsByte<enum ECollisionChannel> Channel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCollisionEnabled
struct UPrimitiveComponent_SetCollisionEnabled_Params
{
	TEnumAsByte<enum ECollisionEnabled> NewType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCenterOfMass
struct UPrimitiveComponent_SetCenterOfMass_Params
{
	struct FVector CenterOfMassOffset; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCastShadow
struct UPrimitiveComponent_SetCastShadow_Params
{
	bool NewCastShadow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetCastPhotonShadow
struct UPrimitiveComponent_SetCastPhotonShadow_Params
{
	bool bNewCastPhotonShadow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetBoundsScale
struct UPrimitiveComponent_SetBoundsScale_Params
{
	float NewBoundsScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAngularDamping
struct UPrimitiveComponent_SetAngularDamping_Params
{
	float InDamping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAllPhysicsLinearVelocity
struct UPrimitiveComponent_SetAllPhysicsLinearVelocity_Params
{
	struct FVector NewVel; // (Parm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAllPhysicsAngularVelocityInRadians
struct UPrimitiveComponent_SetAllPhysicsAngularVelocityInRadians_Params
{
	struct FVector NewAngVel; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAllPhysicsAngularVelocityInDegrees
struct UPrimitiveComponent_SetAllPhysicsAngularVelocityInDegrees_Params
{
	struct FVector NewAngVel; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAllPhysicsAngularVelocity
struct UPrimitiveComponent_SetAllPhysicsAngularVelocity_Params
{
	struct FVector NewAngVel; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bAddToCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAllowCullDistanceVolume
struct UPrimitiveComponent_SetAllowCullDistanceVolume_Params
{
	bool bNewAllowCullDistanceVolume; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAllMassScale
struct UPrimitiveComponent_SetAllMassScale_Params
{
	float InMassScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAfterSeparateTransparencyFlag
struct UPrimitiveComponent_SetAfterSeparateTransparencyFlag_Params
{
	bool flag; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.SetAffectAO
struct UPrimitiveComponent_SetAffectAO_Params
{
	bool bNewAffectAO; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.ScaleByMomentOfInertia
struct UPrimitiveComponent_ScaleByMomentOfInertia_Params
{
	struct FVector InputVector; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.PutRigidBodyToSleep
struct UPrimitiveComponent_PutRigidBodyToSleep_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.OverrideIdeaOutlineThickness
struct UPrimitiveComponent_OverrideIdeaOutlineThickness_Params
{
	bool bOverride; // (Parm, ZeroConstructor, IsPlainOldData)
	float InThickness; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.OverrideIdeaOutlineColor
struct UPrimitiveComponent_OverrideIdeaOutlineColor_Params
{
	bool bOverride; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor InOutlineColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.OverrideHighlightColor
struct UPrimitiveComponent_OverrideHighlightColor_Params
{
	bool bOverride; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor InHighlightColor; // (Parm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.ModifyCollision
struct UPrimitiveComponent_ModifyCollision_Params
{
	TEnumAsByte<enum ECollisionEnabled> NewType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.K2_SetMoveIgnoreMask
struct UPrimitiveComponent_K2_SetMoveIgnoreMask_Params
{
	int InIgnoreMask; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.K2_LineTraceComponent
struct UPrimitiveComponent_K2_LineTraceComponent_Params
{
	struct FVector TraceStart; // (Parm, IsPlainOldData)
	struct FVector TraceEnd; // (Parm, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bShowTrace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector HitLocation; // (Parm, OutParm, IsPlainOldData)
	struct FVector HitNormal; // (Parm, OutParm, IsPlainOldData)
	struct FName BoneName; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.K2_IsTriggerCollisionEnabled
struct UPrimitiveComponent_K2_IsTriggerCollisionEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.K2_IsQueryCollisionEnabled
struct UPrimitiveComponent_K2_IsQueryCollisionEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.K2_IsPhysicsCollisionEnabled
struct UPrimitiveComponent_K2_IsPhysicsCollisionEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.K2_IsCollisionEnabled
struct UPrimitiveComponent_K2_IsCollisionEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.K2_GetMoveIgnoreMask
struct UPrimitiveComponent_K2_GetMoveIgnoreMask_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.IsOverlappingComponent
struct UPrimitiveComponent_IsOverlappingComponent_Params
{
	class UPrimitiveComponent* OtherComp; // (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.IsOverlappingActor
struct UPrimitiveComponent_IsOverlappingActor_Params
{
	class AActor* Other; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.IsGravityEnabled
struct UPrimitiveComponent_IsGravityEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.IsAnyRigidBodyAwake
struct UPrimitiveComponent_IsAnyRigidBodyAwake_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.IgnoreComponentWhenMoving
struct UPrimitiveComponent_IgnoreComponentWhenMoving_Params
{
	class UPrimitiveComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool bShouldIgnore; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.IgnoreActorWhenMoving
struct UPrimitiveComponent_IgnoreActorWhenMoving_Params
{
	class AActor* Actor; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bShouldIgnore; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetWalkableSlopeOverride
struct UPrimitiveComponent_GetWalkableSlopeOverride_Params
{
	struct FWalkableSlopeOverride ReturnValue; // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetPhysicsLinearVelocityAtPoint
struct UPrimitiveComponent_GetPhysicsLinearVelocityAtPoint_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetPhysicsLinearVelocity
struct UPrimitiveComponent_GetPhysicsLinearVelocity_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetPhysicsAngularVelocityInRadians
struct UPrimitiveComponent_GetPhysicsAngularVelocityInRadians_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetPhysicsAngularVelocityInDegrees
struct UPrimitiveComponent_GetPhysicsAngularVelocityInDegrees_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetPhysicsAngularVelocity
struct UPrimitiveComponent_GetPhysicsAngularVelocity_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetOverlappingComponents
struct UPrimitiveComponent_GetOverlappingComponents_Params
{
	TArray<class UPrimitiveComponent*> InOverlappingComponents; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.PrimitiveComponent.GetOverlappingActors
struct UPrimitiveComponent_GetOverlappingActors_Params
{
	TArray<class AActor*> OverlappingActors; // (Parm, OutParm, ZeroConstructor)
	class UClass* ClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetNumMaterials
struct UPrimitiveComponent_GetNumMaterials_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetMaterialFromCollisionFaceIndex
struct UPrimitiveComponent_GetMaterialFromCollisionFaceIndex_Params
{
	int FaceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int SectionIndex; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetMaterialAsync
struct UPrimitiveComponent_GetMaterialAsync_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate MaterialCallback; // (Parm, ZeroConstructor)
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetMaterial
struct UPrimitiveComponent_GetMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetMassScale
struct UPrimitiveComponent_GetMassScale_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetMass
struct UPrimitiveComponent_GetMass_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetMaskFilter
struct UPrimitiveComponent_GetMaskFilter_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetLocalCenterOfMass
struct UPrimitiveComponent_GetLocalCenterOfMass_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetLinearDamping
struct UPrimitiveComponent_GetLinearDamping_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetInterpolatedPhysicsDisplayTransform
struct UPrimitiveComponent_GetInterpolatedPhysicsDisplayTransform_Params
{
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetInertiaTensor
struct UPrimitiveComponent_GetInertiaTensor_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetCollisionResponseToChannel
struct UPrimitiveComponent_GetCollisionResponseToChannel_Params
{
	TEnumAsByte<enum ECollisionChannel> Channel; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionResponse> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetCollisionProfileName
struct UPrimitiveComponent_GetCollisionProfileName_Params
{
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetCollisionObjectType
struct UPrimitiveComponent_GetCollisionObjectType_Params
{
	TEnumAsByte<enum ECollisionChannel> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetCollisionEnabled
struct UPrimitiveComponent_GetCollisionEnabled_Params
{
	TEnumAsByte<enum ECollisionEnabled> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetClosestPointOnCollision
struct UPrimitiveComponent_GetClosestPointOnCollision_Params
{
	struct FVector Point; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector OutPointOnBody; // (Parm, OutParm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetCenterOfMass
struct UPrimitiveComponent_GetCenterOfMass_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.GetAngularDamping
struct UPrimitiveComponent_GetAngularDamping_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.ForceRecoverMaterial
struct UPrimitiveComponent_ForceRecoverMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.ForceClearMaterial
struct UPrimitiveComponent_ForceClearMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.CreateDynamicMaterialInstanceAsync
struct UPrimitiveComponent_CreateDynamicMaterialInstanceAsync_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate MaterialInstCallback; // (Parm, ZeroConstructor)
	class UMaterialInterface* SourceMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.CreateDynamicMaterialInstance
struct UPrimitiveComponent_CreateDynamicMaterialInstance_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* SourceMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.CreateAndSetMaterialInstanceDynamicFromMaterialAsync
struct UPrimitiveComponent_CreateAndSetMaterialInstanceDynamicFromMaterialAsync_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Parent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate MaterialInstCallback; // (Parm, ZeroConstructor)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.CreateAndSetMaterialInstanceDynamicFromMaterial
struct UPrimitiveComponent_CreateAndSetMaterialInstanceDynamicFromMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Parent; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.CreateAndSetMaterialInstanceDynamicAsync
struct UPrimitiveComponent_CreateAndSetMaterialInstanceDynamicAsync_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate MaterialInstCallback; // (Parm, ZeroConstructor)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.CreateAndSetMaterialInstanceDynamic
struct UPrimitiveComponent_CreateAndSetMaterialInstanceDynamic_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.CopyArrayOfMoveIgnoreComponents
struct UPrimitiveComponent_CopyArrayOfMoveIgnoreComponents_Params
{
	TArray<class UPrimitiveComponent*> ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.PrimitiveComponent.CopyArrayOfMoveIgnoreActors
struct UPrimitiveComponent_CopyArrayOfMoveIgnoreActors_Params
{
	TArray<class AActor*> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// DelegateFunction Engine.PrimitiveComponent.ComponentTriggeredBySignature__DelegateSignature
struct UPrimitiveComponent_ComponentTriggeredBySignature__DelegateSignature_Params
{
	class AActor* OtherActor; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* OtherComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FTriggerEvent TriggerEvent; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// DelegateFunction Engine.PrimitiveComponent.ComponentPhysicsContactSignature__DelegateSignature
struct UPrimitiveComponent_ComponentPhysicsContactSignature__DelegateSignature_Params
{
	class AActor* OtherActor; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* OtherComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	EPhysicsContactState ContactState; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NormalImpulse; // (Parm, IsPlainOldData)
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// DelegateFunction Engine.PrimitiveComponent.ComponentInteractWithTriggerSignature__DelegateSignature
struct UPrimitiveComponent_ComponentInteractWithTriggerSignature__DelegateSignature_Params
{
	class AActor* TriggerActor; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* TriggerComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FTriggerEvent TriggerEvent; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.PrimitiveComponent.ClearMoveIgnoreComponents
struct UPrimitiveComponent_ClearMoveIgnoreComponents_Params
{
};

// Function Engine.PrimitiveComponent.ClearMoveIgnoreActors
struct UPrimitiveComponent_ClearMoveIgnoreActors_Params
{
};

// Function Engine.PrimitiveComponent.CanCharacterStepUp
struct UPrimitiveComponent_CanCharacterStepUp_Params
{
	class APawn* Pawn; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddTorqueInRadians
struct UPrimitiveComponent_AddTorqueInRadians_Params
{
	struct FVector Torque; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAccelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddTorqueInDegrees
struct UPrimitiveComponent_AddTorqueInDegrees_Params
{
	struct FVector Torque; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAccelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddTorque
struct UPrimitiveComponent_AddTorque_Params
{
	struct FVector Torque; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAccelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddRadialImpulse
struct UPrimitiveComponent_AddRadialImpulse_Params
{
	struct FVector Origin; // (Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float Strength; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ERadialImpulseFalloff> Falloff; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bVelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddRadialForce
struct UPrimitiveComponent_AddRadialForce_Params
{
	struct FVector Origin; // (Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float Strength; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ERadialImpulseFalloff> Falloff; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAccelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddImpulseAtLocation
struct UPrimitiveComponent_AddImpulseAtLocation_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddImpulse
struct UPrimitiveComponent_AddImpulse_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bVelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddForceAtLocationLocal
struct UPrimitiveComponent_AddForceAtLocationLocal_Params
{
	struct FVector Force; // (Parm, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddForceAtLocation
struct UPrimitiveComponent_AddForceAtLocation_Params
{
	struct FVector Force; // (Parm, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddForce
struct UPrimitiveComponent_AddForce_Params
{
	struct FVector Force; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAccelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddAngularImpulseInRadians
struct UPrimitiveComponent_AddAngularImpulseInRadians_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bVelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddAngularImpulseInDegrees
struct UPrimitiveComponent_AddAngularImpulseInDegrees_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bVelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PrimitiveComponent.AddAngularImpulse
struct UPrimitiveComponent_AddAngularImpulse_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bVelChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetVectorParameterValueOnMaterials
struct UMeshComponent_SetVectorParameterValueOnMaterials_Params
{
	struct FName ParameterName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ParameterValue; // (ConstParm, Parm, IsPlainOldData)
};

// Function Engine.MeshComponent.SetUseOverlayMaterials
struct UMeshComponent_SetUseOverlayMaterials_Params
{
	bool bNewUseOverlayMaterials; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetUseIndexedOverlayMaterials
struct UMeshComponent_SetUseIndexedOverlayMaterials_Params
{
	bool bNewUseIndexedOverlayMaterials; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetScalarParameterValueOnMaterials
struct UMeshComponent_SetScalarParameterValueOnMaterials_Params
{
	struct FName ParameterName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ParameterValue; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetRenderInCustomPass
struct UMeshComponent_SetRenderInCustomPass_Params
{
	bool InRenderInCustomPass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetOverlayMaterialMaxDrawDistance
struct UMeshComponent_SetOverlayMaterialMaxDrawDistance_Params
{
	float InMaxDrawDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetOverlayMaterial
struct UMeshComponent_SetOverlayMaterial_Params
{
	class UMaterialInterface* NewOverlayMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetLayerVisibilityValue
struct UMeshComponent_SetLayerVisibilityValue_Params
{
	TEnumAsByte<enum EMeshVisibleLayer> Layer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool Visible; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPropagateToChildren; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetLayerVisibilityEnable
struct UMeshComponent_SetLayerVisibilityEnable_Params
{
	bool Enable; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPropagateToChildren; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetLayerCastShadowValue
struct UMeshComponent_SetLayerCastShadowValue_Params
{
	TEnumAsByte<enum EMeshCastShadowLayer> Layer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool NewCastShadow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetLayerCastShadowEnable
struct UMeshComponent_SetLayerCastShadowEnable_Params
{
	bool Enable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetIsHeadMesh
struct UMeshComponent_SetIsHeadMesh_Params
{
	bool InIsHeadMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetIndexedOverlayMaterial
struct UMeshComponent_SetIndexedOverlayMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetForceSyncCreatePSO
struct UMeshComponent_SetForceSyncCreatePSO_Params
{
	bool InForceSyncCreatePSO; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetFeatureMaterial
struct UMeshComponent_SetFeatureMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetDrawStyle
struct UMeshComponent_SetDrawStyle_Params
{
	TEnumAsByte<enum EDrawStyleMode> InDrawStyle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.SetCastShadow
struct UMeshComponent_SetCastShadow_Params
{
	bool NewCastShadow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.PrestreamTextures
struct UMeshComponent_PrestreamTextures_Params
{
	float Seconds; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPrioritizeCharacterTextures; // (Parm, ZeroConstructor, IsPlainOldData)
	int CinematicTextureGroups; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.IsMaterialSlotNameValid
struct UMeshComponent_IsMaterialSlotNameValid_Params
{
	struct FName MaterialSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetUseOverlayMaterials
struct UMeshComponent_GetUseOverlayMaterials_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetUseIndexedOverlayMaterials
struct UMeshComponent_GetUseIndexedOverlayMaterials_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetRenderInCustomPass
struct UMeshComponent_GetRenderInCustomPass_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetOverlayMaterial
struct UMeshComponent_GetOverlayMaterial_Params
{
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetMaterialSlotNames
struct UMeshComponent_GetMaterialSlotNames_Params
{
	TArray<struct FName> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.MeshComponent.GetMaterials
struct UMeshComponent_GetMaterials_Params
{
	TArray<class UMaterialInterface*> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.MeshComponent.GetMaterialIndex
struct UMeshComponent_GetMaterialIndex_Params
{
	struct FName MaterialSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetLayerVisibilityValue
struct UMeshComponent_GetLayerVisibilityValue_Params
{
	TEnumAsByte<enum EMeshVisibleLayer> Layer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetLayerCastShadowValue
struct UMeshComponent_GetLayerCastShadowValue_Params
{
	TEnumAsByte<enum EMeshCastShadowLayer> Layer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetIsHideBySmartBear
struct UMeshComponent_GetIsHideBySmartBear_Params
{
	TEnumAsByte<enum EMeshVisibleLayer> Layer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetIsHeadMesh
struct UMeshComponent_GetIsHeadMesh_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetIndexedOverlayMaterials
struct UMeshComponent_GetIndexedOverlayMaterials_Params
{
	TArray<class UMaterialInterface*> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.MeshComponent.GetForceSyncCreatePSO
struct UMeshComponent_GetForceSyncCreatePSO_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.GetDrawStyle
struct UMeshComponent_GetDrawStyle_Params
{
	TEnumAsByte<enum EDrawStyleMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MeshComponent.EnableMeshClipPlane
struct UMeshComponent_EnableMeshClipPlane_Params
{
	struct FPlane ClipPlane; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int PlaneIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.EnableMeshClipArc
struct UMeshComponent_EnableMeshClipArc_Params
{
	struct FPlane ClipPlane; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector4 ClipSphere; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.MeshComponent.EnableMeshClip4Planes
struct UMeshComponent_EnableMeshClip4Planes_Params
{
	TArray<struct FPlane> ClipPlanes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bBox; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.DisableMeshClipPlane
struct UMeshComponent_DisableMeshClipPlane_Params
{
	int PlaneIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.DisableMeshClipArc
struct UMeshComponent_DisableMeshClipArc_Params
{
};

// Function Engine.MeshComponent.DisableMeshClip4Planes
struct UMeshComponent_DisableMeshClip4Planes_Params
{
};

// Function Engine.MeshComponent.ClearFeatureMaterial
struct UMeshComponent_ClearFeatureMaterial_Params
{
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshComponent.ClearAllFeatureMaterial
struct UMeshComponent_ClearAllFeatureMaterial_Params
{
};

// Function Engine.SkinnedMeshComponent.UnloadSkinWeightProfile
struct USkinnedMeshComponent_UnloadSkinWeightProfile_Params
{
	struct FName InProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.UnHideBoneByName
struct USkinnedMeshComponent_UnHideBoneByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.TransformToBoneSpace
struct USkinnedMeshComponent_TransformToBoneSpace_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InPosition; // (Parm, IsPlainOldData)
	struct FRotator InRotation; // (Parm, IsPlainOldData)
	struct FVector OutPosition; // (Parm, OutParm, IsPlainOldData)
	struct FRotator OutRotation; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.TransformFromBoneSpace
struct USkinnedMeshComponent_TransformFromBoneSpace_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InPosition; // (Parm, IsPlainOldData)
	struct FRotator InRotation; // (Parm, IsPlainOldData)
	struct FVector OutPosition; // (Parm, OutParm, IsPlainOldData)
	struct FRotator OutRotation; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetVertexColorOverride_LinearColor
struct USkinnedMeshComponent_SetVertexColorOverride_LinearColor_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FLinearColor> VertexColors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.SkinnedMeshComponent.SetSkinWeightProfile
struct USkinnedMeshComponent_SetSkinWeightProfile_Params
{
	struct FName InProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetSkinWeightOverride
struct USkinnedMeshComponent_SetSkinWeightOverride_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FSkelMeshSkinWeightInfo> SkinWeights; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.SkinnedMeshComponent.SetSkeletalMesh
struct USkinnedMeshComponent_SetSkeletalMesh_Params
{
	class USkeletalMesh* NewMesh; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bReinitPose; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetRenderInCustomPass
struct USkinnedMeshComponent_SetRenderInCustomPass_Params
{
	bool InRenderInCustomPass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetPhysicsAsset
struct USkinnedMeshComponent_SetPhysicsAsset_Params
{
	class UPhysicsAsset* NewPhysicsAsset; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bForceReinit; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetMinLOD
struct USkinnedMeshComponent_SetMinLOD_Params
{
	int InNewMinLOD; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetMasterPoseComponent
struct USkinnedMeshComponent_SetMasterPoseComponent_Params
{
	class USkinnedMeshComponent* NewMasterBoneComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetIsHeadMesh
struct USkinnedMeshComponent_SetIsHeadMesh_Params
{
	bool InIsHeadMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetGlobalUROExcludeFlags
struct USkinnedMeshComponent_SetGlobalUROExcludeFlags_Params
{
	EGlobalUROExcludeFlags Flags; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetForceSyncCreatePSO
struct USkinnedMeshComponent_SetForceSyncCreatePSO_Params
{
	bool InForceSyncCreatePSO; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetForcedLOD
struct USkinnedMeshComponent_SetForcedLOD_Params
{
	int InNewForcedLOD; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetDrawStyle
struct USkinnedMeshComponent_SetDrawStyle_Params
{
	TEnumAsByte<enum EDrawStyleMode> InDrawStyle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetCastCapsuleIndirectShadow
struct USkinnedMeshComponent_SetCastCapsuleIndirectShadow_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetCastCapsuleDirectShadow
struct USkinnedMeshComponent_SetCastCapsuleDirectShadow_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.SetCapsuleIndirectShadowMinVisibility
struct USkinnedMeshComponent_SetCapsuleIndirectShadowMinVisibility_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.ResetAnimUROParams
struct USkinnedMeshComponent_ResetAnimUROParams_Params
{
	TArray<float> DistanceFactors; // (Parm, ZeroConstructor)
	int MaxEvalRateForInterpolation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.IsUsingSkinWeightProfile
struct USkinnedMeshComponent_IsUsingSkinWeightProfile_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.IsBoneHiddenByName
struct USkinnedMeshComponent_IsBoneHiddenByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.HideBoneByName
struct USkinnedMeshComponent_HideBoneByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EPhysBodyOp> PhysBodyOption; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetSocketBoneName
struct USkinnedMeshComponent_GetSocketBoneName_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetRenderInCustomPass
struct USkinnedMeshComponent_GetRenderInCustomPass_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetPredictedLODLevel
struct USkinnedMeshComponent_GetPredictedLODLevel_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetParentBone
struct USkinnedMeshComponent_GetParentBone_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetNumLODs
struct USkinnedMeshComponent_GetNumLODs_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetNumBones
struct USkinnedMeshComponent_GetNumBones_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetIsHeadMesh
struct USkinnedMeshComponent_GetIsHeadMesh_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetGlobalUROExcludeFlags
struct USkinnedMeshComponent_GetGlobalUROExcludeFlags_Params
{
	EGlobalUROExcludeFlags ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetForceSyncCreatePSO
struct USkinnedMeshComponent_GetForceSyncCreatePSO_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetDrawStyle
struct USkinnedMeshComponent_GetDrawStyle_Params
{
	TEnumAsByte<enum EDrawStyleMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetCurrentSkinWeightProfileName
struct USkinnedMeshComponent_GetCurrentSkinWeightProfileName_Params
{
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetBoneName
struct USkinnedMeshComponent_GetBoneName_Params
{
	int BoneIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.GetBoneIndex
struct USkinnedMeshComponent_GetBoneIndex_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.FindClosestBone_K2
struct USkinnedMeshComponent_FindClosestBone_K2_Params
{
	struct FVector TestLocation; // (Parm, IsPlainOldData)
	struct FVector BoneLocation; // (Parm, OutParm, IsPlainOldData)
	float IgnoreScale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bRequirePhysicsAsset; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.EnableMeshClipPlane
struct USkinnedMeshComponent_EnableMeshClipPlane_Params
{
	struct FPlane ClipPlane; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int PlaneIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.EnableMeshClipArc
struct USkinnedMeshComponent_EnableMeshClipArc_Params
{
	struct FPlane ClipPlane; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector4 ClipSphere; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.EnableMeshClip4Planes
struct USkinnedMeshComponent_EnableMeshClip4Planes_Params
{
	TArray<struct FPlane> ClipPlanes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bBox; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.DisableMeshClipPlane
struct USkinnedMeshComponent_DisableMeshClipPlane_Params
{
	int PlaneIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.DisableMeshClipArc
struct USkinnedMeshComponent_DisableMeshClipArc_Params
{
};

// Function Engine.SkinnedMeshComponent.DisableMeshClip4Planes
struct USkinnedMeshComponent_DisableMeshClip4Planes_Params
{
};

// Function Engine.SkinnedMeshComponent.ClearVertexColorOverride
struct USkinnedMeshComponent_ClearVertexColorOverride_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.ClearSkinWeightProfile
struct USkinnedMeshComponent_ClearSkinWeightProfile_Params
{
};

// Function Engine.SkinnedMeshComponent.ClearSkinWeightOverride
struct USkinnedMeshComponent_ClearSkinWeightOverride_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkinnedMeshComponent.BoneIsChildOf
struct USkinnedMeshComponent_BoneIsChildOf_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ParentBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.UnbindClothFromMasterPoseComponent
struct USkeletalMeshComponent_UnbindClothFromMasterPoseComponent_Params
{
	bool bRestoreSimulationSpace; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SuspendClothingSimulation
struct USkeletalMeshComponent_SuspendClothingSimulation_Params
{
};

// Function Engine.SkeletalMeshComponent.Stop
struct USkeletalMeshComponent_Stop_Params
{
};

// Function Engine.SkeletalMeshComponent.StartClothSimulationWithDelay
struct USkeletalMeshComponent_StartClothSimulationWithDelay_Params
{
	int DelayFrames; // (Parm, ZeroConstructor, IsPlainOldData)
	int ResumeBlendFrames; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SnapshotPose
struct USkeletalMeshComponent_SnapshotPose_Params
{
	struct FPoseSnapshot Snapshot; // (Parm, OutParm, ReferenceParm)
};

// Function Engine.SkeletalMeshComponent.SetUpdateAnimationInEditor
struct USkeletalMeshComponent_SetUpdateAnimationInEditor_Params
{
	bool NewUpdateState; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetTickMode
struct USkeletalMeshComponent_SetTickMode_Params
{
	ESkeletaTickMode InTickMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetTeleportRotationThreshold
struct USkeletalMeshComponent_SetTeleportRotationThreshold_Params
{
	float Threshold; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetTeleportDistanceThreshold
struct USkeletalMeshComponent_SetTeleportDistanceThreshold_Params
{
	float Threshold; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetSubInstance
struct USkeletalMeshComponent_SetSubInstance_Params
{
	struct FName InTag; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class UClass* TargetClass; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetPosition
struct USkeletalMeshComponent_SetPosition_Params
{
	float InPos; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFireNotifies; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetPlayRate
struct USkeletalMeshComponent_SetPlayRate_Params
{
	float Rate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetPhysicsBlendWeight
struct USkeletalMeshComponent_SetPhysicsBlendWeight_Params
{
	float PhysicsBlendWeight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetNotifyRigidBodyCollisionBelow
struct USkeletalMeshComponent_SetNotifyRigidBodyCollisionBelow_Params
{
	bool bNewNotifyRigidBodyCollision; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetMorphTarget
struct USkeletalMeshComponent_SetMorphTarget_Params
{
	struct FName MorphTargetName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bRemoveZeroWeight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetEnablePhysicsBlending
struct USkeletalMeshComponent_SetEnablePhysicsBlending_Params
{
	bool bNewBlendPhysics; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetEnableGravityOnAllBodiesBelow
struct USkeletalMeshComponent_SetEnableGravityOnAllBodiesBelow_Params
{
	bool bEnableGravity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetEnableBodyGravity
struct USkeletalMeshComponent_SetEnableBodyGravity_Params
{
	bool bEnableGravity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetDisableAnimCurves
struct USkeletalMeshComponent_SetDisableAnimCurves_Params
{
	bool bInDisableAnimCurves; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetConstraintProfileForAll
struct USkeletalMeshComponent_SetConstraintProfileForAll_Params
{
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDefaultIfNotFound; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetConstraintProfile
struct USkeletalMeshComponent_SetConstraintProfile_Params
{
	struct FName JointName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDefaultIfNotFound; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothSkinningMode
struct USkeletalMeshComponent_SetClothSkinningMode_Params
{
	int ClothAssetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	EClothSkinningMode InMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothResumeBlendFrames
struct USkeletalMeshComponent_SetClothResumeBlendFrames_Params
{
	int Frames; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothMaxDistanceScale
struct USkeletalMeshComponent_SetClothMaxDistanceScale_Params
{
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothAnimDriveStiffnessRange
struct USkeletalMeshComponent_SetClothAnimDriveStiffnessRange_Params
{
	float InLow; // (Parm, ZeroConstructor, IsPlainOldData)
	float InHigh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothAnimDriveMultiplier
struct USkeletalMeshComponent_SetClothAnimDriveMultiplier_Params
{
	float InMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothAnimDriveMaxRelativeVelocity
struct USkeletalMeshComponent_SetClothAnimDriveMaxRelativeVelocity_Params
{
	float InVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothAnimDriveEnabled
struct USkeletalMeshComponent_SetClothAnimDriveEnabled_Params
{
	bool bInEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetClothAnimDriveDampingRange
struct USkeletalMeshComponent_SetClothAnimDriveDampingRange_Params
{
	float InLow; // (Parm, ZeroConstructor, IsPlainOldData)
	float InHigh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetBodyNotifyRigidBodyCollision
struct USkeletalMeshComponent_SetBodyNotifyRigidBodyCollision_Params
{
	bool bNewNotifyRigidBodyCollision; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAnimInstanceClass
struct USkeletalMeshComponent_SetAnimInstanceClass_Params
{
	class UClass* NewClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAnimGroupRole
struct USkeletalMeshComponent_SetAnimGroupRole_Params
{
	ESkeletalMeshGroupRole NewRole; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAnimationMode
struct USkeletalMeshComponent_SetAnimationMode_Params
{
	TEnumAsByte<enum EAnimationMode> InAnimationMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAnimation
struct USkeletalMeshComponent_SetAnimation_Params
{
	class UAnimationAsset* NewAnimToPlay; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAngularLimits
struct USkeletalMeshComponent_SetAngularLimits_Params
{
	struct FName InBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Swing1LimitAngle; // (Parm, ZeroConstructor, IsPlainOldData)
	float TwistLimitAngle; // (Parm, ZeroConstructor, IsPlainOldData)
	float Swing2LimitAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllowedAnimCurvesEvaluation
struct USkeletalMeshComponent_SetAllowedAnimCurvesEvaluation_Params
{
	TArray<struct FName> List; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bAllow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllowAnimCurveEvaluation
struct USkeletalMeshComponent_SetAllowAnimCurveEvaluation_Params
{
	bool bInAllow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllMotorsAngularVelocityDrive
struct USkeletalMeshComponent_SetAllMotorsAngularVelocityDrive_Params
{
	bool bEnableSwingDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableTwistDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSkipCustomPhysicsType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllMotorsAngularPositionDrive
struct USkeletalMeshComponent_SetAllMotorsAngularPositionDrive_Params
{
	bool bEnableSwingDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableTwistDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSkipCustomPhysicsType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllMotorsAngularDriveParams
struct USkeletalMeshComponent_SetAllMotorsAngularDriveParams_Params
{
	float InSpring; // (Parm, ZeroConstructor, IsPlainOldData)
	float InDamping; // (Parm, ZeroConstructor, IsPlainOldData)
	float InForceLimit; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSkipCustomPhysicsType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllBodiesSimulatePhysics
struct USkeletalMeshComponent_SetAllBodiesSimulatePhysics_Params
{
	bool bNewSimulate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllBodiesPhysicsBlendWeight
struct USkeletalMeshComponent_SetAllBodiesPhysicsBlendWeight_Params
{
	float PhysicsBlendWeight; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSkipCustomPhysicsType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllBodiesBelowSimulatePhysics
struct USkeletalMeshComponent_SetAllBodiesBelowSimulatePhysics_Params
{
	struct FName InBoneName; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool bNewSimulate; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.SetAllBodiesBelowPhysicsBlendWeight
struct USkeletalMeshComponent_SetAllBodiesBelowPhysicsBlendWeight_Params
{
	struct FName InBoneName; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float PhysicsBlendWeight; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSkipCustomPhysicsType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.ResumeClothingSimulation
struct USkeletalMeshComponent_ResumeClothingSimulation_Params
{
};

// Function Engine.SkeletalMeshComponent.ResetClothTeleportMode
struct USkeletalMeshComponent_ResetClothTeleportMode_Params
{
};

// Function Engine.SkeletalMeshComponent.ResetClothSimulationDelay
struct USkeletalMeshComponent_ResetClothSimulationDelay_Params
{
};

// Function Engine.SkeletalMeshComponent.ResetClothAnimDriveRuntimeOverrides
struct USkeletalMeshComponent_ResetClothAnimDriveRuntimeOverrides_Params
{
};

// Function Engine.SkeletalMeshComponent.ResetAllowedAnimCurveEvaluation
struct USkeletalMeshComponent_ResetAllowedAnimCurveEvaluation_Params
{
};

// Function Engine.SkeletalMeshComponent.ResetAllBodiesSimulatePhysics
struct USkeletalMeshComponent_ResetAllBodiesSimulatePhysics_Params
{
};

// Function Engine.SkeletalMeshComponent.PlayAnimation
struct USkeletalMeshComponent_PlayAnimation_Params
{
	class UAnimationAsset* NewAnimToPlay; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLooping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.Play
struct USkeletalMeshComponent_Play_Params
{
	bool bLooping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.OverrideAnimationData
struct USkeletalMeshComponent_OverrideAnimationData_Params
{
	class UAnimationAsset* InAnimToPlay; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIsLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIsPlaying; // (Parm, ZeroConstructor, IsPlainOldData)
	float Position; // (Parm, ZeroConstructor, IsPlainOldData)
	float PlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.K2_GetClosestPointOnPhysicsAsset
struct USkeletalMeshComponent_K2_GetClosestPointOnPhysicsAsset_Params
{
	struct FVector WorldPosition; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector ClosestWorldPosition; // (Parm, OutParm, IsPlainOldData)
	struct FVector Normal; // (Parm, OutParm, IsPlainOldData)
	struct FName BoneName; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Distance; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.IsPlaying
struct USkeletalMeshComponent_IsPlaying_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.IsClothingSimulationSuspended
struct USkeletalMeshComponent_IsClothingSimulationSuspended_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.IsBodyGravityEnabled
struct USkeletalMeshComponent_IsBodyGravityEnabled_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetTeleportRotationThreshold
struct USkeletalMeshComponent_GetTeleportRotationThreshold_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetTeleportDistanceThreshold
struct USkeletalMeshComponent_GetTeleportDistanceThreshold_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetSubInstance
struct USkeletalMeshComponent_GetSubInstance_Params
{
	struct FName InTag; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class UAnimInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetSubAnimInstances
struct USkeletalMeshComponent_GetSubAnimInstances_Params
{
	TArray<class UAnimInstance*> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.SkeletalMeshComponent.GetSkeletalCenterOfMass
struct USkeletalMeshComponent_GetSkeletalCenterOfMass_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetPostProcessInstance
struct USkeletalMeshComponent_GetPostProcessInstance_Params
{
	class UAnimInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetPosition
struct USkeletalMeshComponent_GetPosition_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetPlayRate
struct USkeletalMeshComponent_GetPlayRate_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetMorphTarget
struct USkeletalMeshComponent_GetMorphTarget_Params
{
	struct FName MorphTargetName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetDisableAnimCurves
struct USkeletalMeshComponent_GetDisableAnimCurves_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetCurrentJointAngles
struct USkeletalMeshComponent_GetCurrentJointAngles_Params
{
	struct FName InBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Swing1Angle; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float TwistAngle; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Swing2Angle; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetContainerObject
struct USkeletalMeshComponent_GetContainerObject_Params
{
	struct FName InTag; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class UAnimInstanceContainer* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetClothSkinningMode
struct USkeletalMeshComponent_GetClothSkinningMode_Params
{
	int ClothAssetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	EClothSkinningMode ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetClothMaxDistanceScale
struct USkeletalMeshComponent_GetClothMaxDistanceScale_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetClothAnimDriveStiffnessRange
struct USkeletalMeshComponent_GetClothAnimDriveStiffnessRange_Params
{
	float OutLow; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutHigh; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetClothAnimDriveMultiplier
struct USkeletalMeshComponent_GetClothAnimDriveMultiplier_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetClothAnimDriveMaxRelativeVelocity
struct USkeletalMeshComponent_GetClothAnimDriveMaxRelativeVelocity_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetClothAnimDriveEnabled
struct USkeletalMeshComponent_GetClothAnimDriveEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetClothAnimDriveDampingRange
struct USkeletalMeshComponent_GetClothAnimDriveDampingRange_Params
{
	float OutLow; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutHigh; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetBoneMass
struct USkeletalMeshComponent_GetBoneMass_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bScaleMass; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetAnimInstance
struct USkeletalMeshComponent_GetAnimInstance_Params
{
	class UAnimInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetAnimationMode
struct USkeletalMeshComponent_GetAnimationMode_Params
{
	TEnumAsByte<enum EAnimationMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.GetAllowedAnimCurveEvaluate
struct USkeletalMeshComponent_GetAllowedAnimCurveEvaluate_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.ForceClothNextUpdateTeleportAndReset
struct USkeletalMeshComponent_ForceClothNextUpdateTeleportAndReset_Params
{
};

// Function Engine.SkeletalMeshComponent.ForceClothNextUpdateTeleport
struct USkeletalMeshComponent_ForceClothNextUpdateTeleport_Params
{
};

// Function Engine.SkeletalMeshComponent.FindConstraintBoneName
struct USkeletalMeshComponent_FindConstraintBoneName_Params
{
	int ConstraintIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.EnableCheckPhysicsBounds
struct USkeletalMeshComponent_EnableCheckPhysicsBounds_Params
{
	bool InEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.ClearSubInstance
struct USkeletalMeshComponent_ClearSubInstance_Params
{
	struct FName InTag; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.ClearMorphTargets
struct USkeletalMeshComponent_ClearMorphTargets_Params
{
};

// Function Engine.SkeletalMeshComponent.ClearContainerObjects
struct USkeletalMeshComponent_ClearContainerObjects_Params
{
};

// Function Engine.SkeletalMeshComponent.CacheContainerObject
struct USkeletalMeshComponent_CacheContainerObject_Params
{
	struct FName InTag; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class UAnimInstanceContainer* InContainerObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimInstance* OwnerInstance; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.BreakConstraint
struct USkeletalMeshComponent_BreakConstraint_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	struct FVector HitLocation; // (Parm, IsPlainOldData)
	struct FName InBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.BindClothToMasterPoseComponent
struct USkeletalMeshComponent_BindClothToMasterPoseComponent_Params
{
};

// Function Engine.SkeletalMeshComponent.AllowAnimCurveEvaluation
struct USkeletalMeshComponent_AllowAnimCurveEvaluation_Params
{
	struct FName NameOfCurve; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAllow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.AddImpulseToAllBodiesBelow
struct USkeletalMeshComponent_AddImpulseToAllBodiesBelow_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bVelChange; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.AddForceToAllBodiesBelow
struct USkeletalMeshComponent_AddForceToAllBodiesBelow_Params
{
	struct FVector Force; // (Parm, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAccelChange; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMeshComponent.AccumulateAllBodiesBelowPhysicsBlendWeight
struct USkeletalMeshComponent_AccumulateAllBodiesBelowPhysicsBlendWeight_Params
{
	struct FName InBoneName; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float AddPhysicsBlendWeight; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSkipCustomPhysicsType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.UnlockAIResources
struct UAnimInstance_UnlockAIResources_Params
{
	bool bUnlockMovement; // (Parm, ZeroConstructor, IsPlainOldData)
	bool UnlockAILogic; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.TryGetPawnOwner
struct UAnimInstance_TryGetPawnOwner_Params
{
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.StopSlotAnimation
struct UAnimInstance_StopSlotAnimation_Params
{
	float InBlendOutTime; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName SlotNodeName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.SnapshotPose
struct UAnimInstance_SnapshotPose_Params
{
	struct FPoseSnapshot Snapshot; // (Parm, OutParm, ReferenceParm)
};

// Function Engine.AnimInstance.SetSubAnimNodeAnimInstance
struct UAnimInstance_SetSubAnimNodeAnimInstance_Params
{
	struct FName SubInstanceSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimInstance* AnimInstance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.SetRootMotionMode
struct UAnimInstance_SetRootMotionMode_Params
{
	TEnumAsByte<enum ERootMotionMode> Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.SetMorphTarget
struct UAnimInstance_SetMorphTarget_Params
{
	struct FName MorphTargetName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.SetForceParallelUpdateAnimation
struct UAnimInstance_SetForceParallelUpdateAnimation_Params
{
	bool bForce; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.SavePoseSnapshot
struct UAnimInstance_SavePoseSnapshot_Params
{
	struct FName SnapshotName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.ResetSubAnimNodeAnimInstance
struct UAnimInstance_ResetSubAnimNodeAnimInstance_Params
{
	struct FName SubInstanceSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.PrimeUpdateCounterForDormantSubInstance
struct UAnimInstance_PrimeUpdateCounterForDormantSubInstance_Params
{
};

// Function Engine.AnimInstance.PlaySlotAnimationAsDynamicMontage
struct UAnimInstance_PlaySlotAnimationAsDynamicMontage_Params
{
	class UAnimSequenceBase* Asset; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName SlotNodeName; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendInTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendOutTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
	int LoopCount; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendOutTriggerTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InTimeToStartMontageAt; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimMontage* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.PlaySlotAnimation
struct UAnimInstance_PlaySlotAnimation_Params
{
	class UAnimSequenceBase* Asset; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName SlotNodeName; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendInTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendOutTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
	int LoopCount; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_Stop
struct UAnimInstance_Montage_Stop_Params
{
	float InBlendOutTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_SetPosition
struct UAnimInstance_Montage_SetPosition_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float NewPosition; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_SetPlayRate
struct UAnimInstance_Montage_SetPlayRate_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float NewPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_SetNextSection
struct UAnimInstance_Montage_SetNextSection_Params
{
	struct FName SectionNameToChange; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName NextSection; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_Resume
struct UAnimInstance_Montage_Resume_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_Play
struct UAnimInstance_Montage_Play_Params
{
	class UAnimMontage* MontageToPlay; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
	EMontagePlayReturnType ReturnValueType; // (Parm, ZeroConstructor, IsPlainOldData)
	float InTimeToStartMontageAt; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_Pause
struct UAnimInstance_Montage_Pause_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_JumpToSectionsEnd
struct UAnimInstance_Montage_JumpToSectionsEnd_Params
{
	struct FName SectionName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_JumpToSection
struct UAnimInstance_Montage_JumpToSection_Params
{
	struct FName SectionName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_IsPlaying
struct UAnimInstance_Montage_IsPlaying_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_IsActive
struct UAnimInstance_Montage_IsActive_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_GetPosition
struct UAnimInstance_Montage_GetPosition_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_GetPlayRate
struct UAnimInstance_Montage_GetPlayRate_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_GetNextSection
struct UAnimInstance_Montage_GetNextSection_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName SectionName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_GetIsStopped
struct UAnimInstance_Montage_GetIsStopped_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_GetCurrentSection
struct UAnimInstance_Montage_GetCurrentSection_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.Montage_GetBlendTime
struct UAnimInstance_Montage_GetBlendTime_Params
{
	class UAnimMontage* Montage; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.LockAIResources
struct UAnimInstance_LockAIResources_Params
{
	bool bLockMovement; // (Parm, ZeroConstructor, IsPlainOldData)
	bool LockAILogic; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.IsSyncGroupBetweenMarkers
struct UAnimInstance_IsSyncGroupBetweenMarkers_Params
{
	struct FName InSyncGroupName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PreviousMarker; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName NextMarker; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bRespectMarkerOrder; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.IsPlayingSlotAnimation
struct UAnimInstance_IsPlayingSlotAnimation_Params
{
	class UAnimSequenceBase* Asset; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName SlotNodeName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.IsAnyMontagePlaying
struct UAnimInstance_IsAnyMontagePlaying_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.HasMarkerBeenHitThisFrame
struct UAnimInstance_HasMarkerBeenHitThisFrame_Params
{
	struct FName SyncGroup; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName MarkerName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetTimeToClosestMarker
struct UAnimInstance_GetTimeToClosestMarker_Params
{
	struct FName SyncGroup; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName MarkerName; // (Parm, ZeroConstructor, IsPlainOldData)
	float OutMarkerTime; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetSyncGroupPosition
struct UAnimInstance_GetSyncGroupPosition_Params
{
	struct FName InSyncGroupName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FMarkerSyncAnimPosition ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.AnimInstance.GetSubAnimNodeAnimInstance
struct UAnimInstance_GetSubAnimNodeAnimInstance_Params
{
	struct FName SubInstanceSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetRelevantAnimTimeRemainingFraction
struct UAnimInstance_GetRelevantAnimTimeRemainingFraction_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int StateIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetRelevantAnimTimeRemaining
struct UAnimInstance_GetRelevantAnimTimeRemaining_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int StateIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetRelevantAnimTimeFraction
struct UAnimInstance_GetRelevantAnimTimeFraction_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int StateIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetRelevantAnimTime
struct UAnimInstance_GetRelevantAnimTime_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int StateIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetRelevantAnimLength
struct UAnimInstance_GetRelevantAnimLength_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int StateIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetOwningComponent
struct UAnimInstance_GetOwningComponent_Params
{
	class USkeletalMeshComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.AnimInstance.GetOwningActor
struct UAnimInstance_GetOwningActor_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceTransitionTimeElapsedFraction
struct UAnimInstance_GetInstanceTransitionTimeElapsedFraction_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int TransitionIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceTransitionTimeElapsed
struct UAnimInstance_GetInstanceTransitionTimeElapsed_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int TransitionIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceTransitionCrossfadeDuration
struct UAnimInstance_GetInstanceTransitionCrossfadeDuration_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int TransitionIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceStateWeight
struct UAnimInstance_GetInstanceStateWeight_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int StateIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceMachineWeight
struct UAnimInstance_GetInstanceMachineWeight_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceCurrentStateElapsedTime
struct UAnimInstance_GetInstanceCurrentStateElapsedTime_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceAssetPlayerTimeFromEndFraction
struct UAnimInstance_GetInstanceAssetPlayerTimeFromEndFraction_Params
{
	int AssetPlayerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceAssetPlayerTimeFromEnd
struct UAnimInstance_GetInstanceAssetPlayerTimeFromEnd_Params
{
	int AssetPlayerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceAssetPlayerTimeFraction
struct UAnimInstance_GetInstanceAssetPlayerTimeFraction_Params
{
	int AssetPlayerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceAssetPlayerTime
struct UAnimInstance_GetInstanceAssetPlayerTime_Params
{
	int AssetPlayerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetInstanceAssetPlayerLength
struct UAnimInstance_GetInstanceAssetPlayerLength_Params
{
	int AssetPlayerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetCurveValue
struct UAnimInstance_GetCurveValue_Params
{
	struct FName CurveName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetCurrentStateName
struct UAnimInstance_GetCurrentStateName_Params
{
	int MachineIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetCurrentActiveMontage
struct UAnimInstance_GetCurrentActiveMontage_Params
{
	class UAnimMontage* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.GetCurMontageBySlot
struct UAnimInstance_GetCurMontageBySlot_Params
{
	struct FName SlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimMontage* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.DestroySubAnimInstance
struct UAnimInstance_DestroySubAnimInstance_Params
{
	class UAnimInstance* AnimInstance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.DestroyAllSubAnimInstances
struct UAnimInstance_DestroyAllSubAnimInstances_Params
{
};

// Function Engine.AnimInstance.CreateSubAnimInstance
struct UAnimInstance_CreateSubAnimInstance_Params
{
	class UClass* InstanceClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName InstanceName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.ClearMorphTargets
struct UAnimInstance_ClearMorphTargets_Params
{
};

// Function Engine.AnimInstance.CalculateDirection
struct UAnimInstance_CalculateDirection_Params
{
	struct FVector Velocity; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator BaseRotation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstance.BlueprintUpdateAnimation
struct UAnimInstance_BlueprintUpdateAnimation_Params
{
	float DeltaTimeX; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimInstance.BlueprintPostEvaluateAnimation
struct UAnimInstance_BlueprintPostEvaluateAnimation_Params
{
};

// Function Engine.AnimInstance.BlueprintInitializeAnimation
struct UAnimInstance_BlueprintInitializeAnimation_Params
{
};

// Function Engine.AnimInstance.BlueprintBeginPlay
struct UAnimInstance_BlueprintBeginPlay_Params
{
};

// Function Engine.Actor.WasRecentlyRendered
struct AActor_WasRecentlyRendered_Params
{
	float Tolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.UserConstructionScript
struct AActor_UserConstructionScript_Params
{
};

// Function Engine.Actor.TearOff
struct AActor_TearOff_Params
{
};

// Function Engine.Actor.SnapRootComponentTo
struct AActor_SnapRootComponentTo_Params
{
	class AActor* InParentActor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetTickGroup
struct AActor_SetTickGroup_Params
{
	TEnumAsByte<enum ETickingGroup> NewTickGroup; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetTickableWhenPaused
struct AActor_SetTickableWhenPaused_Params
{
	bool bTickableWhenPaused; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetReplicates
struct AActor_SetReplicates_Params
{
	bool bInReplicates; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetReplicateMovement
struct AActor_SetReplicateMovement_Params
{
	bool bInReplicateMovement; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetParallelWorldId
struct AActor_SetParallelWorldId_Params
{
	int InWorldId; // (Parm, ZeroConstructor, IsPlainOldData)
	int Masks; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetOwner
struct AActor_SetOwner_Params
{
	class AActor* NewOwner; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetNetUpdateGroupID
struct AActor_SetNetUpdateGroupID_Params
{
	unsigned char InGroupID; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetNetUpdateGroup
struct AActor_SetNetUpdateGroup_Params
{
	class AActor* InConnectionActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetNetDormancy
struct AActor_SetNetDormancy_Params
{
	TEnumAsByte<enum ENetDormancy> NewDormancy; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetLifeSpan
struct AActor_SetLifeSpan_Params
{
	float InLifespan; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetActorTickInterval
struct AActor_SetActorTickInterval_Params
{
	float TickInterval; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetActorTickEnabled
struct AActor_SetActorTickEnabled_Params
{
	bool bEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetActorScale3D
struct AActor_SetActorScale3D_Params
{
	struct FVector NewScale3D; // (Parm, IsPlainOldData)
};

// Function Engine.Actor.SetActorRelativeScale3D
struct AActor_SetActorRelativeScale3D_Params
{
	struct FVector NewRelativeScale; // (Parm, IsPlainOldData)
};

// Function Engine.Actor.SetActorHiddenInGame
struct AActor_SetActorHiddenInGame_Params
{
	bool bNewHidden; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.SetActorEnableCollision
struct AActor_SetActorEnableCollision_Params
{
	bool bNewActorEnableCollision; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ResetParallelWorldId
struct AActor_ResetParallelWorldId_Params
{
	int Masks; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.RemoveTickPrerequisiteComponent
struct AActor_RemoveTickPrerequisiteComponent_Params
{
	class UActorComponent* PrerequisiteComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.Actor.RemoveTickPrerequisiteActor
struct AActor_RemoveTickPrerequisiteActor_Params
{
	class AActor* PrerequisiteActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveTick
struct AActor_ReceiveTick_Params
{
	float DeltaSeconds; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveReInitForReplay
struct AActor_ReceiveReInitForReplay_Params
{
};

// Function Engine.Actor.ReceiveRadialDamage
struct AActor_ReceiveRadialDamage_Params
{
	float DamageReceived; // (Parm, ZeroConstructor, IsPlainOldData)
	class UDamageType* DamageType; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (Parm, IsPlainOldData)
	struct FHitResult HitInfo; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class AController* InstigatedBy; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceivePostReplayRecover
struct AActor_ReceivePostReplayRecover_Params
{
};

// Function Engine.Actor.ReceivePointDamage
struct AActor_ReceivePointDamage_Params
{
	float Damage; // (Parm, ZeroConstructor, IsPlainOldData)
	class UDamageType* DamageType; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector HitLocation; // (Parm, IsPlainOldData)
	struct FVector HitNormal; // (Parm, IsPlainOldData)
	class UPrimitiveComponent* HitComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ShotFromDirection; // (Parm, IsPlainOldData)
	class AController* InstigatedBy; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult HitInfo; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.Actor.ReceiveHit
struct AActor_ReceiveHit_Params
{
	class UPrimitiveComponent* MyComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class AActor* Other; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* OtherComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool bSelfMoved; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector HitLocation; // (Parm, IsPlainOldData)
	struct FVector HitNormal; // (Parm, IsPlainOldData)
	struct FVector NormalImpulse; // (Parm, IsPlainOldData)
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.Actor.ReceiveEndPlay
struct AActor_ReceiveEndPlay_Params
{
	TEnumAsByte<enum EEndPlayReason> EndPlayReason; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveDestroyed
struct AActor_ReceiveDestroyed_Params
{
};

// Function Engine.Actor.ReceiveBeginPlay
struct AActor_ReceiveBeginPlay_Params
{
};

// Function Engine.Actor.ReceiveAnyDamage
struct AActor_ReceiveAnyDamage_Params
{
	float Damage; // (Parm, ZeroConstructor, IsPlainOldData)
	class UDamageType* DamageType; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AController* InstigatedBy; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveActorOnReleased
struct AActor_ReceiveActorOnReleased_Params
{
	struct FKey ButtonReleased; // (Parm)
};

// Function Engine.Actor.ReceiveActorOnInputTouchLeave
struct AActor_ReceiveActorOnInputTouchLeave_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveActorOnInputTouchEnter
struct AActor_ReceiveActorOnInputTouchEnter_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveActorOnInputTouchEnd
struct AActor_ReceiveActorOnInputTouchEnd_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveActorOnInputTouchBegin
struct AActor_ReceiveActorOnInputTouchBegin_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveActorOnClicked
struct AActor_ReceiveActorOnClicked_Params
{
	struct FKey ButtonPressed; // (Parm)
};

// Function Engine.Actor.ReceiveActorEndOverlap
struct AActor_ReceiveActorEndOverlap_Params
{
	class AActor* OtherActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveActorEndCursorOver
struct AActor_ReceiveActorEndCursorOver_Params
{
};

// Function Engine.Actor.ReceiveActorBeginOverlap
struct AActor_ReceiveActorBeginOverlap_Params
{
	class AActor* OtherActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ReceiveActorBeginCursorOver
struct AActor_ReceiveActorBeginCursorOver_Params
{
};

// Function Engine.Actor.PrestreamTextures
struct AActor_PrestreamTextures_Params
{
	float Seconds; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableStreaming; // (Parm, ZeroConstructor, IsPlainOldData)
	int CinematicTextureGroups; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.OnRep_ReplicateMovement
struct AActor_OnRep_ReplicateMovement_Params
{
};

// Function Engine.Actor.OnRep_ReplicatedMovement
struct AActor_OnRep_ReplicatedMovement_Params
{
};

// Function Engine.Actor.OnRep_Owner
struct AActor_OnRep_Owner_Params
{
};

// Function Engine.Actor.OnRep_Instigator
struct AActor_OnRep_Instigator_Params
{
};

// Function Engine.Actor.OnRep_AttachmentReplication
struct AActor_OnRep_AttachmentReplication_Params
{
};

// Function Engine.Actor.MarkNetDormancyForReplay
struct AActor_MarkNetDormancyForReplay_Params
{
	bool bInDormancyForReplay; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bForceNetUpdate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.MakeNoise
struct AActor_MakeNoise_Params
{
	float Loudness; // (Parm, ZeroConstructor, IsPlainOldData)
	class APawn* NoiseInstigator; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NoiseLocation; // (Parm, IsPlainOldData)
	float MaxRange; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName Tag; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.MakeMIDForMaterial
struct AActor_MakeMIDForMaterial_Params
{
	class UMaterialInterface* Parent; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_TeleportTo
struct AActor_K2_TeleportTo_Params
{
	struct FVector DestLocation; // (Parm, IsPlainOldData)
	struct FRotator DestRotation; // (Parm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_SetActorTransform
struct AActor_K2_SetActorTransform_Params
{
	struct FTransform NewTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_SetActorRotation
struct AActor_K2_SetActorRotation_Params
{
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	bool bTeleportPhysics; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_SetActorRelativeTransform
struct AActor_K2_SetActorRelativeTransform_Params
{
	struct FTransform NewRelativeTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_SetActorRelativeRotation
struct AActor_K2_SetActorRelativeRotation_Params
{
	struct FRotator NewRelativeRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_SetActorRelativeLocation
struct AActor_K2_SetActorRelativeLocation_Params
{
	struct FVector NewRelativeLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_SetActorLocationAndRotation
struct AActor_K2_SetActorLocationAndRotation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_SetActorLocation
struct AActor_K2_SetActorLocation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_OnReset
struct AActor_K2_OnReset_Params
{
};

// Function Engine.Actor.K2_OnEndViewTarget
struct AActor_K2_OnEndViewTarget_Params
{
	class APlayerController* PC; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_OnBecomeViewTarget
struct AActor_K2_OnBecomeViewTarget_Params
{
	class APlayerController* PC; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_GetRootComponent
struct AActor_K2_GetRootComponent_Params
{
	class USceneComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.Actor.K2_GetActorRotation
struct AActor_K2_GetActorRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_GetActorLocation
struct AActor_K2_GetActorLocation_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.K2_DetachFromActor
struct AActor_K2_DetachFromActor_Params
{
	EDetachmentRule LocationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EDetachmentRule RotationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EDetachmentRule ScaleRule; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_DestroyComponent
struct AActor_K2_DestroyComponent_Params
{
	class UActorComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.Actor.K2_DestroyActor
struct AActor_K2_DestroyActor_Params
{
};

// Function Engine.Actor.K2_AttachToComponent
struct AActor_K2_AttachToComponent_Params
{
	class USceneComponent* Parent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName SocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule LocationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule RotationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule ScaleRule; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bWeldSimulatedBodies; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AttachToActor
struct AActor_K2_AttachToActor_Params
{
	class AActor* ParentActor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName SocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule LocationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule RotationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule ScaleRule; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bWeldSimulatedBodies; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AttachRootComponentToActor
struct AActor_K2_AttachRootComponentToActor_Params
{
	class AActor* InParentActor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> AttachLocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bWeldSimulatedBodies; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AttachRootComponentTo
struct AActor_K2_AttachRootComponentTo_Params
{
	class USceneComponent* InParent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> AttachLocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bWeldSimulatedBodies; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AddActorWorldTransform
struct AActor_K2_AddActorWorldTransform_Params
{
	struct FTransform DeltaTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AddActorWorldRotation
struct AActor_K2_AddActorWorldRotation_Params
{
	struct FRotator DeltaRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AddActorWorldOffset
struct AActor_K2_AddActorWorldOffset_Params
{
	struct FVector DeltaLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AddActorLocalTransform
struct AActor_K2_AddActorLocalTransform_Params
{
	struct FTransform NewTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AddActorLocalRotation
struct AActor_K2_AddActorLocalRotation_Params
{
	struct FRotator DeltaRotation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.K2_AddActorLocalOffset
struct AActor_K2_AddActorLocalOffset_Params
{
	struct FVector DeltaLocation; // (Parm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepHitResult; // (Parm, OutParm, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.IsOverlappingActor
struct AActor_IsOverlappingActor_Params
{
	class AActor* Other; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.IsChildActor
struct AActor_IsChildActor_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.IsActorTickEnabled
struct AActor_IsActorTickEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.IsActorBeingDestroyed
struct AActor_IsActorBeingDestroyed_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.HasAuthority
struct AActor_HasAuthority_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetVerticalDistanceTo
struct AActor_GetVerticalDistanceTo_Params
{
	class AActor* OtherActor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetVelocity
struct AActor_GetVelocity_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetTransform
struct AActor_GetTransform_Params
{
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetTickableWhenPaused
struct AActor_GetTickableWhenPaused_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetSquaredDistanceTo
struct AActor_GetSquaredDistanceTo_Params
{
	class AActor* OtherActor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetRole
struct AActor_GetRole_Params
{
	TEnumAsByte<enum ENetRole> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetRemoteRole
struct AActor_GetRemoteRole_Params
{
	TEnumAsByte<enum ENetRole> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetParentComponent
struct AActor_GetParentComponent_Params
{
	class UChildActorComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.Actor.GetParentActor
struct AActor_GetParentActor_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetParallelWorldId
struct AActor_GetParallelWorldId_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetOwner
struct AActor_GetOwner_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetOverlappingComponents
struct AActor_GetOverlappingComponents_Params
{
	TArray<class UPrimitiveComponent*> OverlappingComponents; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.Actor.GetOverlappingActors
struct AActor_GetOverlappingActors_Params
{
	TArray<class AActor*> OverlappingActors; // (Parm, OutParm, ZeroConstructor)
	class UClass* ClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.GetNetUpdateGroupID
struct AActor_GetNetUpdateGroupID_Params
{
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetLocalRole
struct AActor_GetLocalRole_Params
{
	TEnumAsByte<enum ENetRole> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetLifeSpan
struct AActor_GetLifeSpan_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetInstigatorController
struct AActor_GetInstigatorController_Params
{
	class AController* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetInstigator
struct AActor_GetInstigator_Params
{
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetInputVectorAxisValue
struct AActor_GetInputVectorAxisValue_Params
{
	struct FKey InputAxisKey; // (ConstParm, Parm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetInputAxisValue
struct AActor_GetInputAxisValue_Params
{
	struct FName InputAxisName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetInputAxisKeyValue
struct AActor_GetInputAxisKeyValue_Params
{
	struct FKey InputAxisKey; // (ConstParm, Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetHorizontalDotProductTo
struct AActor_GetHorizontalDotProductTo_Params
{
	class AActor* OtherActor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetHorizontalDistanceTo
struct AActor_GetHorizontalDistanceTo_Params
{
	class AActor* OtherActor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetGameTimeSinceCreation
struct AActor_GetGameTimeSinceCreation_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetDotProductTo
struct AActor_GetDotProductTo_Params
{
	class AActor* OtherActor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetDistanceTo
struct AActor_GetDistanceTo_Params
{
	class AActor* OtherActor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetComponentsByTag
struct AActor_GetComponentsByTag_Params
{
	class UClass* ComponentClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName Tag; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class UActorComponent*> ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.Actor.GetComponentsByClass
struct AActor_GetComponentsByClass_Params
{
	class UClass* ComponentClass; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class UActorComponent*> ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.Actor.GetComponentByClass
struct AActor_GetComponentByClass_Params
{
	class UClass* ComponentClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UActorComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.Actor.GetAttachParentSocketName
struct AActor_GetAttachParentSocketName_Params
{
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetAttachParentActor
struct AActor_GetAttachParentActor_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetAttachedActors
struct AActor_GetAttachedActors_Params
{
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.Actor.GetAllChildActors
struct AActor_GetAllChildActors_Params
{
	TArray<class AActor*> ChildActors; // (Parm, OutParm, ZeroConstructor)
	bool bIncludeDescendants; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.GetActorUpVector
struct AActor_GetActorUpVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorTimeDilation
struct AActor_GetActorTimeDilation_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorTickInterval
struct AActor_GetActorTickInterval_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorScale3D
struct AActor_GetActorScale3D_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorRightVector
struct AActor_GetActorRightVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorRelativeScale3D
struct AActor_GetActorRelativeScale3D_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorForwardVector
struct AActor_GetActorForwardVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorEyesViewPoint
struct AActor_GetActorEyesViewPoint_Params
{
	struct FVector OutLocation; // (Parm, OutParm, IsPlainOldData)
	struct FRotator OutRotation; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorEnableCollision
struct AActor_GetActorEnableCollision_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.GetActorBounds
struct AActor_GetActorBounds_Params
{
	bool bOnlyCollidingComponents; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (Parm, OutParm, IsPlainOldData)
	struct FVector BoxExtent; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.Actor.ForceNetUpdate
struct AActor_ForceNetUpdate_Params
{
};

// Function Engine.Actor.ForceNetConsider
struct AActor_ForceNetConsider_Params
{
};

// Function Engine.Actor.FlushNetDormancyOnceForReplay
struct AActor_FlushNetDormancyOnceForReplay_Params
{
};

// Function Engine.Actor.FlushNetDormancy
struct AActor_FlushNetDormancy_Params
{
};

// Function Engine.Actor.EnableInput
struct AActor_EnableInput_Params
{
	class APlayerController* PlayerController; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.DisableInput
struct AActor_DisableInput_Params
{
	class APlayerController* PlayerController; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.DetachRootComponentFromParent
struct AActor_DetachRootComponentFromParent_Params
{
	bool bMaintainWorldPosition; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.ClearComponentOverlaps
struct AActor_ClearComponentOverlaps_Params
{
};

// Function Engine.Actor.BeenInParallelWorld
struct AActor_BeenInParallelWorld_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Actor.AddTickPrerequisiteComponent
struct AActor_AddTickPrerequisiteComponent_Params
{
	class UActorComponent* PrerequisiteComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.Actor.AddTickPrerequisiteActor
struct AActor_AddTickPrerequisiteActor_Params
{
	class AActor* PrerequisiteActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Actor.AddComponent
struct AActor_AddComponent_Params
{
	struct FName TemplateName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bManualAttachment; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform RelativeTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class UObject* ComponentTemplateContext; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UActorComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// DelegateFunction Engine.Actor.ActorTriggeredBySignature__DelegateSignature
struct AActor_ActorTriggeredBySignature__DelegateSignature_Params
{
	class AActor* OtherActor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTriggerEvent TriggerEvent; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// DelegateFunction Engine.Actor.ActorPhysicsContactSignature__DelegateSignature
struct AActor_ActorPhysicsContactSignature__DelegateSignature_Params
{
	class AActor* OtherActor; // (Parm, ZeroConstructor, IsPlainOldData)
	EPhysicsContactState ContactState; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NormalImpulse; // (Parm, IsPlainOldData)
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// DelegateFunction Engine.Actor.ActorInteractWithTriggerSignature__DelegateSignature
struct AActor_ActorInteractWithTriggerSignature__DelegateSignature_Params
{
	class AActor* TriggerActor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTriggerEvent TriggerEvent; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.Actor.ActorHasTag
struct AActor_ActorHasTag_Params
{
	struct FName Tag; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.SpawnDefaultController
struct APawn_SpawnDefaultController_Params
{
};

// Function Engine.Pawn.SetUseViewTranslatedTransform
struct APawn_SetUseViewTranslatedTransform_Params
{
	bool bNewUseViewTranslatedTransform; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.SetCanAffectNavigationGeneration
struct APawn_SetCanAffectNavigationGeneration_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bForceUpdate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.ReceiveUnpossessed
struct APawn_ReceiveUnpossessed_Params
{
	class AController* OldController; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.ReceivePossessed
struct APawn_ReceivePossessed_Params
{
	class AController* NewController; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.PawnMakeNoise
struct APawn_PawnMakeNoise_Params
{
	float Loudness; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NoiseLocation; // (Parm, IsPlainOldData)
	bool bUseNoiseMakerLocation; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* NoiseMaker; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.OnRep_PlayerState
struct APawn_OnRep_PlayerState_Params
{
};

// Function Engine.Pawn.OnRep_Controller
struct APawn_OnRep_Controller_Params
{
};

// Function Engine.Pawn.LaunchPawn
struct APawn_LaunchPawn_Params
{
	struct FVector LaunchVelocity; // (Parm, IsPlainOldData)
	bool bXYOverride; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bZOverride; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.K2_GetMovementInputVector
struct APawn_K2_GetMovementInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.IsPlayerControlled
struct APawn_IsPlayerControlled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.IsMoveInputIgnored
struct APawn_IsMoveInputIgnored_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.IsLocallyControlled
struct APawn_IsLocallyControlled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.IsControlled
struct APawn_IsControlled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.GetPendingMovementInputVector
struct APawn_GetPendingMovementInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.GetNavAgentLocation
struct APawn_GetNavAgentLocation_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.GetMovementComponent
struct APawn_GetMovementComponent_Params
{
	class UPawnMovementComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.Pawn.GetMovementBaseActor
struct APawn_GetMovementBaseActor_Params
{
	class APawn* Pawn; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.GetMovementBase
struct APawn_GetMovementBase_Params
{
	class UPrimitiveComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.Pawn.GetLastMovementInputVector
struct APawn_GetLastMovementInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.GetControlRotation
struct APawn_GetControlRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.GetController
struct APawn_GetController_Params
{
	class AController* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.GetBaseAimRotation
struct APawn_GetBaseAimRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.DetachFromControllerPendingDestroy
struct APawn_DetachFromControllerPendingDestroy_Params
{
};

// Function Engine.Pawn.ConsumeMovementInputVector
struct APawn_ConsumeMovementInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Pawn.AddMovementInput
struct APawn_AddMovementInput_Params
{
	struct FVector WorldDirection; // (Parm, IsPlainOldData)
	float ScaleValue; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bForce; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.AddControllerYawInput
struct APawn_AddControllerYawInput_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.AddControllerRollInput
struct APawn_AddControllerRollInput_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Pawn.AddControllerPitchInput
struct APawn_AddControllerPitchInput_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MovementComponent.StopMovementImmediately
struct UMovementComponent_StopMovementImmediately_Params
{
};

// Function Engine.MovementComponent.SnapUpdatedComponentToPlane
struct UMovementComponent_SnapUpdatedComponentToPlane_Params
{
};

// Function Engine.MovementComponent.SetUpdatedComponent
struct UMovementComponent_SetUpdatedComponent_Params
{
	class USceneComponent* NewUpdatedComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.MovementComponent.SetPlaneConstraintOrigin
struct UMovementComponent_SetPlaneConstraintOrigin_Params
{
	struct FVector PlaneOrigin; // (Parm, IsPlainOldData)
};

// Function Engine.MovementComponent.SetPlaneConstraintNormal
struct UMovementComponent_SetPlaneConstraintNormal_Params
{
	struct FVector PlaneNormal; // (Parm, IsPlainOldData)
};

// Function Engine.MovementComponent.SetPlaneConstraintFromVectors
struct UMovementComponent_SetPlaneConstraintFromVectors_Params
{
	struct FVector Forward; // (Parm, IsPlainOldData)
	struct FVector Up; // (Parm, IsPlainOldData)
};

// Function Engine.MovementComponent.SetPlaneConstraintEnabled
struct UMovementComponent_SetPlaneConstraintEnabled_Params
{
	bool bEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MovementComponent.SetPlaneConstraintAxisSetting
struct UMovementComponent_SetPlaneConstraintAxisSetting_Params
{
	EPlaneConstraintAxisSetting NewAxisSetting; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MovementComponent.PhysicsVolumeChanged
struct UMovementComponent_PhysicsVolumeChanged_Params
{
	class APhysicsVolume* NewVolume; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MovementComponent.K2_MoveUpdatedComponent
struct UMovementComponent_K2_MoveUpdatedComponent_Params
{
	struct FVector Delta; // (Parm, IsPlainOldData)
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.K2_GetModifiedMaxSpeed
struct UMovementComponent_K2_GetModifiedMaxSpeed_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.K2_GetMaxSpeedModifier
struct UMovementComponent_K2_GetMaxSpeedModifier_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.IsExceedingMaxSpeed
struct UMovementComponent_IsExceedingMaxSpeed_Params
{
	float MaxSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.GetPlaneConstraintOrigin
struct UMovementComponent_GetPlaneConstraintOrigin_Params
{
	struct FVector ReturnValue; // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.MovementComponent.GetPlaneConstraintNormal
struct UMovementComponent_GetPlaneConstraintNormal_Params
{
	struct FVector ReturnValue; // (ConstParm, Parm, OutParm, ReturnParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.MovementComponent.GetPlaneConstraintAxisSetting
struct UMovementComponent_GetPlaneConstraintAxisSetting_Params
{
	EPlaneConstraintAxisSetting ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.GetPhysicsVolume
struct UMovementComponent_GetPhysicsVolume_Params
{
	class APhysicsVolume* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.GetMaxSpeed
struct UMovementComponent_GetMaxSpeed_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.GetGravityZ
struct UMovementComponent_GetGravityZ_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.ConstrainNormalToPlane
struct UMovementComponent_ConstrainNormalToPlane_Params
{
	struct FVector Normal; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.ConstrainLocationToPlane
struct UMovementComponent_ConstrainLocationToPlane_Params
{
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.MovementComponent.ConstrainDirectionToPlane
struct UMovementComponent_ConstrainDirectionToPlane_Params
{
	struct FVector Direction; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.NavMovementComponent.StopMovementKeepPathing
struct UNavMovementComponent_StopMovementKeepPathing_Params
{
};

// Function Engine.NavMovementComponent.StopActiveMovement
struct UNavMovementComponent_StopActiveMovement_Params
{
};

// Function Engine.NavMovementComponent.IsSwimming
struct UNavMovementComponent_IsSwimming_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavMovementComponent.IsMovingOnGround
struct UNavMovementComponent_IsMovingOnGround_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavMovementComponent.IsFlying
struct UNavMovementComponent_IsFlying_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavMovementComponent.IsFalling
struct UNavMovementComponent_IsFalling_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavMovementComponent.IsCrouching
struct UNavMovementComponent_IsCrouching_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnMovementComponent.K2_GetInputVector
struct UPawnMovementComponent_K2_GetInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnMovementComponent.IsMoveInputIgnored
struct UPawnMovementComponent_IsMoveInputIgnored_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnMovementComponent.GetPendingInputVector
struct UPawnMovementComponent_GetPendingInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnMovementComponent.GetPawnOwner
struct UPawnMovementComponent_GetPawnOwner_Params
{
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnMovementComponent.GetLastInputVector
struct UPawnMovementComponent_GetLastInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnMovementComponent.ConsumeInputVector
struct UPawnMovementComponent_ConsumeInputVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnMovementComponent.AddInputVector
struct UPawnMovementComponent_AddInputVector_Params
{
	struct FVector WorldVector; // (Parm, IsPlainOldData)
	bool bForce; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ProjectileMovementComponent.StopSimulating
struct UProjectileMovementComponent_StopSimulating_Params
{
	struct FHitResult HitResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.ProjectileMovementComponent.SetVelocityInLocalSpace
struct UProjectileMovementComponent_SetVelocityInLocalSpace_Params
{
	struct FVector NewVelocity; // (Parm, IsPlainOldData)
};

// DelegateFunction Engine.ProjectileMovementComponent.OnProjectileStopDelegate__DelegateSignature
struct UProjectileMovementComponent_OnProjectileStopDelegate__DelegateSignature_Params
{
	struct FHitResult ImpactResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// DelegateFunction Engine.ProjectileMovementComponent.OnProjectileBounceDelegate__DelegateSignature
struct UProjectileMovementComponent_OnProjectileBounceDelegate__DelegateSignature_Params
{
	struct FHitResult ImpactResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector ImpactVelocity; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.ProjectileMovementComponent.LimitVelocity
struct UProjectileMovementComponent_LimitVelocity_Params
{
	struct FVector NewVelocity; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.UnCrouch
struct ACharacter_UnCrouch_Params
{
	bool bClientSimulation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.StopJumping
struct ACharacter_StopJumping_Params
{
};

// Function Engine.Character.StopAnimMontage
struct ACharacter_StopAnimMontage_Params
{
	class UAnimMontage* AnimMontage; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.SetReplicateMovement
struct ACharacter_SetReplicateMovement_Params
{
	bool bInReplicateMovement; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.RootMotionDebugClientPrintOnScreen
struct ACharacter_RootMotionDebugClientPrintOnScreen_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
};

// Function Engine.Character.PlayAnimMontage
struct ACharacter_PlayAnimMontage_Params
{
	class UAnimMontage* AnimMontage; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName StartSectionName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.OnWalkingOffLedge
struct ACharacter_OnWalkingOffLedge_Params
{
	struct FVector PreviousFloorImpactNormal; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector PreviousFloorContactNormal; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector PreviousLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float TimeDelta; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.OnRep_ServerLastTransformUpdateTimeStamp
struct ACharacter_OnRep_ServerLastTransformUpdateTimeStamp_Params
{
};

// Function Engine.Character.OnRep_RootMotion
struct ACharacter_OnRep_RootMotion_Params
{
};

// Function Engine.Character.OnRep_ReplicatedBasedMovement
struct ACharacter_OnRep_ReplicatedBasedMovement_Params
{
};

// Function Engine.Character.OnRep_IsCrouched
struct ACharacter_OnRep_IsCrouched_Params
{
};

// Function Engine.Character.OnLaunched
struct ACharacter_OnLaunched_Params
{
	struct FVector LaunchVelocity; // (Parm, IsPlainOldData)
	bool bXYOverride; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bZOverride; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.OnLanded
struct ACharacter_OnLanded_Params
{
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.Character.OnJumped
struct ACharacter_OnJumped_Params
{
};

// Function Engine.Character.LaunchCharacter
struct ACharacter_LaunchCharacter_Params
{
	struct FVector LaunchVelocity; // (Parm, IsPlainOldData)
	bool bXYOverride; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bZOverride; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.K2_UpdateCustomMovement
struct ACharacter_K2_UpdateCustomMovement_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.K2_OnStartCrouch
struct ACharacter_K2_OnStartCrouch_Params
{
	float HalfHeightAdjust; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScaledHalfHeightAdjust; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.K2_OnMovementModeChanged
struct ACharacter_K2_OnMovementModeChanged_Params
{
	TEnumAsByte<enum EMovementMode> PrevMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EMovementMode> NewMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char PrevCustomMode; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char NewCustomMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.K2_OnEndCrouch
struct ACharacter_K2_OnEndCrouch_Params
{
	float HalfHeightAdjust; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScaledHalfHeightAdjust; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.Jump
struct ACharacter_Jump_Params
{
};

// Function Engine.Character.IsPlayingRootMotion
struct ACharacter_IsPlayingRootMotion_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.IsPlayingNetworkedRootMotionMontage
struct ACharacter_IsPlayingNetworkedRootMotionMontage_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.IsJumpProvidingForce
struct ACharacter_IsJumpProvidingForce_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.GetCurrentMontage
struct ACharacter_GetCurrentMontage_Params
{
	class UAnimMontage* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.GetBaseTranslationOffset
struct ACharacter_GetBaseTranslationOffset_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.GetBaseRotationOffsetRotator
struct ACharacter_GetBaseRotationOffsetRotator_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.GetAnimRootMotionTranslationScale
struct ACharacter_GetAnimRootMotionTranslationScale_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.Crouch
struct ACharacter_Crouch_Params
{
	bool bClientSimulation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Character.ClientCheatWalk
struct ACharacter_ClientCheatWalk_Params
{
};

// Function Engine.Character.ClientCheatGhost
struct ACharacter_ClientCheatGhost_Params
{
};

// Function Engine.Character.ClientCheatFly
struct ACharacter_ClientCheatFly_Params
{
};

// Function Engine.Character.CanJumpInternal
struct ACharacter_CanJumpInternal_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.CanJump
struct ACharacter_CanJump_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Character.CacheInitialMeshOffset
struct ACharacter_CacheInitialMeshOffset_Params
{
	struct FVector MeshRelativeLocation; // (Parm, IsPlainOldData)
	struct FRotator MeshRelativeRotation; // (Parm, IsPlainOldData)
};

// Function Engine.Controller.UnPossess
struct AController_UnPossess_Params
{
};

// Function Engine.Controller.StopMovement
struct AController_StopMovement_Params
{
};

// Function Engine.Controller.SetInitialLocationAndRotation
struct AController_SetInitialLocationAndRotation_Params
{
	struct FVector NewLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator NewRotation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.Controller.SetIgnoreMoveInput
struct AController_SetIgnoreMoveInput_Params
{
	bool bNewMoveInput; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Controller.SetIgnoreLookInput
struct AController_SetIgnoreLookInput_Params
{
	bool bNewLookInput; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Controller.SetControlRotation
struct AController_SetControlRotation_Params
{
	struct FRotator NewRotation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FString CallSource; // (Parm, ZeroConstructor)
};

// Function Engine.Controller.ResetIgnoreMoveInput
struct AController_ResetIgnoreMoveInput_Params
{
};

// Function Engine.Controller.ResetIgnoreLookInput
struct AController_ResetIgnoreLookInput_Params
{
};

// Function Engine.Controller.ResetIgnoreInputFlags
struct AController_ResetIgnoreInputFlags_Params
{
};

// Function Engine.Controller.ReceiveInstigatedAnyDamage
struct AController_ReceiveInstigatedAnyDamage_Params
{
	float Damage; // (Parm, ZeroConstructor, IsPlainOldData)
	class UDamageType* DamageType; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor* DamagedActor; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Controller.PossessOnlyClient
struct AController_PossessOnlyClient_Params
{
	class APawn* InPawn; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Controller.Possess
struct AController_Possess_Params
{
	class APawn* InPawn; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Controller.OnRep_PlayerState
struct AController_OnRep_PlayerState_Params
{
};

// Function Engine.Controller.OnRep_Pawn
struct AController_OnRep_Pawn_Params
{
};

// Function Engine.Controller.LineOfSightTo
struct AController_LineOfSightTo_Params
{
	class AActor* Other; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ViewPoint; // (Parm, IsPlainOldData)
	bool bAlternateChecks; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.K2_GetPawn
struct AController_K2_GetPawn_Params
{
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.IsPlayerController
struct AController_IsPlayerController_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.IsMoveInputIgnored
struct AController_IsMoveInputIgnored_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.IsLookInputIgnored
struct AController_IsLookInputIgnored_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.IsLocalPlayerController
struct AController_IsLocalPlayerController_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.IsLocalController
struct AController_IsLocalController_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.GetViewTarget
struct AController_GetViewTarget_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.GetDesiredRotation
struct AController_GetDesiredRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.GetControlRotation
struct AController_GetControlRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Controller.ClientSetRotation
struct AController_ClientSetRotation_Params
{
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
	bool bResetCamera; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Controller.ClientSetLocation
struct AController_ClientSetLocation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
};

// Function Engine.Controller.CastToPlayerController
struct AController_CastToPlayerController_Params
{
	class APlayerController* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimNotify.Received_Notify
struct UAnimNotify_Received_Notify_Params
{
	class USkeletalMeshComponent* MeshComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UAnimSequenceBase* Animation; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimNotify.GetNotifyName
struct UAnimNotify_GetNotifyName_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.AnimNotifyState.Received_NotifyTick
struct UAnimNotifyState_Received_NotifyTick_Params
{
	class USkeletalMeshComponent* MeshComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UAnimSequenceBase* Animation; // (Parm, ZeroConstructor, IsPlainOldData)
	float FrameDeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimNotifyState.Received_NotifyEnd
struct UAnimNotifyState_Received_NotifyEnd_Params
{
	class USkeletalMeshComponent* MeshComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UAnimSequenceBase* Animation; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimNotifyState.Received_NotifyBegin
struct UAnimNotifyState_Received_NotifyBegin_Params
{
	class USkeletalMeshComponent* MeshComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UAnimSequenceBase* Animation; // (Parm, ZeroConstructor, IsPlainOldData)
	float TotalDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimNotifyState.GetNotifyName
struct UAnimNotifyState_GetNotifyName_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.GameInstance.ReceiveShutdown
struct UGameInstance_ReceiveShutdown_Params
{
};

// Function Engine.GameInstance.ReceiveInit
struct UGameInstance_ReceiveInit_Params
{
};

// Function Engine.GameInstance.HandleTravelError
struct UGameInstance_HandleTravelError_Params
{
	TEnumAsByte<enum ETravelFailure> FailureType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameInstance.HandleNetworkError
struct UGameInstance_HandleNetworkError_Params
{
	TEnumAsByte<enum ENetworkFailure> FailureType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIsServer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameInstance.GetDeviceLevel
struct UGameInstance_GetDeviceLevel_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameInstance.DebugRemovePlayer
struct UGameInstance_DebugRemovePlayer_Params
{
	int ControllerId; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameInstance.DebugCreatePlayer
struct UGameInstance_DebugCreatePlayer_Params
{
	int ControllerId; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.StartPlay
struct AGameModeBase_StartPlay_Params
{
};

// Function Engine.GameModeBase.SpawnDefaultPawnFor
struct AGameModeBase_SpawnDefaultPawnFor_Params
{
	class AController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* StartSpot; // (Parm, ZeroConstructor, IsPlainOldData)
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.SpawnDefaultPawnAtTransform
struct AGameModeBase_SpawnDefaultPawnAtTransform_Params
{
	class AController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform SpawnTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.ShouldReset
struct AGameModeBase_ShouldReset_Params
{
	class AActor* ActorToReset; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.ReturnToMainMenuHost
struct AGameModeBase_ReturnToMainMenuHost_Params
{
};

// Function Engine.GameModeBase.RestartPlayerAtTransform
struct AGameModeBase_RestartPlayerAtTransform_Params
{
	class AController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform SpawnTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.GameModeBase.RestartPlayerAtPlayerStart
struct AGameModeBase_RestartPlayerAtPlayerStart_Params
{
	class AController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* StartSpot; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.RestartPlayer
struct AGameModeBase_RestartPlayer_Params
{
	class AController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.ResetLevel
struct AGameModeBase_ResetLevel_Params
{
};

// Function Engine.GameModeBase.PlayerCanRestart
struct AGameModeBase_PlayerCanRestart_Params
{
	class APlayerController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.MustSpectate
struct AGameModeBase_MustSpectate_Params
{
	class APlayerController* NewPlayerController; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.K2_PostLogin
struct AGameModeBase_K2_PostLogin_Params
{
	class APlayerController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.K2_OnSwapPlayerControllers
struct AGameModeBase_K2_OnSwapPlayerControllers_Params
{
	class APlayerController* OldPC; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerController* NewPC; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.K2_OnRestartPlayer
struct AGameModeBase_K2_OnRestartPlayer_Params
{
	class AController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.K2_OnLogout
struct AGameModeBase_K2_OnLogout_Params
{
	class AController* ExitingController; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.K2_OnChangeName
struct AGameModeBase_K2_OnChangeName_Params
{
	class AController* Other; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString NewName; // (Parm, ZeroConstructor)
	bool bNameChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.K2_FindPlayerStart
struct AGameModeBase_K2_FindPlayerStart_Params
{
	class AController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString IncomingName; // (Parm, ZeroConstructor)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.InitStartSpot
struct AGameModeBase_InitStartSpot_Params
{
	class AActor* StartSpot; // (Parm, ZeroConstructor, IsPlainOldData)
	class AController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.InitializeHUDForPlayer
struct AGameModeBase_InitializeHUDForPlayer_Params
{
	class APlayerController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.HasMatchStarted
struct AGameModeBase_HasMatchStarted_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.HandleStartingNewPlayer
struct AGameModeBase_HandleStartingNewPlayer_Params
{
	class APlayerController* NewPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.GetNumSpectators
struct AGameModeBase_GetNumSpectators_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.GetNumPlayers
struct AGameModeBase_GetNumPlayers_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.GetDefaultPawnClassForController
struct AGameModeBase_GetDefaultPawnClassForController_Params
{
	class AController* InController; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.FindPlayerStart
struct AGameModeBase_FindPlayerStart_Params
{
	class AController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString IncomingName; // (Parm, ZeroConstructor)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.ChoosePlayerStart
struct AGameModeBase_ChoosePlayerStart_Params
{
	class AController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameModeBase.ChangeName
struct AGameModeBase_ChangeName_Params
{
	class AController* Controller; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString NewName; // (Parm, ZeroConstructor)
	bool bNameChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameModeBase.CanSpectate
struct AGameModeBase_CanSpectate_Params
{
	class APlayerController* Viewer; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerState* ViewTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameMode.StartMatch
struct AGameMode_StartMatch_Params
{
};

// Function Engine.GameMode.SetBandwidthLimit
struct AGameMode_SetBandwidthLimit_Params
{
	float AsyncIOBandwidthLimit; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameMode.Say
struct AGameMode_Say_Params
{
	struct FString Msg; // (Parm, ZeroConstructor)
};

// Function Engine.GameMode.RestartGame
struct AGameMode_RestartGame_Params
{
};

// Function Engine.GameMode.ReadyToStartMatch
struct AGameMode_ReadyToStartMatch_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameMode.ReadyToEndMatch
struct AGameMode_ReadyToEndMatch_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameMode.K2_OnSetMatchState
struct AGameMode_K2_OnSetMatchState_Params
{
	struct FName NewState; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameMode.IsMatchInProgress
struct AGameMode_IsMatchInProgress_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameMode.HasMatchEnded
struct AGameMode_HasMatchEnded_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameMode.GetMatchState
struct AGameMode_GetMatchState_Params
{
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameMode.EndMatch
struct AGameMode_EndMatch_Params
{
};

// Function Engine.GameMode.AbortMatch
struct AGameMode_AbortMatch_Params
{
};

// Function Engine.BoxComponent.SetBoxExtent
struct UBoxComponent_SetBoxExtent_Params
{
	struct FVector InBoxExtent; // (Parm, IsPlainOldData)
	bool bUpdateOverlaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BoxComponent.GetUnscaledBoxExtent
struct UBoxComponent_GetUnscaledBoxExtent_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.BoxComponent.GetScaledBoxExtent
struct UBoxComponent_GetScaledBoxExtent_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameStateBase.OnRep_SpectatorClass
struct AGameStateBase_OnRep_SpectatorClass_Params
{
};

// Function Engine.GameStateBase.OnRep_ReplicatedWorldTimeSeconds
struct AGameStateBase_OnRep_ReplicatedWorldTimeSeconds_Params
{
};

// Function Engine.GameStateBase.OnRep_ReplicatedHasBegunPlay
struct AGameStateBase_OnRep_ReplicatedHasBegunPlay_Params
{
};

// Function Engine.GameStateBase.OnRep_GameModeClass
struct AGameStateBase_OnRep_GameModeClass_Params
{
};

// Function Engine.GameStateBase.HasMatchStarted
struct AGameStateBase_HasMatchStarted_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameStateBase.HasBegunPlay
struct AGameStateBase_HasBegunPlay_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameStateBase.GetServerWorldTimeSeconds
struct AGameStateBase_GetServerWorldTimeSeconds_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameStateBase.GetPlayerStartTime
struct AGameStateBase_GetPlayerStartTime_Params
{
	class AController* Controller; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameStateBase.GetPlayerRespawnDelay
struct AGameStateBase_GetPlayerRespawnDelay_Params
{
	class AController* Controller; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameState.OnRep_MatchState
struct AGameState_OnRep_MatchState_Params
{
};

// Function Engine.GameState.OnRep_ElapsedTime
struct AGameState_OnRep_ElapsedTime_Params
{
};

// Function Engine.PlayerState.ReceiveOverrideWith
struct APlayerState_ReceiveOverrideWith_Params
{
	class APlayerState* OldPlayerState; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerState.ReceiveCopyProperties
struct APlayerState_ReceiveCopyProperties_Params
{
	class APlayerState* NewPlayerState; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerState.OnRep_UniqueId
struct APlayerState_OnRep_UniqueId_Params
{
};

// Function Engine.PlayerState.OnRep_Score
struct APlayerState_OnRep_Score_Params
{
};

// Function Engine.PlayerState.OnRep_PlayerName
struct APlayerState_OnRep_PlayerName_Params
{
};

// Function Engine.PlayerState.OnRep_bIsInactive
struct APlayerState_OnRep_bIsInactive_Params
{
};

// Function Engine.CameraModifier.IsDisabled
struct UCameraModifier_IsDisabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CameraModifier.GetViewTarget
struct UCameraModifier_GetViewTarget_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CameraModifier.EnableModifier
struct UCameraModifier_EnableModifier_Params
{
};

// Function Engine.CameraModifier.DisableModifier
struct UCameraModifier_DisableModifier_Params
{
	bool bImmediate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraModifier.BlueprintModifyPostProcess
struct UCameraModifier_BlueprintModifyPostProcess_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float PostProcessBlendWeight; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FPostProcessSettings PostProcessSettings; // (Parm, OutParm)
};

// Function Engine.CameraModifier.BlueprintModifyCamera
struct UCameraModifier_BlueprintModifyCamera_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ViewLocation; // (Parm, IsPlainOldData)
	struct FRotator ViewRotation; // (Parm, IsPlainOldData)
	float FOV; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewViewLocation; // (Parm, OutParm, IsPlainOldData)
	struct FRotator NewViewRotation; // (Parm, OutParm, IsPlainOldData)
	float NewFOV; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.SetCapsuleSize
struct UCapsuleComponent_SetCapsuleSize_Params
{
	float InRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	float InHalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateOverlaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.SetCapsuleRadius
struct UCapsuleComponent_SetCapsuleRadius_Params
{
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateOverlaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.SetCapsuleHalfHeight
struct UCapsuleComponent_SetCapsuleHalfHeight_Params
{
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateOverlaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetUnscaledCapsuleSize_WithoutHemisphere
struct UCapsuleComponent_GetUnscaledCapsuleSize_WithoutHemisphere_Params
{
	float OutRadius; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutHalfHeightWithoutHemisphere; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetUnscaledCapsuleSize
struct UCapsuleComponent_GetUnscaledCapsuleSize_Params
{
	float OutRadius; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutHalfHeight; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetUnscaledCapsuleRadius
struct UCapsuleComponent_GetUnscaledCapsuleRadius_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetUnscaledCapsuleHalfHeight_WithoutHemisphere
struct UCapsuleComponent_GetUnscaledCapsuleHalfHeight_WithoutHemisphere_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetUnscaledCapsuleHalfHeight
struct UCapsuleComponent_GetUnscaledCapsuleHalfHeight_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetShapeScale
struct UCapsuleComponent_GetShapeScale_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetScaledCapsuleSize_WithoutHemisphere
struct UCapsuleComponent_GetScaledCapsuleSize_WithoutHemisphere_Params
{
	float OutRadius; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutHalfHeightWithoutHemisphere; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetScaledCapsuleSize
struct UCapsuleComponent_GetScaledCapsuleSize_Params
{
	float OutRadius; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutHalfHeight; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetScaledCapsuleRadius
struct UCapsuleComponent_GetScaledCapsuleRadius_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetScaledCapsuleHalfHeight_WithoutHemisphere
struct UCapsuleComponent_GetScaledCapsuleHalfHeight_WithoutHemisphere_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CapsuleComponent.GetScaledCapsuleHalfHeight
struct UCapsuleComponent_GetScaledCapsuleHalfHeight_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.UpdateSpline
struct USplineComponent_UpdateSpline_Params
{
};

// Function Engine.SplineComponent.SetWorldLocationAtSplinePoint
struct USplineComponent_SetWorldLocationAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SplineComponent.SetUpVectorAtSplinePoint
struct USplineComponent_SetUpVectorAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InUpVector; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetUnselectedSplineSegmentColor
struct USplineComponent_SetUnselectedSplineSegmentColor_Params
{
	struct FLinearColor SegmentColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SplineComponent.SetTangentsAtSplinePoint
struct USplineComponent_SetTangentsAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InArriveTangent; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector InLeaveTangent; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetTangentAtSplinePoint
struct USplineComponent_SetTangentAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InTangent; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetSplineWorldPoints
struct USplineComponent_SetSplineWorldPoints_Params
{
	TArray<struct FVector> Points; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.SplineComponent.SetSplinePointType
struct USplineComponent_SetSplinePointType_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplinePointType> Type; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetSplinePoints
struct USplineComponent_SetSplinePoints_Params
{
	TArray<struct FVector> Points; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetSplineLocalPoints
struct USplineComponent_SetSplineLocalPoints_Params
{
	TArray<struct FVector> Points; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.SplineComponent.SetSelectedSplineSegmentColor
struct USplineComponent_SetSelectedSplineSegmentColor_Params
{
	struct FLinearColor SegmentColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SplineComponent.SetLocationAtSplinePoint
struct USplineComponent_SetLocationAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetDrawDebug
struct USplineComponent_SetDrawDebug_Params
{
	bool bShow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetDefaultUpVector
struct USplineComponent_SetDefaultUpVector_Params
{
	struct FVector UpVector; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetClosedLoopAtPosition
struct USplineComponent_SetClosedLoopAtPosition_Params
{
	bool bInClosedLoop; // (Parm, ZeroConstructor, IsPlainOldData)
	float Key; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.SetClosedLoop
struct USplineComponent_SetClosedLoop_Params
{
	bool bInClosedLoop; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.RemoveSplinePoint
struct USplineComponent_RemoveSplinePoint_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.IsClosedLoop
struct USplineComponent_IsClosedLoop_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldTangentAtDistanceAlongSpline
struct USplineComponent_GetWorldTangentAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldRotationAtTime
struct USplineComponent_GetWorldRotationAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldRotationAtDistanceAlongSpline
struct USplineComponent_GetWorldRotationAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldLocationAtTime
struct USplineComponent_GetWorldLocationAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldLocationAtSplinePoint
struct USplineComponent_GetWorldLocationAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldLocationAtDistanceAlongSpline
struct USplineComponent_GetWorldLocationAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldDirectionAtTime
struct USplineComponent_GetWorldDirectionAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetWorldDirectionAtDistanceAlongSpline
struct USplineComponent_GetWorldDirectionAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetUpVectorAtTime
struct USplineComponent_GetUpVectorAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetUpVectorAtSplinePoint
struct USplineComponent_GetUpVectorAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetUpVectorAtDistanceAlongSpline
struct USplineComponent_GetUpVectorAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetTransformAtTime
struct USplineComponent_GetTransformAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseScale; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetTransformAtSplinePoint
struct USplineComponent_GetTransformAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseScale; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetTransformAtDistanceAlongSpline
struct USplineComponent_GetTransformAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseScale; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetTangentAtTime
struct USplineComponent_GetTangentAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetTangentAtSplinePoint
struct USplineComponent_GetTangentAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetTangentAtDistanceAlongSpline
struct USplineComponent_GetTangentAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetSplinePointType
struct USplineComponent_GetSplinePointType_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplinePointType> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetSplineLength
struct USplineComponent_GetSplineLength_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetScaleAtTime
struct USplineComponent_GetScaleAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetScaleAtSplinePoint
struct USplineComponent_GetScaleAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetScaleAtDistanceAlongSpline
struct USplineComponent_GetScaleAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRotationAtTime
struct USplineComponent_GetRotationAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRotationAtSplinePoint
struct USplineComponent_GetRotationAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRotationAtDistanceAlongSpline
struct USplineComponent_GetRotationAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRollAtTime
struct USplineComponent_GetRollAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRollAtSplinePoint
struct USplineComponent_GetRollAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRollAtDistanceAlongSpline
struct USplineComponent_GetRollAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRightVectorAtTime
struct USplineComponent_GetRightVectorAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRightVectorAtSplinePoint
struct USplineComponent_GetRightVectorAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetRightVectorAtDistanceAlongSpline
struct USplineComponent_GetRightVectorAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetNumberOfSplinePoints
struct USplineComponent_GetNumberOfSplinePoints_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetLocationAtTime
struct USplineComponent_GetLocationAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetLocationAtSplinePoint
struct USplineComponent_GetLocationAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetLocationAtDistanceAlongSpline
struct USplineComponent_GetLocationAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetLocationAndTangentAtSplinePoint
struct USplineComponent_GetLocationAndTangentAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, OutParm, IsPlainOldData)
	struct FVector Tangent; // (Parm, OutParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.GetLocationAndRotationAtDistanceAlongSpline
struct USplineComponent_GetLocationAndRotationAtDistanceAlongSpline_Params
{
	struct FRotator OutRotation; // (Parm, OutParm, IsPlainOldData)
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetLocalLocationAndTangentAtSplinePoint
struct USplineComponent_GetLocalLocationAndTangentAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector LocalLocation; // (Parm, OutParm, IsPlainOldData)
	struct FVector LocalTangent; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetLeaveTangentAtSplinePoint
struct USplineComponent_GetLeaveTangentAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetInputKeyAtDistanceAlongSpline
struct USplineComponent_GetInputKeyAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetDistanceAlongSplineAtSplinePoint
struct USplineComponent_GetDistanceAlongSplineAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetDistanceAlongSplineAtSplineInputKey
struct USplineComponent_GetDistanceAlongSplineAtSplineInputKey_Params
{
	float InKey; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetDirectionAtTime
struct USplineComponent_GetDirectionAtTime_Params
{
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseConstantVelocity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetDirectionAtSplinePoint
struct USplineComponent_GetDirectionAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetDirectionAtDistanceAlongSpline
struct USplineComponent_GetDirectionAtDistanceAlongSpline_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetDefaultUpVector
struct USplineComponent_GetDefaultUpVector_Params
{
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetCurvatureAtSplinePoint
struct USplineComponent_GetCurvatureAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetCurvatureAtDistance
struct USplineComponent_GetCurvatureAtDistance_Params
{
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.GetArriveTangentAtSplinePoint
struct USplineComponent_GetArriveTangentAtSplinePoint_Params
{
	int PointIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindUpVectorClosestToWorldLocation
struct USplineComponent_FindUpVectorClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindTransformClosestToWorldLocation
struct USplineComponent_FindTransformClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseScale; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindTangentClosestToWorldLocation
struct USplineComponent_FindTangentClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindScaleClosestToWorldLocation
struct USplineComponent_FindScaleClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindRotationClosestToWorldLocation
struct USplineComponent_FindRotationClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindRollClosestToWorldLocation
struct USplineComponent_FindRollClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindRightVectorClosestToWorldLocation
struct USplineComponent_FindRightVectorClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindLocationClosestToWorldLocation
struct USplineComponent_FindLocationClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindInputKeyClosestToWorldLocation
struct USplineComponent_FindInputKeyClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.FindDirectionClosestToWorldLocation
struct USplineComponent_FindDirectionClosestToWorldLocation_Params
{
	struct FVector WorldLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponent.ClearSplinePoints
struct USplineComponent_ClearSplinePoints_Params
{
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.AddSplineWorldPoint
struct USplineComponent_AddSplineWorldPoint_Params
{
	struct FVector Position; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SplineComponent.AddSplinePointAtIndex
struct USplineComponent_AddSplinePointAtIndex_Params
{
	struct FVector Position; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.AddSplinePoint
struct USplineComponent_AddSplinePoint_Params
{
	struct FVector Position; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum ESplineCoordinateSpace> CoordinateSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.AddSplineLocalPoint
struct USplineComponent_AddSplineLocalPoint_Params
{
	struct FVector Position; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SplineComponent.AddPoints
struct USplineComponent_AddPoints_Params
{
	TArray<struct FSplinePoint> Points; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineComponent.AddPoint
struct USplineComponent_AddPoint_Params
{
	struct FSplinePoint Point; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bUpdateSpline; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetUseFieldOfViewForLOD
struct UCameraComponent_SetUseFieldOfViewForLOD_Params
{
	bool bInUseFieldOfViewForLOD; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetProjectionMode
struct UCameraComponent_SetProjectionMode_Params
{
	TEnumAsByte<enum ECameraProjectionMode> InProjectionMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetPostProcessBlendWeight
struct UCameraComponent_SetPostProcessBlendWeight_Params
{
	float InPostProcessBlendWeight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetOrthoWidth
struct UCameraComponent_SetOrthoWidth_Params
{
	float InOrthoWidth; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetOrthoNearClipPlane
struct UCameraComponent_SetOrthoNearClipPlane_Params
{
	float InOrthoNearClipPlane; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetOrthoFarClipPlane
struct UCameraComponent_SetOrthoFarClipPlane_Params
{
	float InOrthoFarClipPlane; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetFieldOfView
struct UCameraComponent_SetFieldOfView_Params
{
	float InFieldOfView; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetConstraintAspectRatio
struct UCameraComponent_SetConstraintAspectRatio_Params
{
	bool bInConstrainAspectRatio; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetAutoFixFovByAspectRatio
struct UCameraComponent_SetAutoFixFovByAspectRatio_Params
{
	bool bInAutoFixFovByAspectRatio; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetAspectRatio
struct UCameraComponent_SetAspectRatio_Params
{
	float InAspectRatio; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.SetActive
struct UCameraComponent_SetActive_Params
{
	bool bNewActive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bReset; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.RemoveBlendable
struct UCameraComponent_RemoveBlendable_Params
{
	TScriptInterface<class UBlendableInterface> InBlendableObject; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.OnViewportSizeChanged
struct UCameraComponent_OnViewportSizeChanged_Params
{
	struct FVector2D OldViewportSize; // (Parm, IsPlainOldData)
	struct FVector2D NewViewportSize; // (Parm, IsPlainOldData)
};

// Function Engine.CameraComponent.GetCameraView
struct UCameraComponent_GetCameraView_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FMinimalViewInfo DesiredView; // (Parm, OutParm)
};

// Function Engine.CameraComponent.ApplyDrawDistanceOffset
struct UCameraComponent_ApplyDrawDistanceOffset_Params
{
	float InFieldOfView; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraComponent.AddOrUpdateBlendable
struct UCameraComponent_AddOrUpdateBlendable_Params
{
	TScriptInterface<class UBlendableInterface> InBlendableObject; // (Parm, ZeroConstructor, IsPlainOldData)
	float InWeight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.FXSystemComponent.SetVectorParameter
struct UFXSystemComponent_SetVectorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Param; // (Parm, IsPlainOldData)
};

// Function Engine.FXSystemComponent.SetFloatParameter
struct UFXSystemComponent_SetFloatParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.FXSystemComponent.SetColorParameter
struct UFXSystemComponent_SetColorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor Param; // (Parm, IsPlainOldData)
};

// Function Engine.FXSystemComponent.SetActorParameter
struct UFXSystemComponent_SetActorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetVectorParameter
struct UParticleSystemComponent_SetVectorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Param; // (Parm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetVectorCurveParameter
struct UParticleSystemComponent_SetVectorCurveParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FInterpCurveVector InCurve; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bMaterialParam; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetTrailSourceData
struct UParticleSystemComponent_SetTrailSourceData_Params
{
	struct FName InFirstSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName InSecondSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETrailWidthMode> InWidthMode; // (Parm, ZeroConstructor, IsPlainOldData)
	float InWidth; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetTemplate
struct UParticleSystemComponent_SetTemplate_Params
{
	class UParticleSystem* NewTemplate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetSocketName
struct UParticleSystemComponent_SetSocketName_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetMultiCurveActiveIndex
struct UParticleSystemComponent_SetMultiCurveActiveIndex_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	int ActiveIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bNeedResetParticles; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetMaterialParameter
struct UParticleSystemComponent_SetMaterialParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetLODLevel
struct UParticleSystemComponent_SetLODLevel_Params
{
	int InLODLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetFloatParameter
struct UParticleSystemComponent_SetFloatParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetFloatCurveParameter
struct UParticleSystemComponent_SetFloatCurveParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FInterpCurveFloat InCurve; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bMaterialParam; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetEmitterEnable
struct UParticleSystemComponent_SetEmitterEnable_Params
{
	struct FName EmitterName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bNewEnableState; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetColorParameter
struct UParticleSystemComponent_SetColorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor Param; // (Parm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetColorCurveParameter
struct UParticleSystemComponent_SetColorCurveParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FInterpCurveLinearColor InCurve; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bMaterialParam; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetBeamTargetTangent
struct UParticleSystemComponent_SetBeamTargetTangent_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewTangentPoint; // (Parm, IsPlainOldData)
	int TargetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetBeamTargetStrength
struct UParticleSystemComponent_SetBeamTargetStrength_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float NewTargetStrength; // (Parm, ZeroConstructor, IsPlainOldData)
	int TargetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetBeamTargetPoint
struct UParticleSystemComponent_SetBeamTargetPoint_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewTargetPoint; // (Parm, IsPlainOldData)
	int TargetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetBeamSourceTangent
struct UParticleSystemComponent_SetBeamSourceTangent_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewTangentPoint; // (Parm, IsPlainOldData)
	int SourceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetBeamSourceStrength
struct UParticleSystemComponent_SetBeamSourceStrength_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float NewSourceStrength; // (Parm, ZeroConstructor, IsPlainOldData)
	int SourceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetBeamSourcePoint
struct UParticleSystemComponent_SetBeamSourcePoint_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewSourcePoint; // (Parm, IsPlainOldData)
	int SourceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetBeamEndPoint
struct UParticleSystemComponent_SetBeamEndPoint_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewEndPoint; // (Parm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetAutoAttachParams
struct UParticleSystemComponent_SetAutoAttachParams_Params
{
	class USceneComponent* Parent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName SocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> LocationType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetAutoAttachmentParameters
struct UParticleSystemComponent_SetAutoAttachmentParameters_Params
{
	class USceneComponent* Parent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName SocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule LocationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule RotationRule; // (Parm, ZeroConstructor, IsPlainOldData)
	EAttachmentRule ScaleRule; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.SetActorParameter
struct UParticleSystemComponent_SetActorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.RemoveCurveParameter
struct UParticleSystemComponent_RemoveCurveParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.OnMaterialLoaded
struct UParticleSystemComponent_OnMaterialLoaded_Params
{
	class UMaterialInterface* MaterialInstance; // (Parm, ZeroConstructor, IsPlainOldData)
	int ElementIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetTemplate
struct UParticleSystemComponent_GetTemplate_Params
{
	class UParticleSystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetPerformanceScore
struct UParticleSystemComponent_GetPerformanceScore_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetNumActiveParticles
struct UParticleSystemComponent_GetNumActiveParticles_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetNamedMaterial
struct UParticleSystemComponent_GetNamedMaterial_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetLODLevel
struct UParticleSystemComponent_GetLODLevel_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetBeamTargetTangent
struct UParticleSystemComponent_GetBeamTargetTangent_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int TargetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector OutTangentPoint; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetBeamTargetStrength
struct UParticleSystemComponent_GetBeamTargetStrength_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int TargetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float OutTargetStrength; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetBeamTargetPoint
struct UParticleSystemComponent_GetBeamTargetPoint_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int TargetIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector OutTargetPoint; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetBeamSourceTangent
struct UParticleSystemComponent_GetBeamSourceTangent_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int SourceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector OutTangentPoint; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetBeamSourceStrength
struct UParticleSystemComponent_GetBeamSourceStrength_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int SourceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float OutSourceStrength; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetBeamSourcePoint
struct UParticleSystemComponent_GetBeamSourcePoint_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int SourceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector OutSourcePoint; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GetBeamEndPoint
struct UParticleSystemComponent_GetBeamEndPoint_Params
{
	int EmitterIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector OutEndPoint; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.GenerateParticleEvent
struct UParticleSystemComponent_GenerateParticleEvent_Params
{
	struct FName InEventName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float InEmitterTime; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InLocation; // (ConstParm, Parm, IsPlainOldData)
	struct FVector InDirection; // (ConstParm, Parm, IsPlainOldData)
	struct FVector InVelocity; // (ConstParm, Parm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.EndTrails
struct UParticleSystemComponent_EndTrails_Params
{
};

// Function Engine.ParticleSystemComponent.CreateNamedDynamicMaterialInstanceAsync
struct UParticleSystemComponent_CreateNamedDynamicMaterialInstanceAsync_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate MaterialInstCallback; // (Parm, ZeroConstructor)
	class UMaterialInterface* SourceMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.CreateNamedDynamicMaterialInstance
struct UParticleSystemComponent_CreateNamedDynamicMaterialInstance_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* SourceMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystemComponent.BeginTrails
struct UParticleSystemComponent_BeginTrails_Params
{
	struct FName InFirstSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName InSecondSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETrailWidthMode> InWidthMode; // (Parm, ZeroConstructor, IsPlainOldData)
	float InWidth; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SphereComponent.SetSphereRadius
struct USphereComponent_SetSphereRadius_Params
{
	float InSphereRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateOverlaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SphereComponent.GetUnscaledSphereRadius
struct USphereComponent_GetUnscaledSphereRadius_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SphereComponent.GetShapeScale
struct USphereComponent_GetShapeScale_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SphereComponent.GetScaledSphereRadius
struct USphereComponent_GetScaledSphereRadius_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SpringArmComponent.SetActive
struct USpringArmComponent_SetActive_Params
{
	bool bNewActive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bReset; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SpringArmComponent.GetTargetRotation
struct USpringArmComponent_GetTargetRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingActor.SetMaxDecalProcessPerFame
struct ADecalBakingActor_SetMaxDecalProcessPerFame_Params
{
	int InValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalBakingActor.OnBakingFinished
struct ADecalBakingActor_OnBakingFinished_Params
{
	class UTextureRenderTarget2D* InRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalBakingActor.GetMaxDecalProcessPerFame
struct ADecalBakingActor_GetMaxDecalProcessPerFame_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingActor.FindDecalBakingRequestID
struct ADecalBakingActor_FindDecalBakingRequestID_Params
{
	class UTextureRenderTarget2D* RenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingActor.EndDecalBakingCache
struct ADecalBakingActor_EndDecalBakingCache_Params
{
	class UTextureRenderTarget2D* RenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalBakingActor.DoCompression
struct ADecalBakingActor_DoCompression_Params
{
	class UTextureRenderTarget2D* InRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalBakingActor.CompressTexture
struct ADecalBakingActor_CompressTexture_Params
{
	class UTextureRenderTarget2D* InRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bInRGBA; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUsePunchthroughAlpha; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseOptimizeOpaque; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingActor.CancelDecalBakingRequest
struct ADecalBakingActor_CancelDecalBakingRequest_Params
{
	int RequestID; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalBakingActor.BeginDecalBakingCache
struct ADecalBakingActor_BeginDecalBakingCache_Params
{
	class UTextureRenderTarget2D* RenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalBakingActor.BakeDecalForStaticMesh
struct ADecalBakingActor_BakeDecalForStaticMesh_Params
{
	class UTextureRenderTarget2D* RenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	class UStaticMesh* StaticMesh; // (Parm, ZeroConstructor, IsPlainOldData)
	int UVIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FDecalParameter> InDecalParams; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bIntermidiate; // (Parm, ZeroConstructor, IsPlainOldData)
	int CachedDecalIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingActor.BakeDecalForSkeletalMesh
struct ADecalBakingActor_BakeDecalForSkeletalMesh_Params
{
	class UTextureRenderTarget2D* RenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	class USkeletalMesh* SkeletalMesh; // (Parm, ZeroConstructor, IsPlainOldData)
	int UVIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FDecalParameter> InDecalParams; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bIntermidiate; // (Parm, ZeroConstructor, IsPlainOldData)
	int CachedDecalIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int SectionIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* OriginTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InterpToMovementComponent.StopSimulating
struct UInterpToMovementComponent_StopSimulating_Params
{
	struct FHitResult HitResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.InterpToMovementComponent.RestartMovement
struct UInterpToMovementComponent_RestartMovement_Params
{
	float InitialDirection; // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Engine.InterpToMovementComponent.OnInterpToWaitEndDelegate__DelegateSignature
struct UInterpToMovementComponent_OnInterpToWaitEndDelegate__DelegateSignature_Params
{
	struct FHitResult ImpactResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Engine.InterpToMovementComponent.OnInterpToWaitBeginDelegate__DelegateSignature
struct UInterpToMovementComponent_OnInterpToWaitBeginDelegate__DelegateSignature_Params
{
	struct FHitResult ImpactResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Engine.InterpToMovementComponent.OnInterpToStopDelegate__DelegateSignature
struct UInterpToMovementComponent_OnInterpToStopDelegate__DelegateSignature_Params
{
	struct FHitResult ImpactResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Engine.InterpToMovementComponent.OnInterpToReverseDelegate__DelegateSignature
struct UInterpToMovementComponent_OnInterpToReverseDelegate__DelegateSignature_Params
{
	struct FHitResult ImpactResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Engine.InterpToMovementComponent.OnInterpToResetDelegate__DelegateSignature
struct UInterpToMovementComponent_OnInterpToResetDelegate__DelegateSignature_Params
{
	struct FHitResult ImpactResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InterpToMovementComponent.FinaliseControlPoints
struct UInterpToMovementComponent_FinaliseControlPoints_Params
{
};

// Function Engine.LevelScriptActor.WorldOriginLocationChanged
struct ALevelScriptActor_WorldOriginLocationChanged_Params
{
	struct FIntVector OldOriginLocation; // (Parm, IsPlainOldData)
	struct FIntVector NewOriginLocation; // (Parm, IsPlainOldData)
};

// Function Engine.LevelScriptActor.SetCinematicMode
struct ALevelScriptActor_SetCinematicMode_Params
{
	bool bCinematicMode; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bHidePlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsHUD; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsMovement; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsTurning; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LevelScriptActor.RemoteEvent
struct ALevelScriptActor_RemoteEvent_Params
{
	struct FName EventName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelScriptActor.LevelReset
struct ALevelScriptActor_LevelReset_Params
{
};

// Function Engine.NavLinkProxy.SetSmartLinkEnabled
struct ANavLinkProxy_SetSmartLinkEnabled_Params
{
	bool bEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavLinkProxy.ResumePathFollowing
struct ANavLinkProxy_ResumePathFollowing_Params
{
	class AActor* Agent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavLinkProxy.ReceiveSmartLinkReached
struct ANavLinkProxy_ReceiveSmartLinkReached_Params
{
	class AActor* Agent; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Destination; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.NavLinkProxy.IsSmartLinkEnabled
struct ANavLinkProxy_IsSmartLinkEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavLinkProxy.HasMovingAgents
struct ANavLinkProxy_HasMovingAgents_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetStaticMesh
struct UStaticMeshComponent_SetStaticMesh_Params
{
	class UStaticMesh* NewMesh; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetRenderInCustomPass
struct UStaticMeshComponent_SetRenderInCustomPass_Params
{
	bool InRenderInCustomPass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetOverrideCullingScreenSizeEnable
struct UStaticMeshComponent_SetOverrideCullingScreenSizeEnable_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetOverrideCullingScreenSize
struct UStaticMeshComponent_SetOverrideCullingScreenSize_Params
{
	float ScreenSize; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetLowDeviceForcedLodModel
struct UStaticMeshComponent_SetLowDeviceForcedLodModel_Params
{
	int NewLowDeviceForcedLodModel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetForceSyncCreatePSO
struct UStaticMeshComponent_SetForceSyncCreatePSO_Params
{
	bool InForceSyncCreatePSO; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetForcedLodModel
struct UStaticMeshComponent_SetForcedLodModel_Params
{
	int NewForcedLodModel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetDrawStyle
struct UStaticMeshComponent_SetDrawStyle_Params
{
	TEnumAsByte<enum EDrawStyleMode> InDrawStyle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetDistanceFieldSelfShadowBias
struct UStaticMeshComponent_SetDistanceFieldSelfShadowBias_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.SetDirty
struct UStaticMeshComponent_SetDirty_Params
{
};

// Function Engine.StaticMeshComponent.OnRep_StaticMesh
struct UStaticMeshComponent_OnRep_StaticMesh_Params
{
	class UStaticMesh* OldStaticMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.GetRenderInCustomPass
struct UStaticMeshComponent_GetRenderInCustomPass_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.GetLocalBounds
struct UStaticMeshComponent_GetLocalBounds_Params
{
	struct FVector Min; // (Parm, OutParm, IsPlainOldData)
	struct FVector Max; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.GetForceSyncCreatePSO
struct UStaticMeshComponent_GetForceSyncCreatePSO_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.GetDrawStyle
struct UStaticMeshComponent_GetDrawStyle_Params
{
	TEnumAsByte<enum EDrawStyleMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.EnableMeshClipPlane
struct UStaticMeshComponent_EnableMeshClipPlane_Params
{
	struct FPlane ClipPlane; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int PlaneIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.EnableMeshClipArc
struct UStaticMeshComponent_EnableMeshClipArc_Params
{
	struct FPlane ClipPlane; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector4 ClipSphere; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.EnableMeshClip4Planes
struct UStaticMeshComponent_EnableMeshClip4Planes_Params
{
	TArray<struct FPlane> ClipPlanes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bBox; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.DisableMeshClipPlane
struct UStaticMeshComponent_DisableMeshClipPlane_Params
{
	int PlaneIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMeshComponent.DisableMeshClipArc
struct UStaticMeshComponent_DisableMeshClipArc_Params
{
};

// Function Engine.StaticMeshComponent.DisableMeshClip4Planes
struct UStaticMeshComponent_DisableMeshClip4Planes_Params
{
};

// Function Engine.CharacterMovementComponent.SetWalkableFloorZ
struct UCharacterMovementComponent_SetWalkableFloorZ_Params
{
	float InWalkableFloorZ; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetWalkableFloorAngle
struct UCharacterMovementComponent_SetWalkableFloorAngle_Params
{
	float InWalkableFloorAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetMovementMode
struct UCharacterMovementComponent_SetMovementMode_Params
{
	TEnumAsByte<enum EMovementMode> NewMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char NewCustomMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetGroupsToIgnoreMask
struct UCharacterMovementComponent_SetGroupsToIgnoreMask_Params
{
	struct FNavAvoidanceMask GroupMask; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetGroupsToIgnore
struct UCharacterMovementComponent_SetGroupsToIgnore_Params
{
	int GroupFlags; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetGroupsToAvoidMask
struct UCharacterMovementComponent_SetGroupsToAvoidMask_Params
{
	struct FNavAvoidanceMask GroupMask; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetGroupsToAvoid
struct UCharacterMovementComponent_SetGroupsToAvoid_Params
{
	int GroupFlags; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetAvoidanceGroupMask
struct UCharacterMovementComponent_SetAvoidanceGroupMask_Params
{
	struct FNavAvoidanceMask GroupMask; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetAvoidanceGroup
struct UCharacterMovementComponent_SetAvoidanceGroup_Params
{
	int GroupFlags; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.SetAvoidanceEnabled
struct UCharacterMovementComponent_SetAvoidanceEnabled_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ServerMoveOld
struct UCharacterMovementComponent_ServerMoveOld_Params
{
	float OldTimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10 OldAccel; // (Parm)
	unsigned char OldMoveFlags; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ServerMoveDualHybridRootMotion
struct UCharacterMovementComponent_ServerMoveDualHybridRootMotion_Params
{
	float TimeStamp0; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10 InAccel0; // (Parm)
	unsigned char PendingFlags; // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t View0; // (Parm, ZeroConstructor, IsPlainOldData)
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10 InAccel; // (Parm)
	struct FVector_NetQuantize100 ClientLoc; // (Parm)
	unsigned char NewFlags; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ClientRoll; // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t View; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* ClientMovementBase; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName ClientBaseBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ClientMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ServerMoveDual
struct UCharacterMovementComponent_ServerMoveDual_Params
{
	float TimeStamp0; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10 InAccel0; // (Parm)
	unsigned char PendingFlags; // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t View0; // (Parm, ZeroConstructor, IsPlainOldData)
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10 InAccel; // (Parm)
	struct FVector_NetQuantize100 ClientLoc; // (Parm)
	unsigned char NewFlags; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ClientRoll; // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t View; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* ClientMovementBase; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName ClientBaseBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ClientMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ServerMove
struct UCharacterMovementComponent_ServerMove_Params
{
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10 InAccel; // (Parm)
	struct FVector_NetQuantize100 ClientLoc; // (Parm)
	unsigned char CompressedMoveFlags; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ClientRoll; // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t View; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* ClientMovementBase; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName ClientBaseBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ClientMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.K2_GetWalkableFloorZ
struct UCharacterMovementComponent_K2_GetWalkableFloorZ_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.K2_GetWalkableFloorAngle
struct UCharacterMovementComponent_K2_GetWalkableFloorAngle_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.K2_GetModifiedMaxAcceleration
struct UCharacterMovementComponent_K2_GetModifiedMaxAcceleration_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.K2_FindFloor
struct UCharacterMovementComponent_K2_FindFloor_Params
{
	struct FVector CapsuleLocation; // (Parm, IsPlainOldData)
	struct FFindFloorResult FloorResult; // (Parm, OutParm)
};

// Function Engine.CharacterMovementComponent.K2_ComputeFloorDist
struct UCharacterMovementComponent_K2_ComputeFloorDist_Params
{
	struct FVector CapsuleLocation; // (Parm, IsPlainOldData)
	float LineDistance; // (Parm, ZeroConstructor, IsPlainOldData)
	float SweepDistance; // (Parm, ZeroConstructor, IsPlainOldData)
	float SweepRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FFindFloorResult FloorResult; // (Parm, OutParm)
};

// Function Engine.CharacterMovementComponent.IsWalking
struct UCharacterMovementComponent_IsWalking_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.IsWalkable
struct UCharacterMovementComponent_IsWalkable_Params
{
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetValidPerchRadius
struct UCharacterMovementComponent_GetValidPerchRadius_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetPerchRadiusThreshold
struct UCharacterMovementComponent_GetPerchRadiusThreshold_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetMovementBase
struct UCharacterMovementComponent_GetMovementBase_Params
{
	class UPrimitiveComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetMinAnalogSpeed
struct UCharacterMovementComponent_GetMinAnalogSpeed_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetMaxJumpHeightWithJumpTime
struct UCharacterMovementComponent_GetMaxJumpHeightWithJumpTime_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetMaxJumpHeight
struct UCharacterMovementComponent_GetMaxJumpHeight_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetMaxBrakingDeceleration
struct UCharacterMovementComponent_GetMaxBrakingDeceleration_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetMaxAcceleration
struct UCharacterMovementComponent_GetMaxAcceleration_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetImpartedMovementBaseVelocity
struct UCharacterMovementComponent_GetImpartedMovementBaseVelocity_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetCurrentAcceleration
struct UCharacterMovementComponent_GetCurrentAcceleration_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetCharacterOwner
struct UCharacterMovementComponent_GetCharacterOwner_Params
{
	class ACharacter* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.GetAnalogInputModifier
struct UCharacterMovementComponent_GetAnalogInputModifier_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.FlushServerMoves
struct UCharacterMovementComponent_FlushServerMoves_Params
{
};

// Function Engine.CharacterMovementComponent.DisableMovement
struct UCharacterMovementComponent_DisableMovement_Params
{
};

// Function Engine.CharacterMovementComponent.ClientVeryShortAdjustPosition
struct UCharacterMovementComponent_ClientVeryShortAdjustPosition_Params
{
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewLoc; // (Parm, IsPlainOldData)
	class UPrimitiveComponent* NewBase; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName NewBaseBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bHasBase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bBaseRelativePosition; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ServerMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ClientAdjustRootMotionSourcePosition
struct UCharacterMovementComponent_ClientAdjustRootMotionSourcePosition_Params
{
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRootMotionSourceGroup ServerRootMotion; // (Parm)
	bool bHasAnimRootMotion; // (Parm, ZeroConstructor, IsPlainOldData)
	float ServerMontageTrackPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ServerLoc; // (Parm, IsPlainOldData)
	struct FVector_NetQuantizeNormal ServerRotation; // (Parm)
	float ServerVelZ; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* ServerBase; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName ServerBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bHasBase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bBaseRelativePosition; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ServerMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ClientAdjustRootMotionPosition
struct UCharacterMovementComponent_ClientAdjustRootMotionPosition_Params
{
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	float ServerMontageTrackPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ServerLoc; // (Parm, IsPlainOldData)
	struct FVector_NetQuantizeNormal ServerRotation; // (Parm)
	float ServerVelZ; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* ServerBase; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName ServerBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bHasBase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bBaseRelativePosition; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ServerMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ClientAdjustPosition
struct UCharacterMovementComponent_ClientAdjustPosition_Params
{
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewLoc; // (Parm, IsPlainOldData)
	struct FVector NewVel; // (Parm, IsPlainOldData)
	class UPrimitiveComponent* NewBase; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName NewBaseBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bHasBase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bBaseRelativePosition; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ServerMovementMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ClientAckGoodMove
struct UCharacterMovementComponent_ClientAckGoodMove_Params
{
	float TimeStamp; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.ClearAccumulatedForces
struct UCharacterMovementComponent_ClearAccumulatedForces_Params
{
};

// Function Engine.CharacterMovementComponent.CapsuleTouched
struct UCharacterMovementComponent_CapsuleTouched_Params
{
	class UPrimitiveComponent* OverlappedComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class AActor* Other; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* OtherComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	int OtherBodyIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFromSweep; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult SweepResult; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.CalcVelocity
struct UCharacterMovementComponent_CalcVelocity_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float Friction; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFluid; // (Parm, ZeroConstructor, IsPlainOldData)
	float BrakingDeceleration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.AddImpulse
struct UCharacterMovementComponent_AddImpulse_Params
{
	struct FVector Impulse; // (Parm, IsPlainOldData)
	bool bVelocityChange; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CharacterMovementComponent.AddForce
struct UCharacterMovementComponent_AddForce_Params
{
	struct FVector Force; // (Parm, IsPlainOldData)
};

// Function Engine.CameraShake.ReceiveStopShake
struct UCameraShake_ReceiveStopShake_Params
{
	bool bImmediately; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraShake.ReceivePlayShake
struct UCameraShake_ReceivePlayShake_Params
{
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraShake.ReceiveIsFinished
struct UCameraShake_ReceiveIsFinished_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CameraShake.BlueprintUpdateCameraShake
struct UCameraShake_BlueprintUpdateCameraShake_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FMinimalViewInfo POV; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FMinimalViewInfo ModifiedPOV; // (Parm, OutParm)
};

// Function Engine.NetDriver.SetFunctionEligibleForSharedSerializationByName
struct UNetDriver_SetFunctionEligibleForSharedSerializationByName_Params
{
	class UClass* Class; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
	bool bEligible; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NetDriver.PrintRPCFunctionCallInfo
struct UNetDriver_PrintRPCFunctionCallInfo_Params
{
};

// Function Engine.GameplayStatics.UnloadStreamLevel
struct UGameplayStatics_UnloadStreamLevel_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName LevelName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.GameplayStatics.UnloadAllStreamLevel
struct UGameplayStatics_UnloadAllStreamLevel_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SuggestProjectileVelocity_CustomArc
struct UGameplayStatics_SuggestProjectileVelocity_CustomArc_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector OutLaunchVelocity; // (Parm, OutParm, IsPlainOldData)
	struct FVector StartPos; // (Parm, IsPlainOldData)
	struct FVector EndPos; // (Parm, IsPlainOldData)
	float OverrideGravityZ; // (Parm, ZeroConstructor, IsPlainOldData)
	float ArcParam; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnSoundAttached
struct UGameplayStatics_SpawnSoundAttached_Params
{
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	class USceneComponent* AttachToComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName AttachPointName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> LocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bStopWhenAttachedToDestroyed; // (Parm, ZeroConstructor, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundConcurrency* ConcurrencySettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAudioComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnSoundAtLocation
struct UGameplayStatics_SpawnSoundAtLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundConcurrency* ConcurrencySettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAudioComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnSound2D
struct UGameplayStatics_SpawnSound2D_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundConcurrency* ConcurrencySettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPersistAcrossLevelTransition; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAudioComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnObject
struct UGameplayStatics_SpawnObject_Params
{
	class UClass* ObjectClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* Outer; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnForceFeedbackAttached
struct UGameplayStatics_SpawnForceFeedbackAttached_Params
{
	class UForceFeedbackEffect* ForceFeedbackEffect; // (Parm, ZeroConstructor, IsPlainOldData)
	class USceneComponent* AttachToComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName AttachPointName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> LocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bStopWhenAttachedToDestroyed; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	float IntensityMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class UForceFeedbackAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UForceFeedbackComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnForceFeedbackAtLocation
struct UGameplayStatics_SpawnForceFeedbackAtLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UForceFeedbackEffect* ForceFeedbackEffect; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	bool bLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	float IntensityMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class UForceFeedbackAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UForceFeedbackComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnEmitterAttachedToActor
struct UGameplayStatics_SpawnEmitterAttachedToActor_Params
{
	class UParticleSystem* EmitterTemplate; // (Parm, ZeroConstructor, IsPlainOldData)
	class USceneComponent* AttachToComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName AttachPointName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	struct FVector Scale; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> LocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UParticleSystemComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnEmitterAttached
struct UGameplayStatics_SpawnEmitterAttached_Params
{
	class UParticleSystem* EmitterTemplate; // (Parm, ZeroConstructor, IsPlainOldData)
	class USceneComponent* AttachToComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName AttachPointName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	struct FVector Scale; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> LocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UParticleSystemComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnEmitterAtLocation
struct UGameplayStatics_SpawnEmitterAtLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UParticleSystem* EmitterTemplate; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	struct FVector Scale; // (Parm, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UParticleSystemComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnDialogueAttached
struct UGameplayStatics_SpawnDialogueAttached_Params
{
	class UDialogueWave* Dialogue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDialogueContext Context; // (ConstParm, Parm, OutParm, ReferenceParm)
	class USceneComponent* AttachToComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName AttachPointName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> LocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bStopWhenAttachedToDestroyed; // (Parm, ZeroConstructor, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAudioComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnDialogueAtLocation
struct UGameplayStatics_SpawnDialogueAtLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UDialogueWave* Dialogue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDialogueContext Context; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAudioComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnDialogue2D
struct UGameplayStatics_SpawnDialogue2D_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UDialogueWave* Dialogue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDialogueContext Context; // (ConstParm, Parm, OutParm, ReferenceParm)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAudioComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnDecalAttached
struct UGameplayStatics_SpawnDecalAttached_Params
{
	class UMaterialInterface* DecalMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector DecalSize; // (Parm, IsPlainOldData)
	class USceneComponent* AttachToComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName AttachPointName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EAttachLocation> LocationType; // (Parm, ZeroConstructor, IsPlainOldData)
	float LifeSpan; // (Parm, ZeroConstructor, IsPlainOldData)
	class UDecalComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SpawnDecalAtLocation
struct UGameplayStatics_SpawnDecalAtLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* DecalMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector DecalSize; // (Parm, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	float LifeSpan; // (Parm, ZeroConstructor, IsPlainOldData)
	class UDecalComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetWorldOriginLocation
struct UGameplayStatics_SetWorldOriginLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FIntVector NewLocation; // (Parm, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetSubtitlesEnabled
struct UGameplayStatics_SetSubtitlesEnabled_Params
{
	bool bEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetSoundMixClassOverride
struct UGameplayStatics_SetSoundMixClassOverride_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundMix* InSoundMixModifier; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundClass* InSoundClass; // (Parm, ZeroConstructor, IsPlainOldData)
	float Volume; // (Parm, ZeroConstructor, IsPlainOldData)
	float Pitch; // (Parm, ZeroConstructor, IsPlainOldData)
	float FadeInTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bApplyToChildren; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetPlayerControllerID
struct UGameplayStatics_SetPlayerControllerID_Params
{
	class APlayerController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	int ControllerId; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetGlobalTimeDilation
struct UGameplayStatics_SetGlobalTimeDilation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float TimeDilation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetGlobalPitchModulation
struct UGameplayStatics_SetGlobalPitchModulation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float PitchModulation; // (Parm, ZeroConstructor, IsPlainOldData)
	float TimeSec; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetGlobalListenerFocusParameters
struct UGameplayStatics_SetGlobalListenerFocusParameters_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float FocusAzimuthScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float NonFocusAzimuthScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float FocusDistanceScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float NonFocusDistanceScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float FocusVolumeScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float NonFocusVolumeScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float FocusPriorityScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float NonFocusPriorityScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetGamePaused
struct UGameplayStatics_SetGamePaused_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool bPaused; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.SetBaseSoundMix
struct UGameplayStatics_SetBaseSoundMix_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundMix* InSoundMix; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.SaveGameToSlot
struct UGameplayStatics_SaveGameToSlot_Params
{
	class USaveGame* SaveGameObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString SlotName; // (Parm, ZeroConstructor)
	int UserIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.RestartShaderPrecompile
struct UGameplayStatics_RestartShaderPrecompile_Params
{
};

// Function Engine.GameplayStatics.RemovePlayer
struct UGameplayStatics_RemovePlayer_Params
{
	class APlayerController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDestroyPawn; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.RebaseZeroOriginOntoLocal
struct UGameplayStatics_RebaseZeroOriginOntoLocal_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector WorldLocation; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.RebaseLocalOriginOntoZero
struct UGameplayStatics_RebaseLocalOriginOntoZero_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector WorldLocation; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.PushSoundMixModifier
struct UGameplayStatics_PushSoundMixModifier_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundMix* InSoundMixModifier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.ProjectWorldToScreen
struct UGameplayStatics_ProjectWorldToScreen_Params
{
	class APlayerController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector WorldPosition; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector2D ScreenPosition; // (Parm, OutParm, IsPlainOldData)
	bool bPlayerViewportRelative; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.PopSoundMixModifier
struct UGameplayStatics_PopSoundMixModifier_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundMix* InSoundMixModifier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.PlayWorldCameraShake
struct UGameplayStatics_PlayWorldCameraShake_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Shake; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Epicenter; // (Parm, IsPlainOldData)
	float InnerRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	float OuterRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	float Falloff; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bOrientShakeTowardsEpicenter; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.PlaySoundAtLocation
struct UGameplayStatics_PlaySoundAtLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundConcurrency* ConcurrencySettings; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* OwningActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.PlaySound2D
struct UGameplayStatics_PlaySound2D_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundConcurrency* ConcurrencySettings; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* OwningActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.PlayDialogueAtLocation
struct UGameplayStatics_PlayDialogueAtLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UDialogueWave* Dialogue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDialogueContext Context; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundAttenuation* AttenuationSettings; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.PlayDialogue2D
struct UGameplayStatics_PlayDialogue2D_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UDialogueWave* Dialogue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDialogueContext Context; // (ConstParm, Parm, OutParm, ReferenceParm)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.ParseOption
struct UGameplayStatics_ParseOption_Params
{
	struct FString Options; // (Parm, ZeroConstructor)
	struct FString Key; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.GameplayStatics.OpenShaderCodeLibrary
struct UGameplayStatics_OpenShaderCodeLibrary_Params
{
	struct FString Path; // (Parm, ZeroConstructor)
	struct FString VersionNum; // (Parm, ZeroConstructor)
	bool bForceOpen; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.OpenLevel
struct UGameplayStatics_OpenLevel_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName LevelName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAbsolute; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Options; // (Parm, ZeroConstructor)
};

// Function Engine.GameplayStatics.MakeHitResult
struct UGameplayStatics_MakeHitResult_Params
{
	bool bBlockingHit; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bInitialOverlap; // (Parm, ZeroConstructor, IsPlainOldData)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	float Distance; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FVector ImpactPoint; // (Parm, IsPlainOldData)
	struct FVector Normal; // (Parm, IsPlainOldData)
	struct FVector ImpactNormal; // (Parm, IsPlainOldData)
	class UPhysicalMaterial* PhysMat; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* HitActor; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* HitComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName HitBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	int HitItem; // (Parm, ZeroConstructor, IsPlainOldData)
	int FaceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector TraceStart; // (Parm, IsPlainOldData)
	struct FVector TraceEnd; // (Parm, IsPlainOldData)
	struct FHitResult ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.LoadStreamLevel
struct UGameplayStatics_LoadStreamLevel_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName LevelName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMakeVisibleAfterLoad; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bShouldBlockOnLoad; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.GameplayStatics.LoadShaderLibraryAdditional
struct UGameplayStatics_LoadShaderLibraryAdditional_Params
{
	int IncludeMask; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.LoadGameFromSlot
struct UGameplayStatics_LoadGameFromSlot_Params
{
	struct FString SlotName; // (Parm, ZeroConstructor)
	int UserIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USaveGame* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.IsGamePaused
struct UGameplayStatics_IsGamePaused_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.IsForwardPlusShaderLibraryLoaded
struct UGameplayStatics_IsForwardPlusShaderLibraryLoaded_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.HasOption
struct UGameplayStatics_HasOption_Params
{
	struct FString Options; // (Parm, ZeroConstructor)
	struct FString InKey; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.HasLaunchOption
struct UGameplayStatics_HasLaunchOption_Params
{
	struct FString OptionToCheck; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GrassOverlappingSphereCount
struct UGameplayStatics_GrassOverlappingSphereCount_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UStaticMesh* StaticMesh; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector CenterPosition; // (Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetWorldOriginLocation
struct UGameplayStatics_GetWorldOriginLocation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FIntVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetWorldDeltaSeconds
struct UGameplayStatics_GetWorldDeltaSeconds_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetUnpausedTimeSeconds
struct UGameplayStatics_GetUnpausedTimeSeconds_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetTimeSeconds
struct UGameplayStatics_GetTimeSeconds_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetSurfaceType
struct UGameplayStatics_GetSurfaceType_Params
{
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum EPhysicalSurface> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetStreamingLevel
struct UGameplayStatics_GetStreamingLevel_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName PackageName; // (Parm, ZeroConstructor, IsPlainOldData)
	class ULevelStreaming* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetRealTimeSeconds
struct UGameplayStatics_GetRealTimeSeconds_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetPlayerPawn
struct UGameplayStatics_GetPlayerPawn_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int playerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetPlayerControllerID
struct UGameplayStatics_GetPlayerControllerID_Params
{
	class APlayerController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetPlayerController
struct UGameplayStatics_GetPlayerController_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int playerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerController* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetPlayerCharacter
struct UGameplayStatics_GetPlayerCharacter_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int playerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class ACharacter* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetPlayerCameraManager
struct UGameplayStatics_GetPlayerCameraManager_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int playerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerCameraManager* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetPlatformName
struct UGameplayStatics_GetPlatformName_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.GameplayStatics.GetPlatformInt
struct UGameplayStatics_GetPlatformInt_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetObjectClass
struct UGameplayStatics_GetObjectClass_Params
{
	class UObject* Object; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetKeyValue
struct UGameplayStatics_GetKeyValue_Params
{
	struct FString Pair; // (Parm, ZeroConstructor)
	struct FString Key; // (Parm, OutParm, ZeroConstructor)
	struct FString Value; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.GameplayStatics.GetIntOption
struct UGameplayStatics_GetIntOption_Params
{
	struct FString Options; // (Parm, ZeroConstructor)
	struct FString Key; // (Parm, ZeroConstructor)
	int DefaultValue; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetGlobalTimeDilation
struct UGameplayStatics_GetGlobalTimeDilation_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetGameState
struct UGameplayStatics_GetGameState_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AGameStateBase* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetGameMode
struct UGameplayStatics_GetGameMode_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AGameModeBase* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetGameInstance
struct UGameplayStatics_GetGameInstance_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UGameInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetFirstActorOfClass
struct UGameplayStatics_GetFirstActorOfClass_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ActorClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetCurrentReverbEffect
struct UGameplayStatics_GetCurrentReverbEffect_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UReverbEffect* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetCurrentLevelName
struct UGameplayStatics_GetCurrentLevelName_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool bRemovePrefixString; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.GameplayStatics.GetAudioTimeSeconds
struct UGameplayStatics_GetAudioTimeSeconds_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetAllActorsWithTag
struct UGameplayStatics_GetAllActorsWithTag_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName Tag; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.GameplayStatics.GetAllActorsWithInterface
struct UGameplayStatics_GetAllActorsWithInterface_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Interface; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.GameplayStatics.GetAllActorsOfClass
struct UGameplayStatics_GetAllActorsOfClass_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ActorClass; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.GameplayStatics.GetActorArrayBounds
struct UGameplayStatics_GetActorArrayBounds_Params
{
	TArray<class AActor*> Actors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bOnlyCollidingComponents; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Center; // (Parm, OutParm, IsPlainOldData)
	struct FVector BoxExtent; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetActorArrayAverageLocation
struct UGameplayStatics_GetActorArrayAverageLocation_Params
{
	TArray<class AActor*> Actors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.GetAccurateRealTime
struct UGameplayStatics_GetAccurateRealTime_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int Seconds; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float PartialSeconds; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.FlushLevelStreaming
struct UGameplayStatics_FlushLevelStreaming_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.FlushAsyncLoading
struct UGameplayStatics_FlushAsyncLoading_Params
{
};

// Function Engine.GameplayStatics.FinishSpawningActor
struct UGameplayStatics_FinishSpawningActor_Params
{
	class AActor* Actor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform SpawnTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.FindCollisionUV
struct UGameplayStatics_FindCollisionUV_Params
{
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int UVChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D UV; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.EnableShaderPak_Only
struct UGameplayStatics_EnableShaderPak_Only_Params
{
	struct FString ShaderPakName; // (Parm, ZeroConstructor)
};

// Function Engine.GameplayStatics.EnableShaderPak
struct UGameplayStatics_EnableShaderPak_Params
{
	struct FString ShaderPakName; // (Parm, ZeroConstructor)
};

// Function Engine.GameplayStatics.EnableShaderLevel
struct UGameplayStatics_EnableShaderLevel_Params
{
	struct FString ShaderLevelName; // (Parm, ZeroConstructor)
};

// Function Engine.GameplayStatics.EnableShaderGroup
struct UGameplayStatics_EnableShaderGroup_Params
{
	struct FString GroupName; // (Parm, ZeroConstructor)
	int ShaderPlatform; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.EnableLiveStreaming
struct UGameplayStatics_EnableLiveStreaming_Params
{
	bool Enable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.DoesSaveGameExist
struct UGameplayStatics_DoesSaveGameExist_Params
{
	struct FString SlotName; // (Parm, ZeroConstructor)
	int UserIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.DeprojectScreenToWorld
struct UGameplayStatics_DeprojectScreenToWorld_Params
{
	class APlayerController* Player; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ScreenPosition; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector WorldPosition; // (Parm, OutParm, IsPlainOldData)
	struct FVector WorldDirection; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.DeleteGameInSlot
struct UGameplayStatics_DeleteGameInSlot_Params
{
	struct FString SlotName; // (Parm, ZeroConstructor)
	int UserIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.DeactivateReverbEffect
struct UGameplayStatics_DeactivateReverbEffect_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FName TagName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.CreateSound2D
struct UGameplayStatics_CreateSound2D_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundConcurrency* ConcurrencySettings; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPersistAcrossLevelTransition; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAutoDestroy; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAudioComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.GameplayStatics.CreateSaveGameObjectFromBlueprint
struct UGameplayStatics_CreateSaveGameObjectFromBlueprint_Params
{
	class UBlueprint* SaveGameBlueprint; // (Parm, ZeroConstructor, IsPlainOldData)
	class USaveGame* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.CreateSaveGameObject
struct UGameplayStatics_CreateSaveGameObject_Params
{
	class UClass* SaveGameClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class USaveGame* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.CreatePlayer
struct UGameplayStatics_CreatePlayer_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int ControllerId; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSpawnPawn; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerController* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.ClearSoundMixModifiers
struct UGameplayStatics_ClearSoundMixModifiers_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.ClearSoundMixClassOverride
struct UGameplayStatics_ClearSoundMixClassOverride_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class USoundMix* InSoundMixModifier; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundClass* InSoundClass; // (Parm, ZeroConstructor, IsPlainOldData)
	float FadeOutTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameplayStatics.CheckMetalLibraryUncompressed
struct UGameplayStatics_CheckMetalLibraryUncompressed_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.CancelAsyncLoading
struct UGameplayStatics_CancelAsyncLoading_Params
{
};

// Function Engine.GameplayStatics.BreakHitResult
struct UGameplayStatics_BreakHitResult_Params
{
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bBlockingHit; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool bInitialOverlap; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Time; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Distance; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, OutParm, IsPlainOldData)
	struct FVector ImpactPoint; // (Parm, OutParm, IsPlainOldData)
	struct FVector Normal; // (Parm, OutParm, IsPlainOldData)
	struct FVector ImpactNormal; // (Parm, OutParm, IsPlainOldData)
	class UPhysicalMaterial* PhysMat; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class AActor* HitActor; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* HitComponent; // (Parm, OutParm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName HitBoneName; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int HitItem; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int FaceIndex; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector TraceStart; // (Parm, OutParm, IsPlainOldData)
	struct FVector TraceEnd; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.BlueprintSuggestProjectileVelocity
struct UGameplayStatics_BlueprintSuggestProjectileVelocity_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector TossVelocity; // (Parm, OutParm, IsPlainOldData)
	struct FVector StartLocation; // (Parm, IsPlainOldData)
	struct FVector EndLocation; // (Parm, IsPlainOldData)
	float LaunchSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	float OverrideGravityZ; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESuggestProjVelocityTraceOption> TraceOption; // (Parm, ZeroConstructor, IsPlainOldData)
	float CollisionRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFavorHighArc; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDrawDebug; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.Blueprint_PredictProjectilePath_ByTraceChannel
struct UGameplayStatics_Blueprint_PredictProjectilePath_ByTraceChannel_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	TArray<struct FVector> OutPathPositions; // (Parm, OutParm, ZeroConstructor)
	struct FVector OutLastTraceDestination; // (Parm, OutParm, IsPlainOldData)
	struct FVector StartPos; // (Parm, IsPlainOldData)
	struct FVector LaunchVelocity; // (Parm, IsPlainOldData)
	bool bTracePath; // (Parm, ZeroConstructor, IsPlainOldData)
	float ProjectileRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionChannel> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	float DrawDebugTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float SimFrequency; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxSimTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float OverrideGravityZ; // (Parm, ZeroConstructor, IsPlainOldData)
	float GravityScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float IgnoreGravityDis; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.Blueprint_PredictProjectilePath_ByObjectType
struct UGameplayStatics_Blueprint_PredictProjectilePath_ByObjectType_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	TArray<struct FVector> OutPathPositions; // (Parm, OutParm, ZeroConstructor)
	struct FVector OutLastTraceDestination; // (Parm, OutParm, IsPlainOldData)
	struct FVector StartPos; // (Parm, IsPlainOldData)
	struct FVector LaunchVelocity; // (Parm, IsPlainOldData)
	bool bTracePath; // (Parm, ZeroConstructor, IsPlainOldData)
	float ProjectileRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	float DrawDebugTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float SimFrequency; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxSimTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float OverrideGravityZ; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.Blueprint_PredictProjectilePath_Advanced
struct UGameplayStatics_Blueprint_PredictProjectilePath_Advanced_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FPredictProjectilePathParams PredictParams; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FPredictProjectilePathResult PredictResult; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.Blueprint_PredictBulletPath_ByTraceChannel
struct UGameplayStatics_Blueprint_PredictBulletPath_ByTraceChannel_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	TArray<struct FVector> OutPathPositions; // (Parm, OutParm, ZeroConstructor)
	struct FVector OutLastTraceDestination; // (Parm, OutParm, IsPlainOldData)
	struct FVector StartPos; // (Parm, IsPlainOldData)
	struct FVector LaunchVelocity; // (Parm, IsPlainOldData)
	bool bTracePath; // (Parm, ZeroConstructor, IsPlainOldData)
	float BulletRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionChannel> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	float DrawDebugTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float SimFrequency; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxSimTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float GravityScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float IgnoreGravityDis; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.BeginSpawningActorFromClass
struct UGameplayStatics_BeginSpawningActorFromClass_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ActorClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform SpawnTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bNoCollisionFail; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* Owner; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.BeginSpawningActorFromBlueprint
struct UGameplayStatics_BeginSpawningActorFromBlueprint_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UBlueprint* Blueprint; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform SpawnTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bNoCollisionFail; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.BeginDeferredActorSpawnFromClass
struct UGameplayStatics_BeginDeferredActorSpawnFromClass_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ActorClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform SpawnTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	ESpawnActorCollisionHandlingMethod CollisionHandlingOverride; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* Owner; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.AreSubtitlesEnabled
struct UGameplayStatics_AreSubtitlesEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.AreAnyListenersWithinRange
struct UGameplayStatics_AreAnyListenersWithinRange_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	float MaximumRange; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.ApplyRadialDamageWithFalloff
struct UGameplayStatics_ApplyRadialDamageWithFalloff_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float BaseDamage; // (Parm, ZeroConstructor, IsPlainOldData)
	float MinimumDamage; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float DamageInnerRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	float DamageOuterRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	float DamageFalloff; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* DamageTypeClass; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> IgnoreActors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
	class AController* InstigatedByController; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionChannel> DamagePreventionChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.ApplyRadialDamage
struct UGameplayStatics_ApplyRadialDamage_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float BaseDamage; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float DamageRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* DamageTypeClass; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> IgnoreActors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
	class AController* InstigatedByController; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDoFullDamage; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionChannel> DamagePreventionChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.ApplyPointDamage
struct UGameplayStatics_ApplyPointDamage_Params
{
	class AActor* DamagedActor; // (Parm, ZeroConstructor, IsPlainOldData)
	float BaseDamage; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector HitFromDirection; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FHitResult HitInfo; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class AController* EventInstigator; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* DamageTypeClass; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.ApplyDamage
struct UGameplayStatics_ApplyDamage_Params
{
	class AActor* DamagedActor; // (Parm, ZeroConstructor, IsPlainOldData)
	float BaseDamage; // (Parm, ZeroConstructor, IsPlainOldData)
	class AController* EventInstigator; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* DamageCauser; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* DamageTypeClass; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameplayStatics.ActivateReverbEffect
struct UGameplayStatics_ActivateReverbEffect_Params
{
	class UObject* WorldContextObject; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class UReverbEffect* ReverbEffect; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName TagName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Priority; // (Parm, ZeroConstructor, IsPlainOldData)
	float Volume; // (Parm, ZeroConstructor, IsPlainOldData)
	float FadeTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.UpdateInstanceTransform
struct UInstancedStaticMeshComponent_UpdateInstanceTransform_Params
{
	int InstanceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform NewInstanceTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bWorldSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMarkRenderStateDirty; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.ShowInstances
struct UInstancedStaticMeshComponent_ShowInstances_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.SetCullDistances
struct UInstancedStaticMeshComponent_SetCullDistances_Params
{
	int StartCullDistance; // (Parm, ZeroConstructor, IsPlainOldData)
	int EndCullDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.ResetAllInstances
struct UInstancedStaticMeshComponent_ResetAllInstances_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.ReplaceAllInstances
struct UInstancedStaticMeshComponent_ReplaceAllInstances_Params
{
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.InstancedStaticMeshComponent.RemoveInstances
struct UInstancedStaticMeshComponent_RemoveInstances_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.RemoveInstance
struct UInstancedStaticMeshComponent_RemoveInstance_Params
{
	int InstanceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.HideInstance
struct UInstancedStaticMeshComponent_HideInstance_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.GetInstanceTransform
struct UInstancedStaticMeshComponent_GetInstanceTransform_Params
{
	int InstanceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform OutInstanceTransform; // (Parm, OutParm, IsPlainOldData)
	bool bWorldSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.GetInstancesOverlappingSphere
struct UInstancedStaticMeshComponent_GetInstancesOverlappingSphere_Params
{
	struct FVector Center; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSphereInWorldSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.InstancedStaticMeshComponent.GetInstancesOverlappingBox
struct UInstancedStaticMeshComponent_GetInstancesOverlappingBox_Params
{
	struct FBox Box; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bBoxInWorldSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.InstancedStaticMeshComponent.GetInstanceCount
struct UInstancedStaticMeshComponent_GetInstanceCount_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.ClearInstances
struct UInstancedStaticMeshComponent_ClearInstances_Params
{
};

// Function Engine.InstancedStaticMeshComponent.AddInstanceWorldSpace
struct UInstancedStaticMeshComponent_AddInstanceWorldSpace_Params
{
	struct FTransform WorldTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedStaticMeshComponent.AddInstances
struct UInstancedStaticMeshComponent_AddInstances_Params
{
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMarkRenderStateDirty; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.InstancedStaticMeshComponent.AddInstance
struct UInstancedStaticMeshComponent_AddInstance_Params
{
	struct FTransform InstanceTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.HierarchicalInstancedStaticMeshComponent.ShowInstances
struct UHierarchicalInstancedStaticMeshComponent_ShowInstances_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.HierarchicalInstancedStaticMeshComponent.ResetAllInstances
struct UHierarchicalInstancedStaticMeshComponent_ResetAllInstances_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.HierarchicalInstancedStaticMeshComponent.RemoveInstances
struct UHierarchicalInstancedStaticMeshComponent_RemoveInstances_Params
{
	TArray<int> InstancesToRemove; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.WasInputKeyJustReleased
struct APlayerController_WasInputKeyJustReleased_Params
{
	struct FKey Key; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.WasInputKeyJustPressed
struct APlayerController_WasInputKeyJustPressed_Params
{
	struct FKey Key; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.ToggleSpeaking
struct APlayerController_ToggleSpeaking_Params
{
	bool bInSpeaking; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SwitchLevel
struct APlayerController_SwitchLevel_Params
{
	struct FString URL; // (Parm, ZeroConstructor)
};

// Function Engine.PlayerController.StopHapticEffect
struct APlayerController_StopHapticEffect_Params
{
	EControllerHand Hand; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.StartFire
struct APlayerController_StartFire_Params
{
	unsigned char FireModeNum; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SetVirtualJoystickVisibility
struct APlayerController_SetVirtualJoystickVisibility_Params
{
	bool bVisible; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SetViewTargetWithBlend
struct APlayerController_SetViewTargetWithBlend_Params
{
	class AActor* NewViewTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendTime; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EViewTargetBlendFunction> BlendFunc; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendExp; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLockOutgoing; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SetName
struct APlayerController_SetName_Params
{
	struct FString S; // (Parm, ZeroConstructor)
};

// Function Engine.PlayerController.SetMouseLocation
struct APlayerController_SetMouseLocation_Params
{
	int X; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int Y; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SetMouseCursorWidget
struct APlayerController_SetMouseCursorWidget_Params
{
	TEnumAsByte<enum EMouseCursor> Cursor; // (Parm, ZeroConstructor, IsPlainOldData)
	class UUserWidget* CursorWidget; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.PlayerController.SetHapticsByValue
struct APlayerController_SetHapticsByValue_Params
{
	float Frequency; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float Amplitude; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	EControllerHand Hand; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SetControllerLightColor
struct APlayerController_SetControllerLightColor_Params
{
	struct FColor Color; // (Parm, IsPlainOldData)
};

// Function Engine.PlayerController.SetCinematicMode
struct APlayerController_SetCinematicMode_Params
{
	bool bInCinematicMode; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bHidePlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsHUD; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsMovement; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsTurning; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SetAudioListenerOverride
struct APlayerController_SetAudioListenerOverride_Params
{
	class USceneComponent* AttachToComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
};

// Function Engine.PlayerController.ServerViewSelf
struct APlayerController_ServerViewSelf_Params
{
	struct FViewTargetTransitionParams TransitionParams; // (Parm)
};

// Function Engine.PlayerController.ServerViewPrevPlayer
struct APlayerController_ServerViewPrevPlayer_Params
{
};

// Function Engine.PlayerController.ServerViewNextPlayer
struct APlayerController_ServerViewNextPlayer_Params
{
};

// Function Engine.PlayerController.ServerVerifyViewTarget
struct APlayerController_ServerVerifyViewTarget_Params
{
};

// Function Engine.PlayerController.ServerUpdateLevelVisibility
struct APlayerController_ServerUpdateLevelVisibility_Params
{
	struct FName PackageName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIsVisible; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ServerUpdateCamera
struct APlayerController_ServerUpdateCamera_Params
{
	struct FVector_NetQuantize CamLoc; // (Parm)
	int CamPitchAndYaw; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ServerUnmutePlayer
struct APlayerController_ServerUnmutePlayer_Params
{
	struct FUniqueNetIdRepl PlayerID; // (Parm)
};

// Function Engine.PlayerController.ServerToggleAILogging
struct APlayerController_ServerToggleAILogging_Params
{
};

// Function Engine.PlayerController.ServerShortTimeout
struct APlayerController_ServerShortTimeout_Params
{
};

// Function Engine.PlayerController.ServerSetSpectatorWaiting
struct APlayerController_ServerSetSpectatorWaiting_Params
{
	bool bWaiting; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ServerSetSpectatorLocation
struct APlayerController_ServerSetSpectatorLocation_Params
{
	struct FVector NewLoc; // (Parm, IsPlainOldData)
	struct FRotator NewRot; // (Parm, IsPlainOldData)
};

// Function Engine.PlayerController.ServerRestartPlayer
struct APlayerController_ServerRestartPlayer_Params
{
};

// Function Engine.PlayerController.ServerPause
struct APlayerController_ServerPause_Params
{
};

// Function Engine.PlayerController.ServerNotifyLoadedWorld
struct APlayerController_ServerNotifyLoadedWorld_Params
{
	struct FName WorldPackageName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ServerMutePlayer
struct APlayerController_ServerMutePlayer_Params
{
	struct FUniqueNetIdRepl PlayerID; // (Parm)
};

// Function Engine.PlayerController.ServerCheckClientPossessionReliable
struct APlayerController_ServerCheckClientPossessionReliable_Params
{
};

// Function Engine.PlayerController.ServerCheckClientPossession
struct APlayerController_ServerCheckClientPossession_Params
{
};

// Function Engine.PlayerController.ServerChangeName
struct APlayerController_ServerChangeName_Params
{
	struct FString S; // (Parm, ZeroConstructor)
};

// Function Engine.PlayerController.ServerCamera
struct APlayerController_ServerCamera_Params
{
	struct FName NewMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ServerAcknowledgePossession
struct APlayerController_ServerAcknowledgePossession_Params
{
	class APawn* P; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.SendToConsole
struct APlayerController_SendToConsole_Params
{
	struct FString Command; // (Parm, ZeroConstructor)
};

// Function Engine.PlayerController.RestartLevel
struct APlayerController_RestartLevel_Params
{
};

// Function Engine.PlayerController.ProjectWorldLocationToScreen
struct APlayerController_ProjectWorldLocationToScreen_Params
{
	struct FVector WorldLocation; // (Parm, IsPlainOldData)
	struct FVector2D ScreenLocation; // (Parm, OutParm, IsPlainOldData)
	bool bPlayerViewportRelative; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.PlayHapticEffect
struct APlayerController_PlayHapticEffect_Params
{
	class UHapticFeedbackEffect_Base* HapticEffect; // (Parm, ZeroConstructor, IsPlainOldData)
	EControllerHand Hand; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLoop; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.PlayDynamicForceFeedback
struct APlayerController_PlayDynamicForceFeedback_Params
{
	float Intensity; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsLeftLarge; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsLeftSmall; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsRightLarge; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsRightSmall; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EDynamicForceFeedbackAction> Action; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.PlayerController.Pause
struct APlayerController_Pause_Params
{
};

// Function Engine.PlayerController.OnServerStartedVisualLogger
struct APlayerController_OnServerStartedVisualLogger_Params
{
	bool bIsLogging; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.OnGoingToLoseJoystick
struct APlayerController_OnGoingToLoseJoystick_Params
{
};

// Function Engine.PlayerController.LocalTravel
struct APlayerController_LocalTravel_Params
{
	struct FString URL; // (Parm, ZeroConstructor)
};

// Function Engine.PlayerController.IsInputKeyDown
struct APlayerController_IsInputKeyDown_Params
{
	struct FKey Key; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetViewportSize
struct APlayerController_GetViewportSize_Params
{
	int SizeX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int SizeY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.GetSpectatorPawn
struct APlayerController_GetSpectatorPawn_Params
{
	class ASpectatorPawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetMousePosition
struct APlayerController_GetMousePosition_Params
{
	float LocationX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float LocationY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetInputVectorKeyState
struct APlayerController_GetInputVectorKeyState_Params
{
	struct FKey Key; // (Parm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetInputTouchState
struct APlayerController_GetInputTouchState_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float LocationX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float LocationY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool bIsCurrentlyPressed; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.GetInputMouseDelta
struct APlayerController_GetInputMouseDelta_Params
{
	float DeltaX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float DeltaY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.GetInputMotionState
struct APlayerController_GetInputMotionState_Params
{
	struct FVector Tilt; // (Parm, OutParm, IsPlainOldData)
	struct FVector RotationRate; // (Parm, OutParm, IsPlainOldData)
	struct FVector Gravity; // (Parm, OutParm, IsPlainOldData)
	struct FVector Acceleration; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetInputKeyTimeDown
struct APlayerController_GetInputKeyTimeDown_Params
{
	struct FKey Key; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetInputAnalogStickState
struct APlayerController_GetInputAnalogStickState_Params
{
	TEnumAsByte<enum EControllerAnalogStick> WhichStick; // (Parm, ZeroConstructor, IsPlainOldData)
	float StickX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float StickY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.GetInputAnalogKeyState
struct APlayerController_GetInputAnalogKeyState_Params
{
	struct FKey Key; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetHUD
struct APlayerController_GetHUD_Params
{
	class AHUD* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetHitResultUnderFingerForObjects
struct APlayerController_GetHitResultUnderFingerForObjects_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult HitResult; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetHitResultUnderFingerByChannel
struct APlayerController_GetHitResultUnderFingerByChannel_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult HitResult; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetHitResultUnderFinger
struct APlayerController_GetHitResultUnderFinger_Params
{
	TEnumAsByte<enum ETouchIndex> FingerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionChannel> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult HitResult; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetHitResultUnderCursorForObjects
struct APlayerController_GetHitResultUnderCursorForObjects_Params
{
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult HitResult; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetHitResultUnderCursorByChannel
struct APlayerController_GetHitResultUnderCursorByChannel_Params
{
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult HitResult; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetHitResultUnderCursor
struct APlayerController_GetHitResultUnderCursor_Params
{
	TEnumAsByte<enum ECollisionChannel> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult HitResult; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.GetFocalLocation
struct APlayerController_GetFocalLocation_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.FOV
struct APlayerController_FOV_Params
{
	float NewFOV; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.EnableCheats
struct APlayerController_EnableCheats_Params
{
};

// Function Engine.PlayerController.DeprojectScreenPositionToWorld
struct APlayerController_DeprojectScreenPositionToWorld_Params
{
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector WorldLocation; // (Parm, OutParm, IsPlainOldData)
	struct FVector WorldDirection; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.DeprojectMousePositionToWorld
struct APlayerController_DeprojectMousePositionToWorld_Params
{
	struct FVector WorldLocation; // (Parm, OutParm, IsPlainOldData)
	struct FVector WorldDirection; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.ConsoleKey
struct APlayerController_ConsoleKey_Params
{
	struct FKey Key; // (Parm)
};

// Function Engine.PlayerController.ClientWasKicked
struct APlayerController_ClientWasKicked_Params
{
	struct FText KickReason; // (ConstParm, Parm, ReferenceParm)
};

// Function Engine.PlayerController.ClientVoiceHandshakeComplete
struct APlayerController_ClientVoiceHandshakeComplete_Params
{
};

// Function Engine.PlayerController.ClientUpdateLevelStreamingStatus
struct APlayerController_ClientUpdateLevelStreamingStatus_Params
{
	struct FName PackageName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bNewShouldBeLoaded; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bNewShouldBeVisible; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bNewShouldBlockOnLoad; // (Parm, ZeroConstructor, IsPlainOldData)
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientUnmutePlayer
struct APlayerController_ClientUnmutePlayer_Params
{
	struct FUniqueNetIdRepl PlayerID; // (Parm)
};

// Function Engine.PlayerController.ClientTravelInternal
struct APlayerController_ClientTravelInternal_Params
{
	struct FString URL; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ETravelType> TravelType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSeamless; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FGuid MapPackageGuid; // (Parm, IsPlainOldData)
};

// Function Engine.PlayerController.ClientTravel
struct APlayerController_ClientTravel_Params
{
	struct FString URL; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ETravelType> TravelType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSeamless; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FGuid MapPackageGuid; // (Parm, IsPlainOldData)
};

// Function Engine.PlayerController.ClientTeamMessage
struct APlayerController_ClientTeamMessage_Params
{
	class APlayerState* SenderPlayerState; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString S; // (Parm, ZeroConstructor)
	struct FName Type; // (Parm, ZeroConstructor, IsPlainOldData)
	float MsgLifeTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientStopForceFeedback
struct APlayerController_ClientStopForceFeedback_Params
{
	class UForceFeedbackEffect* ForceFeedbackEffect; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName Tag; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientStopCameraShake
struct APlayerController_ClientStopCameraShake_Params
{
	class UClass* Shake; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bImmediately; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientStopCameraAnim
struct APlayerController_ClientStopCameraAnim_Params
{
	class UCameraAnim* AnimToStop; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientStartOnlineSession
struct APlayerController_ClientStartOnlineSession_Params
{
};

// Function Engine.PlayerController.ClientSpawnCameraLensEffect
struct APlayerController_ClientSpawnCameraLensEffect_Params
{
	class UClass* LensEffectEmitterClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientSetViewTarget
struct APlayerController_ClientSetViewTarget_Params
{
	class AActor* A; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FViewTargetTransitionParams TransitionParams; // (Parm)
};

// Function Engine.PlayerController.ClientSetSpectatorWaiting
struct APlayerController_ClientSetSpectatorWaiting_Params
{
	bool bWaiting; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientSetHUD
struct APlayerController_ClientSetHUD_Params
{
	class UClass* NewHUDClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientSetForceMipLevelsToBeResident
struct APlayerController_ClientSetForceMipLevelsToBeResident_Params
{
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
	float ForceDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	int CinematicTextureGroups; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientSetCinematicMode
struct APlayerController_ClientSetCinematicMode_Params
{
	bool bInCinematicMode; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsMovement; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsTurning; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAffectsHUD; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientSetCameraMode
struct APlayerController_ClientSetCameraMode_Params
{
	struct FName NewCamMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientSetCameraFade
struct APlayerController_ClientSetCameraFade_Params
{
	bool bEnableFading; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FColor FadeColor; // (Parm, IsPlainOldData)
	struct FVector2D FadeAlpha; // (Parm, IsPlainOldData)
	float FadeTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFadeAudio; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientSetBlockOnAsyncLoading
struct APlayerController_ClientSetBlockOnAsyncLoading_Params
{
};

// Function Engine.PlayerController.ClientReturnToMainMenu
struct APlayerController_ClientReturnToMainMenu_Params
{
	struct FString ReturnReason; // (Parm, ZeroConstructor)
};

// Function Engine.PlayerController.ClientRetryClientRestart
struct APlayerController_ClientRetryClientRestart_Params
{
	class APawn* NewPawn; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientRestart
struct APlayerController_ClientRestart_Params
{
	class APawn* NewPawn; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientReset
struct APlayerController_ClientReset_Params
{
};

// Function Engine.PlayerController.ClientRepObjRef
struct APlayerController_ClientRepObjRef_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientReceiveLocalizedMessage
struct APlayerController_ClientReceiveLocalizedMessage_Params
{
	class UClass* Message; // (Parm, ZeroConstructor, IsPlainOldData)
	int Switch; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerState* RelatedPlayerState_2; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerState* RelatedPlayerState_3; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* OptionalObject; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientPrestreamTextures
struct APlayerController_ClientPrestreamTextures_Params
{
	class AActor* ForcedActor; // (Parm, ZeroConstructor, IsPlainOldData)
	float ForceDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableStreaming; // (Parm, ZeroConstructor, IsPlainOldData)
	int CinematicTextureGroups; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientPrepareMapChange
struct APlayerController_ClientPrepareMapChange_Params
{
	struct FName LevelName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFirst; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLast; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientPlaySoundAtLocation
struct APlayerController_ClientPlaySoundAtLocation_Params
{
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientPlaySound
struct APlayerController_ClientPlaySound_Params
{
	class USoundBase* Sound; // (Parm, ZeroConstructor, IsPlainOldData)
	float VolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float PitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientPlayForceFeedback
struct APlayerController_ClientPlayForceFeedback_Params
{
	class UForceFeedbackEffect* ForceFeedbackEffect; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIgnoreTimeDilation; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName Tag; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientPlayCameraShake
struct APlayerController_ClientPlayCameraShake_Params
{
	class UClass* Shake; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECameraAnimPlaySpace> PlaySpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator UserPlaySpaceRot; // (Parm, IsPlainOldData)
};

// Function Engine.PlayerController.ClientPlayCameraAnim
struct APlayerController_ClientPlayCameraAnim_Params
{
	class UCameraAnim* AnimToPlay; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	float Rate; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendInTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendOutTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLoop; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bRandomStartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECameraAnimPlaySpace> Space; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator CustomPlaySpace; // (Parm, IsPlainOldData)
};

// Function Engine.PlayerController.ClientMutePlayer
struct APlayerController_ClientMutePlayer_Params
{
	struct FUniqueNetIdRepl PlayerID; // (Parm)
};

// Function Engine.PlayerController.ClientMessage
struct APlayerController_ClientMessage_Params
{
	struct FString S; // (Parm, ZeroConstructor)
	struct FName Type; // (Parm, ZeroConstructor, IsPlainOldData)
	float MsgLifeTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientIgnoreMoveInput
struct APlayerController_ClientIgnoreMoveInput_Params
{
	bool bIgnore; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientIgnoreLookInput
struct APlayerController_ClientIgnoreLookInput_Params
{
	bool bIgnore; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientGotoState
struct APlayerController_ClientGotoState_Params
{
	struct FName NewState; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientGameEnded
struct APlayerController_ClientGameEnded_Params
{
	class AActor* EndGameFocus; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIsWinner; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientForceGarbageCollection
struct APlayerController_ClientForceGarbageCollection_Params
{
};

// Function Engine.PlayerController.ClientFlushLevelStreaming
struct APlayerController_ClientFlushLevelStreaming_Params
{
};

// Function Engine.PlayerController.ClientEndOnlineSession
struct APlayerController_ClientEndOnlineSession_Params
{
};

// Function Engine.PlayerController.ClientEnableNetworkVoice
struct APlayerController_ClientEnableNetworkVoice_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientCommitMapChange
struct APlayerController_ClientCommitMapChange_Params
{
};

// Function Engine.PlayerController.ClientClearCameraLensEffects
struct APlayerController_ClientClearCameraLensEffects_Params
{
};

// Function Engine.PlayerController.ClientCapBandwidth
struct APlayerController_ClientCapBandwidth_Params
{
	int Cap; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClientCancelPendingMapChange
struct APlayerController_ClientCancelPendingMapChange_Params
{
};

// Function Engine.PlayerController.ClientAddTextureStreamingLoc
struct APlayerController_ClientAddTextureStreamingLoc_Params
{
	struct FVector InLoc; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bOverrideLocation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ClearJoystick
struct APlayerController_ClearJoystick_Params
{
};

// Function Engine.PlayerController.ClearAudioListenerOverride
struct APlayerController_ClearAudioListenerOverride_Params
{
};

// Function Engine.PlayerController.CanRestartPlayer
struct APlayerController_CanRestartPlayer_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerController.Camera
struct APlayerController_Camera_Params
{
	struct FName NewMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.AddYawInput
struct APlayerController_AddYawInput_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.AddRollInput
struct APlayerController_AddRollInput_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.AddPitchInput
struct APlayerController_AddPitchInput_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerController.ActivateTouchInterface
struct APlayerController_ActivateTouchInterface_Params
{
	class UTouchInterface* NewTouchInterface; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.StopCameraShake
struct APlayerCameraManager_StopCameraShake_Params
{
	class UCameraShake* ShakeInstance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bImmediately; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.StopCameraFade
struct APlayerCameraManager_StopCameraFade_Params
{
};

// Function Engine.PlayerCameraManager.StopCameraAnimInst
struct APlayerCameraManager_StopCameraAnimInst_Params
{
	class UCameraAnimInst* AnimInst; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bImmediate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.StopAllInstancesOfCameraShake
struct APlayerCameraManager_StopAllInstancesOfCameraShake_Params
{
	class UClass* Shake; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bImmediately; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.StopAllInstancesOfCameraAnim
struct APlayerCameraManager_StopAllInstancesOfCameraAnim_Params
{
	class UCameraAnim* Anim; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bImmediate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.StopAllCameraShakes
struct APlayerCameraManager_StopAllCameraShakes_Params
{
	bool bImmediately; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.StopAllCameraAnims
struct APlayerCameraManager_StopAllCameraAnims_Params
{
	bool bImmediate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.StartCameraFade
struct APlayerCameraManager_StartCameraFade_Params
{
	float FromAlpha; // (Parm, ZeroConstructor, IsPlainOldData)
	float ToAlpha; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor Color; // (Parm, IsPlainOldData)
	bool bShouldFadeAudio; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bHoldWhenFinished; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.SetManualCameraFade
struct APlayerCameraManager_SetManualCameraFade_Params
{
	float InFadeAmount; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor Color; // (Parm, IsPlainOldData)
	bool bInFadeAudio; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.RemoveCameraModifier
struct APlayerCameraManager_RemoveCameraModifier_Params
{
	class UCameraModifier* ModifierToRemove; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.RemoveCameraLensEffect
struct APlayerCameraManager_RemoveCameraLensEffect_Params
{
	class AEmitterCameraLensEffectBase* Emitter; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.PlayCameraShake
struct APlayerCameraManager_PlayCameraShake_Params
{
	class UClass* ShakeClass; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECameraAnimPlaySpace> PlaySpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator UserPlaySpaceRot; // (Parm, IsPlainOldData)
	class UCameraShake* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.PlayCameraAnim
struct APlayerCameraManager_PlayCameraAnim_Params
{
	class UCameraAnim* Anim; // (Parm, ZeroConstructor, IsPlainOldData)
	float Rate; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendInTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendOutTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLoop; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bRandomStartTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECameraAnimPlaySpace> PlaySpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator UserPlaySpaceRot; // (Parm, IsPlainOldData)
	class UCameraAnimInst* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.PhotographyCameraModify
struct APlayerCameraManager_PhotographyCameraModify_Params
{
	struct FVector NewCameraLocation; // (ConstParm, Parm, IsPlainOldData)
	struct FVector PreviousCameraLocation; // (ConstParm, Parm, IsPlainOldData)
	struct FVector OriginalCameraLocation; // (ConstParm, Parm, IsPlainOldData)
	struct FVector ResultCameraLocation; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.OnPhotographySessionStart
struct APlayerCameraManager_OnPhotographySessionStart_Params
{
};

// Function Engine.PlayerCameraManager.OnPhotographySessionEnd
struct APlayerCameraManager_OnPhotographySessionEnd_Params
{
};

// Function Engine.PlayerCameraManager.OnPhotographyMultiPartCaptureStart
struct APlayerCameraManager_OnPhotographyMultiPartCaptureStart_Params
{
};

// Function Engine.PlayerCameraManager.OnPhotographyMultiPartCaptureEnd
struct APlayerCameraManager_OnPhotographyMultiPartCaptureEnd_Params
{
};

// Function Engine.PlayerCameraManager.GetOwningPlayerController
struct APlayerCameraManager_GetOwningPlayerController_Params
{
	class APlayerController* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.GetFOVAngle
struct APlayerCameraManager_GetFOVAngle_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.GetCameraRotation
struct APlayerCameraManager_GetCameraRotation_Params
{
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.GetCameraLocation
struct APlayerCameraManager_GetCameraLocation_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.FindCameraModifierByClass
struct APlayerCameraManager_FindCameraModifierByClass_Params
{
	class UClass* ModifierClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UCameraModifier* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.ClearCameraLensEffects
struct APlayerCameraManager_ClearCameraLensEffects_Params
{
};

// Function Engine.PlayerCameraManager.BlueprintUpdateCamera
struct APlayerCameraManager_BlueprintUpdateCamera_Params
{
	class AActor* CameraTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NewCameraLocation; // (Parm, OutParm, IsPlainOldData)
	struct FRotator NewCameraRotation; // (Parm, OutParm, IsPlainOldData)
	float NewCameraFOV; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.AddNewCameraModifier
struct APlayerCameraManager_AddNewCameraModifier_Params
{
	class UClass* ModifierClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UCameraModifier* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlayerCameraManager.AddCameraLensEffect
struct APlayerCameraManager_AddCameraLensEffect_Params
{
	class UClass* LensEffectEmitterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class AEmitterCameraLensEffectBase* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DefaultPawn.TurnAtRate
struct ADefaultPawn_TurnAtRate_Params
{
	float Rate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DefaultPawn.MoveUp_World
struct ADefaultPawn_MoveUp_World_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DefaultPawn.MoveRight
struct ADefaultPawn_MoveRight_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DefaultPawn.MoveForward
struct ADefaultPawn_MoveForward_Params
{
	float Val; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DefaultPawn.LookUpAtRate
struct ADefaultPawn_LookUpAtRate_Params
{
	float Rate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.UpdateShowDebugTargetActor
struct AHUD_UpdateShowDebugTargetActor_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.HUD.ShowHUD
struct AHUD_ShowHUD_Params
{
};

// Function Engine.HUD.ShowDebugToggleSubCategory
struct AHUD_ShowDebugToggleSubCategory_Params
{
	struct FName Category; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.ShowDebugForReticleTargetToggle
struct AHUD_ShowDebugForReticleTargetToggle_Params
{
	class UClass* DesiredClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.ShowDebugForMoifiedTargetActor
struct AHUD_ShowDebugForMoifiedTargetActor_Params
{
};

// Function Engine.HUD.ShowDebug
struct AHUD_ShowDebug_Params
{
	struct FName DebugType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.RemoveDebugText
struct AHUD_RemoveDebugText_Params
{
	class AActor* SrcActor; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLeaveDurationText; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.RemoveAllDebugStrings
struct AHUD_RemoveAllDebugStrings_Params
{
};

// Function Engine.HUD.ReceiveHitBoxRelease
struct AHUD_ReceiveHitBoxRelease_Params
{
	struct FName BoxName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.ReceiveHitBoxEndCursorOver
struct AHUD_ReceiveHitBoxEndCursorOver_Params
{
	struct FName BoxName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.ReceiveHitBoxClick
struct AHUD_ReceiveHitBoxClick_Params
{
	struct FName BoxName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.ReceiveHitBoxBeginCursorOver
struct AHUD_ReceiveHitBoxBeginCursorOver_Params
{
	struct FName BoxName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.ReceiveDrawHUD
struct AHUD_ReceiveDrawHUD_Params
{
	int SizeX; // (Parm, ZeroConstructor, IsPlainOldData)
	int SizeY; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.Project
struct AHUD_Project_Params
{
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.HUD.GetTextSize
struct AHUD_GetTextSize_Params
{
	struct FString Text; // (Parm, ZeroConstructor)
	float OutWidth; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutHeight; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class UFont* Font; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.GetOwningPlayerController
struct AHUD_GetOwningPlayerController_Params
{
	class APlayerController* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.HUD.GetOwningPawn
struct AHUD_GetOwningPawn_Params
{
	class APawn* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.HUD.GetActorsInSelectionRectangle
struct AHUD_GetActorsInSelectionRectangle_Params
{
	class UClass* ClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D FirstPoint; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector2D SecondPoint; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
	bool bIncludeNonCollidingComponents; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bActorMustBeFullyEnclosed; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.DrawTextureSimple
struct AHUD_DrawTextureSimple_Params
{
	class UTexture* Texture; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bScalePosition; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.DrawTexture
struct AHUD_DrawTexture_Params
{
	class UTexture* Texture; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenW; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenH; // (Parm, ZeroConstructor, IsPlainOldData)
	float TextureU; // (Parm, ZeroConstructor, IsPlainOldData)
	float TextureV; // (Parm, ZeroConstructor, IsPlainOldData)
	float TextureUWidth; // (Parm, ZeroConstructor, IsPlainOldData)
	float TextureVHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TintColor; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EBlendMode> BlendMode; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bScalePosition; // (Parm, ZeroConstructor, IsPlainOldData)
	float Rotation; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D RotPivot; // (Parm, IsPlainOldData)
};

// Function Engine.HUD.DrawText
struct AHUD_DrawText_Params
{
	struct FString Text; // (Parm, ZeroConstructor)
	struct FLinearColor TextColor; // (Parm, IsPlainOldData)
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	class UFont* Font; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bScalePosition; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.DrawRect
struct AHUD_DrawRect_Params
{
	struct FLinearColor RectColor; // (Parm, IsPlainOldData)
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenW; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenH; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.DrawMaterialTriangle
struct AHUD_DrawMaterialTriangle_Params
{
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D V0_Pos; // (Parm, IsPlainOldData)
	struct FVector2D V1_Pos; // (Parm, IsPlainOldData)
	struct FVector2D V2_Pos; // (Parm, IsPlainOldData)
	struct FVector2D V0_UV; // (Parm, IsPlainOldData)
	struct FVector2D V1_UV; // (Parm, IsPlainOldData)
	struct FVector2D V2_UV; // (Parm, IsPlainOldData)
	struct FLinearColor V0_Color; // (Parm, IsPlainOldData)
	struct FLinearColor V1_Color; // (Parm, IsPlainOldData)
	struct FLinearColor V2_Color; // (Parm, IsPlainOldData)
};

// Function Engine.HUD.DrawMaterialSimple
struct AHUD_DrawMaterialSimple_Params
{
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenW; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenH; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bScalePosition; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.DrawMaterial
struct AHUD_DrawMaterial_Params
{
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenW; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenH; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaterialU; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaterialV; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaterialUWidth; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaterialVHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bScalePosition; // (Parm, ZeroConstructor, IsPlainOldData)
	float Rotation; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D RotPivot; // (Parm, IsPlainOldData)
};

// Function Engine.HUD.DrawLine
struct AHUD_DrawLine_Params
{
	float StartScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	float EndScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float EndScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float LineThickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.Deproject
struct AHUD_Deproject_Params
{
	float ScreenX; // (Parm, ZeroConstructor, IsPlainOldData)
	float ScreenY; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector WorldPosition; // (Parm, OutParm, IsPlainOldData)
	struct FVector WorldDirection; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.HUD.AddHitBox
struct AHUD_AddHitBox_Params
{
	struct FVector2D Position; // (Parm, IsPlainOldData)
	struct FVector2D Size; // (Parm, IsPlainOldData)
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bConsumesInput; // (Parm, ZeroConstructor, IsPlainOldData)
	int Priority; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HUD.AddDebugText
struct AHUD_AddDebugText_Params
{
	struct FString DebugText; // (Parm, ZeroConstructor)
	class AActor* SrcActor; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Offset; // (Parm, IsPlainOldData)
	struct FVector DesiredOffset; // (Parm, IsPlainOldData)
	struct FColor TextColor; // (Parm, IsPlainOldData)
	bool bSkipOverwriteCheck; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAbsoluteLocation; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bKeepAttachedToActor; // (Parm, ZeroConstructor, IsPlainOldData)
	class UFont* InFont; // (Parm, ZeroConstructor, IsPlainOldData)
	float FontScale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDrawShadow; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationSystem.UpdateDynamicGenerateTargetNav
struct UNavigationSystem_UpdateDynamicGenerateTargetNav_Params
{
	bool IsAdd; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDynamicGenerateTargetNavigation GenerateTargetNav; // (Parm)
};

// Function Engine.NavigationSystem.UnregisterNavigationInvoker
struct UNavigationSystem_UnregisterNavigationInvoker_Params
{
	class AActor* Invoker; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationSystem.SimpleMoveToLocation
struct UNavigationSystem_SimpleMoveToLocation_Params
{
	class AController* Controller; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Goal; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.SimpleMoveToActor
struct UNavigationSystem_SimpleMoveToActor_Params
{
	class AController* Controller; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* Goal; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationSystem.SetMaxSimultaneousTileGenerationJobsCount
struct UNavigationSystem_SetMaxSimultaneousTileGenerationJobsCount_Params
{
	int MaxNumberOfJobs; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationSystem.SetGeometryGatheringMode
struct UNavigationSystem_SetGeometryGatheringMode_Params
{
	ENavDataGatheringModeConfig NewMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationSystem.ResetMaxSimultaneousTileGenerationJobsCount
struct UNavigationSystem_ResetMaxSimultaneousTileGenerationJobsCount_Params
{
};

// Function Engine.NavigationSystem.RegisterNavigationInvoker
struct UNavigationSystem_RegisterNavigationInvoker_Params
{
	class AActor* Invoker; // (Parm, ZeroConstructor, IsPlainOldData)
	float TileGenerationRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	float TileRemovalRadius; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationSystem.ProjectPointToNavigation
struct UNavigationSystem_ProjectPointToNavigation_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Point; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector QueryExtent; // (ConstParm, Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.OnNavigationBoundsUpdated
struct UNavigationSystem_OnNavigationBoundsUpdated_Params
{
	class ANavMeshBoundsVolume* NavVolume; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationSystem.NavigationRaycast
struct UNavigationSystem_NavigationRaycast_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector RayStart; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector RayEnd; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector HitLocation; // (Parm, OutParm, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class AController* Querier; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.K2_ProjectPointToNavigation
struct UNavigationSystem_K2_ProjectPointToNavigation_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Point; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector ProjectedLocation; // (Parm, OutParm, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector QueryExtent; // (ConstParm, Parm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.K2_GetRandomReachablePointInRadius
struct UNavigationSystem_K2_GetRandomReachablePointInRadius_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector RandomLocation; // (Parm, OutParm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.K2_GetRandomPointInNavigableRadius
struct UNavigationSystem_K2_GetRandomPointInNavigableRadius_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector RandomLocation; // (Parm, OutParm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.IsNavigationBeingBuiltOrLocked
struct UNavigationSystem_IsNavigationBeingBuiltOrLocked_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.IsNavigationBeingBuilt
struct UNavigationSystem_IsNavigationBeingBuilt_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.GetRandomReachablePointInRadius
struct UNavigationSystem_GetRandomReachablePointInRadius_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.GetRandomPointInNavigableRadius
struct UNavigationSystem_GetRandomPointInNavigableRadius_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.GetPathLength
struct UNavigationSystem_GetPathLength_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector PathStart; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector PathEnd; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float PathLength; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ENavigationQueryResult> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.GetPathCost
struct UNavigationSystem_GetPathCost_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector PathStart; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector PathEnd; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float PathCost; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class ANavigationData* NavData; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ENavigationQueryResult> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.GetNavigationSystem
struct UNavigationSystem_GetNavigationSystem_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UNavigationSystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.FindPathToLocationSynchronously
struct UNavigationSystem_FindPathToLocationSynchronously_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector PathStart; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector PathEnd; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class AActor* PathfindingContext; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UNavigationPath* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationSystem.FindPathToActorSynchronously
struct UNavigationSystem_FindPathToActorSynchronously_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector PathStart; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class AActor* GoalActor; // (Parm, ZeroConstructor, IsPlainOldData)
	float TetherDistance; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* PathfindingContext; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UNavigationPath* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintAsyncActionBase.Activate
struct UBlueprintAsyncActionBase_Activate_Params
{
};

// Function Engine.AnimNotify_PlayParticleEffect.OnParticleSystemFinished
struct UAnimNotify_PlayParticleEffect_OnParticleSystemFinished_Params
{
	class UParticleSystemComponent* FinishedComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.AnimNotify_PlayParticleEffect.GetParentCharacter
struct UAnimNotify_PlayParticleEffect_GetParentCharacter_Params
{
	class USkeletalMeshComponent* MeshComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class ACharacter* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.UpdateMesh
struct USplineMeshComponent_UpdateMesh_Params
{
};

// Function Engine.SplineMeshComponent.SetStartTangent
struct USplineMeshComponent_SetStartTangent_Params
{
	struct FVector StartTangent; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetStartScale
struct USplineMeshComponent_SetStartScale_Params
{
	struct FVector2D StartScale; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetStartRoll
struct USplineMeshComponent_SetStartRoll_Params
{
	float StartRoll; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetStartPosition
struct USplineMeshComponent_SetStartPosition_Params
{
	struct FVector StartPos; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetStartOffset
struct USplineMeshComponent_SetStartOffset_Params
{
	struct FVector2D StartOffset; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetStartAndEnd
struct USplineMeshComponent_SetStartAndEnd_Params
{
	struct FVector StartPos; // (Parm, IsPlainOldData)
	struct FVector StartTangent; // (Parm, IsPlainOldData)
	struct FVector EndPos; // (Parm, IsPlainOldData)
	struct FVector EndTangent; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetSplineUpDir
struct USplineMeshComponent_SetSplineUpDir_Params
{
	struct FVector InSplineUpDir; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetForwardAxis
struct USplineMeshComponent_SetForwardAxis_Params
{
	TEnumAsByte<enum ESplineMeshAxis> InForwardAxis; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetEndTangent
struct USplineMeshComponent_SetEndTangent_Params
{
	struct FVector EndTangent; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetEndScale
struct USplineMeshComponent_SetEndScale_Params
{
	struct FVector2D EndScale; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetEndRoll
struct USplineMeshComponent_SetEndRoll_Params
{
	float EndRoll; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetEndPosition
struct USplineMeshComponent_SetEndPosition_Params
{
	struct FVector EndPos; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetEndOffset
struct USplineMeshComponent_SetEndOffset_Params
{
	struct FVector2D EndOffset; // (Parm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetBoundaryMin
struct USplineMeshComponent_SetBoundaryMin_Params
{
	float InBoundaryMin; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.SetBoundaryMax
struct USplineMeshComponent_SetBoundaryMax_Params
{
	float InBoundaryMax; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetStartTangent
struct USplineMeshComponent_GetStartTangent_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetStartScale
struct USplineMeshComponent_GetStartScale_Params
{
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetStartRoll
struct USplineMeshComponent_GetStartRoll_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetStartPosition
struct USplineMeshComponent_GetStartPosition_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetStartOffset
struct USplineMeshComponent_GetStartOffset_Params
{
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetSplineUpDir
struct USplineMeshComponent_GetSplineUpDir_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetForwardAxis
struct USplineMeshComponent_GetForwardAxis_Params
{
	TEnumAsByte<enum ESplineMeshAxis> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetEndTangent
struct USplineMeshComponent_GetEndTangent_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetEndScale
struct USplineMeshComponent_GetEndScale_Params
{
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetEndRoll
struct USplineMeshComponent_GetEndRoll_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetEndPosition
struct USplineMeshComponent_GetEndPosition_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetEndOffset
struct USplineMeshComponent_GetEndOffset_Params
{
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetBoundaryMin
struct USplineMeshComponent_GetBoundaryMin_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineMeshComponent.GetBoundaryMax
struct USplineMeshComponent_GetBoundaryMax_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.UpdateMesh
struct UInstancedSplineMeshComponent_UpdateMesh_Params
{
};

// Function Engine.InstancedSplineMeshComponent.ShowOrHideIndex
struct UInstancedSplineMeshComponent_ShowOrHideIndex_Params
{
	int Index; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool bShow; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.SetStaticMeshPrepation
struct UInstancedSplineMeshComponent_SetStaticMeshPrepation_Params
{
};

// Function Engine.InstancedSplineMeshComponent.SetSplineUpDir
struct UInstancedSplineMeshComponent_SetSplineUpDir_Params
{
	struct FVector InSplineUpDir; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.SetForwardAxis
struct UInstancedSplineMeshComponent_SetForwardAxis_Params
{
	TEnumAsByte<enum ESplineMeshAxis> InForwardAxis; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.SetBoundaryMin
struct UInstancedSplineMeshComponent_SetBoundaryMin_Params
{
	float InBoundaryMin; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.SetBoundaryMax
struct UInstancedSplineMeshComponent_SetBoundaryMax_Params
{
	float InBoundaryMax; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.ResetLocalBounds
struct UInstancedSplineMeshComponent_ResetLocalBounds_Params
{
};

// Function Engine.InstancedSplineMeshComponent.IsInstanceHide
struct UInstancedSplineMeshComponent_IsInstanceHide_Params
{
	int InstanceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetStartTangent
struct UInstancedSplineMeshComponent_GetStartTangent_Params
{
	int InstanceIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetStartPosition
struct UInstancedSplineMeshComponent_GetStartPosition_Params
{
	int InstanceIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetSplineUpDir
struct UInstancedSplineMeshComponent_GetSplineUpDir_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetInstanceNum
struct UInstancedSplineMeshComponent_GetInstanceNum_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetForwardAxis
struct UInstancedSplineMeshComponent_GetForwardAxis_Params
{
	TEnumAsByte<enum ESplineMeshAxis> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetEndTangent
struct UInstancedSplineMeshComponent_GetEndTangent_Params
{
	int InstanceIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetEndPosition
struct UInstancedSplineMeshComponent_GetEndPosition_Params
{
	int InstanceIndex; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetBoundaryMin
struct UInstancedSplineMeshComponent_GetBoundaryMin_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.GetBoundaryMax
struct UInstancedSplineMeshComponent_GetBoundaryMax_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.ClearIndex
struct UInstancedSplineMeshComponent_ClearIndex_Params
{
	int Index; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InstancedSplineMeshComponent.AddOrSetIndexStartAndEnd
struct UInstancedSplineMeshComponent_AddOrSetIndexStartAndEnd_Params
{
	int Index; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector StartPos; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector StartTangent; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector EndPos; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector EndTangent; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform InstanceTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool IsWorldSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUpdateMesh; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInterface.SetStreamingTextureMipOffset
struct UMaterialInterface_SetStreamingTextureMipOffset_Params
{
	int NewMipOffset; // (Parm, ZeroConstructor, IsPlainOldData)
	bool SizeLimited; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInterface.SetForceMipLevelsToBeResident
struct UMaterialInterface_SetForceMipLevelsToBeResident_Params
{
	bool OverrideForceMiplevelsToBeResident; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bForceMiplevelsToBeResidentValue; // (Parm, ZeroConstructor, IsPlainOldData)
	float ForceDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	int CinematicTextureGroups; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInterface.GetPhysicalMaterial
struct UMaterialInterface_GetPhysicalMaterial_Params
{
	class UPhysicalMaterial* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MaterialInterface.GetBaseMaterial
struct UMaterialInterface_GetBaseMaterial_Params
{
	class UMaterial* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CameraActor.SetSequencePrimitiveTrackingEnabled
struct ACameraActor_SetSequencePrimitiveTrackingEnabled_Params
{
	bool bEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraActor.SetFullScreen
struct ACameraActor_SetFullScreen_Params
{
	bool bNewFullScreen; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraActor.GetAutoActivatePlayerIndex
struct ACameraActor_GetAutoActivatePlayerIndex_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AmbientSound.Stop
struct AAmbientSound_Stop_Params
{
};

// Function Engine.AmbientSound.Play
struct AAmbientSound_Play_Params
{
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AmbientSound.FadeOut
struct AAmbientSound_FadeOut_Params
{
	float FadeOutDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	float FadeVolumeLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AmbientSound.FadeIn
struct AAmbientSound_FadeIn_Params
{
	float FadeInDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	float FadeVolumeLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AmbientSound.AdjustVolume
struct AAmbientSound_AdjustVolume_Params
{
	float AdjustVolumeDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	float AdjustVolumeLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSequenceBase.GetPlayLength
struct UAnimSequenceBase_GetPlayLength_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstanceContainerInterface.OnDeactived
struct UAnimInstanceContainerInterface_OnDeactived_Params
{
};

// Function Engine.AnimInstanceContainerInterface.OnActived
struct UAnimInstanceContainerInterface_OnActived_Params
{
};

// Function Engine.AnimInstanceContainer.SetTargetAnimInstance
struct UAnimInstanceContainer_SetTargetAnimInstance_Params
{
	class UClass* InstanceClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstanceContainer.SetSoftTargetAnimInstance
struct UAnimInstanceContainer_SetSoftTargetAnimInstance_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstanceContainer.RemoveCacheAnimInstance
struct UAnimInstanceContainer_RemoveCacheAnimInstance_Params
{
	class UClass* InstanceClass; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstanceContainer.IsRunningTargetAnimInstance
struct UAnimInstanceContainer_IsRunningTargetAnimInstance_Params
{
	class UClass* InstanceClass; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstanceContainer.IsReceiveInPoseNode
struct UAnimInstanceContainer_IsReceiveInPoseNode_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstanceContainer.GetTargetInstance
struct UAnimInstanceContainer_GetTargetInstance_Params
{
	bool bCheckPendingKill; // (Parm, ZeroConstructor, IsPlainOldData)
	class UAnimInstance* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimInstanceContainer.ClearCacheAnimInstance
struct UAnimInstanceContainer_ClearCacheAnimInstance_Params
{
};

// Function Engine.AnimInstanceContainer.AddCacheAnimInstance
struct UAnimInstanceContainer_AddCacheAnimInstance_Params
{
	class UClass* InstanceClass; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimNotifyState_Trail.OverridePSTemplate
struct UAnimNotifyState_Trail_OverridePSTemplate_Params
{
	class USkeletalMeshComponent* MeshComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UAnimSequenceBase* Animation; // (Parm, ZeroConstructor, IsPlainOldData)
	class UParticleSystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.StopAnim
struct UAnimSingleNodeInstance_StopAnim_Params
{
};

// Function Engine.AnimSingleNodeInstance.SetReverse
struct UAnimSingleNodeInstance_SetReverse_Params
{
	bool bInReverse; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetPreviewCurveOverride
struct UAnimSingleNodeInstance_SetPreviewCurveOverride_Params
{
	struct FName PoseName; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bRemoveIfZero; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetPositionWithPreviousTime
struct UAnimSingleNodeInstance_SetPositionWithPreviousTime_Params
{
	float InPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPreviousTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFireNotifies; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetPosition
struct UAnimSingleNodeInstance_SetPosition_Params
{
	float InPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFireNotifies; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetPlayRate
struct UAnimSingleNodeInstance_SetPlayRate_Params
{
	float InPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetPlaying
struct UAnimSingleNodeInstance_SetPlaying_Params
{
	bool bIsPlaying; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetLooping
struct UAnimSingleNodeInstance_SetLooping_Params
{
	bool bIsLooping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetBlendSpaceInput
struct UAnimSingleNodeInstance_SetBlendSpaceInput_Params
{
	struct FVector InBlendInput; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.SetAnimationAsset
struct UAnimSingleNodeInstance_SetAnimationAsset_Params
{
	class UAnimationAsset* NewAsset; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIsLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.PlayAnim
struct UAnimSingleNodeInstance_PlayAnim_Params
{
	bool bIsLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPlayRate; // (Parm, ZeroConstructor, IsPlainOldData)
	float InStartPosition; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.GetLength
struct UAnimSingleNodeInstance_GetLength_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimSingleNodeInstance.GetAnimationAsset
struct UAnimSingleNodeInstance_GetAnimationAsset_Params
{
	class UAnimationAsset* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ArrowComponent.SetArrowColor
struct UArrowComponent_SetArrowColor_Params
{
	struct FLinearColor NewColor; // (Parm, IsPlainOldData)
};

// Function Engine.AsyncActionLoadPrimaryAsset.AsyncLoadPrimaryAsset
struct UAsyncActionLoadPrimaryAsset_AsyncLoadPrimaryAsset_Params
{
	struct FPrimaryAssetId PrimaryAsset; // (Parm)
	TArray<struct FName> LoadBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UAsyncActionLoadPrimaryAsset* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AsyncActionLoadPrimaryAssetClass.AsyncLoadPrimaryAssetClass
struct UAsyncActionLoadPrimaryAssetClass_AsyncLoadPrimaryAssetClass_Params
{
	struct FPrimaryAssetId PrimaryAsset; // (Parm)
	TArray<struct FName> LoadBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UAsyncActionLoadPrimaryAssetClass* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AsyncActionLoadPrimaryAssetList.AsyncLoadPrimaryAssetList
struct UAsyncActionLoadPrimaryAssetList_AsyncLoadPrimaryAssetList_Params
{
	TArray<struct FPrimaryAssetId> PrimaryAssetList; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FName> LoadBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UAsyncActionLoadPrimaryAssetList* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AsyncActionLoadPrimaryAssetClassList.AsyncLoadPrimaryAssetClassList
struct UAsyncActionLoadPrimaryAssetClassList_AsyncLoadPrimaryAssetClassList_Params
{
	TArray<struct FPrimaryAssetId> PrimaryAssetList; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FName> LoadBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UAsyncActionLoadPrimaryAssetClassList* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AsyncActionChangePrimaryAssetBundles.AsyncChangeBundleStateForPrimaryAssetList
struct UAsyncActionChangePrimaryAssetBundles_AsyncChangeBundleStateForPrimaryAssetList_Params
{
	TArray<struct FPrimaryAssetId> PrimaryAssetList; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FName> AddBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FName> RemoveBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UAsyncActionChangePrimaryAssetBundles* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AsyncActionChangePrimaryAssetBundles.AsyncChangeBundleStateForMatchingPrimaryAssets
struct UAsyncActionChangePrimaryAssetBundles_AsyncChangeBundleStateForMatchingPrimaryAssets_Params
{
	TArray<struct FName> NewBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FName> OldBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UAsyncActionChangePrimaryAssetBundles* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.StartPrecompute
struct UAtmosphericFogComponent_StartPrecompute_Params
{
};

// Function Engine.AtmosphericFogComponent.SetSunMultiplier
struct UAtmosphericFogComponent_SetSunMultiplier_Params
{
	float NewSunMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetStartDistance
struct UAtmosphericFogComponent_SetStartDistance_Params
{
	float NewStartDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetPrecomputeParams
struct UAtmosphericFogComponent_SetPrecomputeParams_Params
{
	float DensityHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaxScatteringOrder; // (Parm, ZeroConstructor, IsPlainOldData)
	int InscatterAltitudeSampleNum; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetFogMultiplier
struct UAtmosphericFogComponent_SetFogMultiplier_Params
{
	float NewFogMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetDistanceScale
struct UAtmosphericFogComponent_SetDistanceScale_Params
{
	float NewDistanceScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetDistanceOffset
struct UAtmosphericFogComponent_SetDistanceOffset_Params
{
	float NewDistanceOffset; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetDensityOffset
struct UAtmosphericFogComponent_SetDensityOffset_Params
{
	float NewDensityOffset; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetDensityMultiplier
struct UAtmosphericFogComponent_SetDensityMultiplier_Params
{
	float NewDensityMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetDefaultLightColor
struct UAtmosphericFogComponent_SetDefaultLightColor_Params
{
	struct FLinearColor NewLightColor; // (Parm, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetDefaultBrightness
struct UAtmosphericFogComponent_SetDefaultBrightness_Params
{
	float NewBrightness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.SetAltitudeScale
struct UAtmosphericFogComponent_SetAltitudeScale_Params
{
	float NewAltitudeScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.DisableSunDisk
struct UAtmosphericFogComponent_DisableSunDisk_Params
{
	bool NewSunDisk; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AtmosphericFogComponent.DisableGroundScattering
struct UAtmosphericFogComponent_DisableGroundScattering_Params
{
	bool NewGroundScattering; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.Stop
struct UAudioComponent_Stop_Params
{
};

// Function Engine.AudioComponent.SetWaveParameter
struct UAudioComponent_SetWaveParameter_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	class USoundWave* InWave; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetVolumeMultiplier
struct UAudioComponent_SetVolumeMultiplier_Params
{
	float NewVolumeMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetUISound
struct UAudioComponent_SetUISound_Params
{
	bool bInUISound; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetSubmixSend
struct UAudioComponent_SetSubmixSend_Params
{
	class USoundSubmix* Submix; // (Parm, ZeroConstructor, IsPlainOldData)
	float SendLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetSound
struct UAudioComponent_SetSound_Params
{
	class USoundBase* NewSound; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetPitchMultiplier
struct UAudioComponent_SetPitchMultiplier_Params
{
	float NewPitchMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetPaused
struct UAudioComponent_SetPaused_Params
{
	bool bPause; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetLowPassFilterFrequency
struct UAudioComponent_SetLowPassFilterFrequency_Params
{
	float InLowPassFilterFrequency; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetLowPassFilterEnabled
struct UAudioComponent_SetLowPassFilterEnabled_Params
{
	bool InLowPassFilterEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetIntParameter
struct UAudioComponent_SetIntParameter_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	int inInt; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetFloatParameter
struct UAudioComponent_SetFloatParameter_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	float InFloat; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.SetBoolParameter
struct UAudioComponent_SetBoolParameter_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool InBool; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.Play
struct UAudioComponent_Play_Params
{
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.IsPlaying
struct UAudioComponent_IsPlaying_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AudioComponent.FadeOut
struct UAudioComponent_FadeOut_Params
{
	float FadeOutDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	float FadeVolumeLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.FadeIn
struct UAudioComponent_FadeIn_Params
{
	float FadeInDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	float FadeVolumeLevel; // (Parm, ZeroConstructor, IsPlainOldData)
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.BP_GetAttenuationSettingsToApply
struct UAudioComponent_BP_GetAttenuationSettingsToApply_Params
{
	struct FSoundAttenuationSettings OutAttenuationSettings; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AudioComponent.AdjustVolume
struct UAudioComponent_AdjustVolume_Params
{
	float AdjustVolumeDuration; // (Parm, ZeroConstructor, IsPlainOldData)
	float AdjustVolumeLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioComponent.AdjustAttenuation
struct UAudioComponent_AdjustAttenuation_Params
{
	struct FSoundAttenuationSettings InAttenuationSettings; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.AudioVolume.SetReverbSettings
struct AAudioVolume_SetReverbSettings_Params
{
	struct FReverbSettings NewReverbSettings; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.AudioVolume.SetPriority
struct AAudioVolume_SetPriority_Params
{
	float NewPriority; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioVolume.SetInteriorSettings
struct AAudioVolume_SetInteriorSettings_Params
{
	struct FInteriorSettings NewInteriorSettings; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.AudioVolume.SetEnabled
struct AAudioVolume_SetEnabled_Params
{
	bool bNewEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AudioVolume.OnRep_bEnabled
struct AAudioVolume_OnRep_bEnabled_Params
{
};

// Function Engine.AvoidanceManager.RegisterMovementComponent
struct UAvoidanceManager_RegisterMovementComponent_Params
{
	class UMovementComponent* MovementComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	float AvoidanceWeight; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AvoidanceManager.GetObjectCount
struct UAvoidanceManager_GetObjectCount_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AvoidanceManager.GetNewAvoidanceUID
struct UAvoidanceManager_GetNewAvoidanceUID_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AvoidanceManager.GetAvoidanceVelocityForComponent
struct UAvoidanceManager_GetAvoidanceVelocityForComponent_Params
{
	class UMovementComponent* MovementComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.BillboardComponent.SetUV
struct UBillboardComponent_SetUV_Params
{
	int NewU; // (Parm, ZeroConstructor, IsPlainOldData)
	int NewUL; // (Parm, ZeroConstructor, IsPlainOldData)
	int NewV; // (Parm, ZeroConstructor, IsPlainOldData)
	int NewVL; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BillboardComponent.SetSpriteAndUV
struct UBillboardComponent_SetSpriteAndUV_Params
{
	class UTexture2D* NewSprite; // (Parm, ZeroConstructor, IsPlainOldData)
	int NewU; // (Parm, ZeroConstructor, IsPlainOldData)
	int NewUL; // (Parm, ZeroConstructor, IsPlainOldData)
	int NewV; // (Parm, ZeroConstructor, IsPlainOldData)
	int NewVL; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BillboardComponent.SetSprite
struct UBillboardComponent_SetSprite_Params
{
	class UTexture2D* NewSprite; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintMapLibrary.SetMapPropertyByName
struct UBlueprintMapLibrary_SetMapPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	TMap<int, int> Value; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.BlueprintMapLibrary.Map_Values
struct UBlueprintMapLibrary_Map_Values_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<int> Values; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.BlueprintMapLibrary.Map_Remove
struct UBlueprintMapLibrary_Map_Remove_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Key; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintMapLibrary.Map_Length
struct UBlueprintMapLibrary_Map_Length_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintMapLibrary.Map_Keys
struct UBlueprintMapLibrary_Map_Keys_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<int> Keys; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.BlueprintMapLibrary.Map_Find
struct UBlueprintMapLibrary_Map_Find_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Key; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int Value; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintMapLibrary.Map_Contains
struct UBlueprintMapLibrary_Map_Contains_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Key; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintMapLibrary.Map_Clear
struct UBlueprintMapLibrary_Map_Clear_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.BlueprintMapLibrary.Map_Add
struct UBlueprintMapLibrary_Map_Add_Params
{
	TMap<int, int> TargetMap; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Key; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int Value; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.BlueprintPlatformLibrary.ScheduleLocalNotificationFromNow
struct UBlueprintPlatformLibrary_ScheduleLocalNotificationFromNow_Params
{
	int inSecondsFromNow; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText Title; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText Body; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText Action; // (ConstParm, Parm, OutParm, ReferenceParm)
	int NotificationID; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintPlatformLibrary.ScheduleLocalNotificationBadgeFromNow
struct UBlueprintPlatformLibrary_ScheduleLocalNotificationBadgeFromNow_Params
{
	int inSecondsFromNow; // (Parm, ZeroConstructor, IsPlainOldData)
	int NotificationID; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintPlatformLibrary.ScheduleLocalNotificationBadgeAtTime
struct UBlueprintPlatformLibrary_ScheduleLocalNotificationBadgeAtTime_Params
{
	struct FDateTime FireDateTime; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool LocalTime; // (Parm, ZeroConstructor, IsPlainOldData)
	int NotificationID; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintPlatformLibrary.ScheduleLocalNotificationAtTime
struct UBlueprintPlatformLibrary_ScheduleLocalNotificationAtTime_Params
{
	struct FDateTime FireDateTime; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool LocalTime; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText Title; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText Body; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText Action; // (ConstParm, Parm, OutParm, ReferenceParm)
	int NotificationID; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintPlatformLibrary.GetLaunchNotification
struct UBlueprintPlatformLibrary_GetLaunchNotification_Params
{
	bool NotificationLaunchedApp; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FString ActivationEvent; // (Parm, OutParm, ZeroConstructor)
	int FireDate; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintPlatformLibrary.ClearAllLocalNotifications
struct UBlueprintPlatformLibrary_ClearAllLocalNotifications_Params
{
};

// Function Engine.BlueprintPlatformLibrary.CancelLocalNotification
struct UBlueprintPlatformLibrary_CancelLocalNotification_Params
{
	int NotificationID; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintSetLibrary.SetSetPropertyByName
struct UBlueprintSetLibrary_SetSetPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.BlueprintSetLibrary.Set_Union
struct UBlueprintSetLibrary_Set_Union_Params
{
};

// Function Engine.BlueprintSetLibrary.Set_ToArray
struct UBlueprintSetLibrary_Set_ToArray_Params
{
	TArray<int> Result; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.BlueprintSetLibrary.Set_RemoveItems
struct UBlueprintSetLibrary_Set_RemoveItems_Params
{
	TArray<int> Items; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.BlueprintSetLibrary.Set_Remove
struct UBlueprintSetLibrary_Set_Remove_Params
{
	int Item; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintSetLibrary.Set_Length
struct UBlueprintSetLibrary_Set_Length_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintSetLibrary.Set_Intersection
struct UBlueprintSetLibrary_Set_Intersection_Params
{
};

// Function Engine.BlueprintSetLibrary.Set_Difference
struct UBlueprintSetLibrary_Set_Difference_Params
{
};

// Function Engine.BlueprintSetLibrary.Set_Contains
struct UBlueprintSetLibrary_Set_Contains_Params
{
	int ItemToFind; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.BlueprintSetLibrary.Set_Clear
struct UBlueprintSetLibrary_Set_Clear_Params
{
};

// Function Engine.BlueprintSetLibrary.Set_AddItems
struct UBlueprintSetLibrary_Set_AddItems_Params
{
	TArray<int> NewItems; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.BlueprintSetLibrary.Set_Add
struct UBlueprintSetLibrary_Set_Add_Params
{
	int NewItem; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.ReflectionCaptureComponent.SetRealtimeColor
struct UReflectionCaptureComponent_SetRealtimeColor_Params
{
	struct FVector InColor; // (Parm, IsPlainOldData)
};

// Function Engine.ReflectionCaptureComponent.SetRealtimeBrightness
struct UReflectionCaptureComponent_SetRealtimeBrightness_Params
{
	float InBrightness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ReflectionCaptureComponent.SetRealtimeAngle
struct UReflectionCaptureComponent_SetRealtimeAngle_Params
{
	float InAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraAnimInst.Stop
struct UCameraAnimInst_Stop_Params
{
	bool bImmediate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraAnimInst.SetScale
struct UCameraAnimInst_SetScale_Params
{
	float NewDuration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraAnimInst.SetDuration
struct UCameraAnimInst_SetDuration_Params
{
	float NewDuration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CameraAnimInst.SetCurrentTime
struct UCameraAnimInst_SetCurrentTime_Params
{
	float NewTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Canvas.K2_TextSize
struct UCanvas_K2_TextSize_Params
{
	class UFont* RenderFont; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString RenderText; // (Parm, ZeroConstructor)
	struct FVector2D Scale; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Canvas.K2_StrLen
struct UCanvas_K2_StrLen_Params
{
	class UFont* RenderFont; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString RenderText; // (Parm, ZeroConstructor)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Canvas.K2_Project
struct UCanvas_K2_Project_Params
{
	struct FVector WorldLocation; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Canvas.K2_DrawTriangle
struct UCanvas_K2_DrawTriangle_Params
{
	class UTexture* RenderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FCanvasUVTri> Triangles; // (Parm, ZeroConstructor)
};

// Function Engine.Canvas.K2_DrawTexture
struct UCanvas_K2_DrawTexture_Params
{
	class UTexture* RenderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ScreenPosition; // (Parm, IsPlainOldData)
	struct FVector2D ScreenSize; // (Parm, IsPlainOldData)
	struct FVector2D CoordinatePosition; // (Parm, IsPlainOldData)
	struct FVector2D CoordinateSize; // (Parm, IsPlainOldData)
	struct FLinearColor RenderColor; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EBlendMode> BlendMode; // (Parm, ZeroConstructor, IsPlainOldData)
	float Rotation; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D PivotPoint; // (Parm, IsPlainOldData)
};

// Function Engine.Canvas.K2_DrawText
struct UCanvas_K2_DrawText_Params
{
	class UFont* RenderFont; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString RenderText; // (Parm, ZeroConstructor)
	struct FVector2D ScreenPosition; // (Parm, IsPlainOldData)
	struct FLinearColor RenderColor; // (Parm, IsPlainOldData)
	float Kerning; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ShadowColor; // (Parm, IsPlainOldData)
	struct FVector2D ShadowOffset; // (Parm, IsPlainOldData)
	bool bCentreX; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bCentreY; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bOutlined; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor OutlineColor; // (Parm, IsPlainOldData)
};

// Function Engine.Canvas.K2_DrawPolygon
struct UCanvas_K2_DrawPolygon_Params
{
	class UTexture* RenderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ScreenPosition; // (Parm, IsPlainOldData)
	struct FVector2D Radius; // (Parm, IsPlainOldData)
	int NumberOfSides; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor RenderColor; // (Parm, IsPlainOldData)
};

// Function Engine.Canvas.K2_DrawMaterialTriangle
struct UCanvas_K2_DrawMaterialTriangle_Params
{
	class UMaterialInterface* RenderMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FCanvasUVTri> Triangles; // (Parm, ZeroConstructor)
};

// Function Engine.Canvas.K2_DrawMaterial
struct UCanvas_K2_DrawMaterial_Params
{
	class UMaterialInterface* RenderMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ScreenPosition; // (Parm, IsPlainOldData)
	struct FVector2D ScreenSize; // (Parm, IsPlainOldData)
	struct FVector2D CoordinatePosition; // (Parm, IsPlainOldData)
	struct FVector2D CoordinateSize; // (Parm, IsPlainOldData)
	float Rotation; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D PivotPoint; // (Parm, IsPlainOldData)
};

// Function Engine.Canvas.K2_DrawLine
struct UCanvas_K2_DrawLine_Params
{
	struct FVector2D ScreenPositionA; // (Parm, IsPlainOldData)
	struct FVector2D ScreenPositionB; // (Parm, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor RenderColor; // (Parm, IsPlainOldData)
};

// Function Engine.Canvas.K2_DrawBox
struct UCanvas_K2_DrawBox_Params
{
	struct FVector2D ScreenPosition; // (Parm, IsPlainOldData)
	struct FVector2D ScreenSize; // (Parm, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Canvas.K2_DrawBorder
struct UCanvas_K2_DrawBorder_Params
{
	class UTexture* BorderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* BackgroundTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* LeftBorderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* RightBorderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* TopBorderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* BottomBorderTexture; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ScreenPosition; // (Parm, IsPlainOldData)
	struct FVector2D ScreenSize; // (Parm, IsPlainOldData)
	struct FVector2D CoordinatePosition; // (Parm, IsPlainOldData)
	struct FVector2D CoordinateSize; // (Parm, IsPlainOldData)
	struct FLinearColor RenderColor; // (Parm, IsPlainOldData)
	struct FVector2D BorderScale; // (Parm, IsPlainOldData)
	struct FVector2D BackgroundScale; // (Parm, IsPlainOldData)
	float Rotation; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D PivotPoint; // (Parm, IsPlainOldData)
	struct FVector2D CornerSize; // (Parm, IsPlainOldData)
};

// Function Engine.Canvas.K2_Deproject
struct UCanvas_K2_Deproject_Params
{
	struct FVector2D ScreenPosition; // (Parm, IsPlainOldData)
	struct FVector WorldOrigin; // (Parm, OutParm, IsPlainOldData)
	struct FVector WorldDirection; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.Texture.Blueprint_ChangeMaxTextureSize
struct UTexture_Blueprint_ChangeMaxTextureSize_Params
{
	int Size; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CanvasRenderTarget2D.UpdateResource
struct UCanvasRenderTarget2D_UpdateResource_Params
{
};

// Function Engine.CanvasRenderTarget2D.ReceiveUpdate
struct UCanvasRenderTarget2D_ReceiveUpdate_Params
{
	class UCanvas* Canvas; // (Parm, ZeroConstructor, IsPlainOldData)
	int Width; // (Parm, ZeroConstructor, IsPlainOldData)
	int Height; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CanvasRenderTarget2D.GetSize
struct UCanvasRenderTarget2D_GetSize_Params
{
	int Width; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Height; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CanvasRenderTarget2D.CreateCanvasRenderTarget2D
struct UCanvasRenderTarget2D_CreateCanvasRenderTarget2D_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* CanvasRenderTarget2DClass; // (Parm, ZeroConstructor, IsPlainOldData)
	int Width; // (Parm, ZeroConstructor, IsPlainOldData)
	int Height; // (Parm, ZeroConstructor, IsPlainOldData)
	class UCanvasRenderTarget2D* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CheatManager.Walk
struct UCheatManager_Walk_Params
{
};

// Function Engine.CheatManager.ViewSelf
struct UCheatManager_ViewSelf_Params
{
};

// Function Engine.CheatManager.ViewPlayer
struct UCheatManager_ViewPlayer_Params
{
	struct FString S; // (Parm, ZeroConstructor)
};

// Function Engine.CheatManager.ViewClass
struct UCheatManager_ViewClass_Params
{
	class UClass* DesiredClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.ViewActor
struct UCheatManager_ViewActor_Params
{
	struct FName actorName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.TriggerCrash
struct UCheatManager_TriggerCrash_Params
{
};

// Function Engine.CheatManager.ToggleDebugCamera
struct UCheatManager_ToggleDebugCamera_Params
{
};

// Function Engine.CheatManager.ToggleAILogging
struct UCheatManager_ToggleAILogging_Params
{
};

// Function Engine.CheatManager.TestCollisionDistance
struct UCheatManager_TestCollisionDistance_Params
{
};

// Function Engine.CheatManager.Teleport
struct UCheatManager_Teleport_Params
{
};

// Function Engine.CheatManager.Summon
struct UCheatManager_Summon_Params
{
	struct FString ClassName; // (Parm, ZeroConstructor)
};

// Function Engine.CheatManager.StreamLevelOut
struct UCheatManager_StreamLevelOut_Params
{
	struct FName PackageName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.StreamLevelIn
struct UCheatManager_StreamLevelIn_Params
{
	struct FName PackageName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.Slomo
struct UCheatManager_Slomo_Params
{
	float NewTimeDilation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.SetWorldOrigin
struct UCheatManager_SetWorldOrigin_Params
{
};

// Function Engine.CheatManager.SetNavDrawDistance
struct UCheatManager_SetNavDrawDistance_Params
{
	float DrawDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.SetMouseSensitivityToDefault
struct UCheatManager_SetMouseSensitivityToDefault_Params
{
};

// Function Engine.CheatManager.ServerToggleAILogging
struct UCheatManager_ServerToggleAILogging_Params
{
};

// Function Engine.CheatManager.ReceiveInitCheatManager
struct UCheatManager_ReceiveInitCheatManager_Params
{
};

// Function Engine.CheatManager.ReceiveEndPlay
struct UCheatManager_ReceiveEndPlay_Params
{
};

// Function Engine.CheatManager.RebuildNavigation
struct UCheatManager_RebuildNavigation_Params
{
};

// Function Engine.CheatManager.PlayersOnly
struct UCheatManager_PlayersOnly_Params
{
};

// Function Engine.CheatManager.OnlyLoadLevel
struct UCheatManager_OnlyLoadLevel_Params
{
	struct FName PackageName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.LogLoc
struct UCheatManager_LogLoc_Params
{
};

// Function Engine.CheatManager.InvertMouse
struct UCheatManager_InvertMouse_Params
{
};

// Function Engine.CheatManager.God
struct UCheatManager_God_Params
{
};

// Function Engine.CheatManager.Ghost
struct UCheatManager_Ghost_Params
{
};

// Function Engine.CheatManager.FreezeFrame
struct UCheatManager_FreezeFrame_Params
{
	float Delay; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.Fly
struct UCheatManager_Fly_Params
{
};

// Function Engine.CheatManager.FlushLog
struct UCheatManager_FlushLog_Params
{
};

// Function Engine.CheatManager.EnableDebugCamera
struct UCheatManager_EnableDebugCamera_Params
{
};

// Function Engine.CheatManager.DumpVoiceMutingState
struct UCheatManager_DumpVoiceMutingState_Params
{
};

// Function Engine.CheatManager.DumpPartyState
struct UCheatManager_DumpPartyState_Params
{
};

// Function Engine.CheatManager.DumpOnlineSessionState
struct UCheatManager_DumpOnlineSessionState_Params
{
};

// Function Engine.CheatManager.DumpChatState
struct UCheatManager_DumpChatState_Params
{
};

// Function Engine.CheatManager.DisableDebugCamera
struct UCheatManager_DisableDebugCamera_Params
{
};

// Function Engine.CheatManager.DestroyTarget
struct UCheatManager_DestroyTarget_Params
{
};

// Function Engine.CheatManager.DestroyPawns
struct UCheatManager_DestroyPawns_Params
{
	class UClass* aClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.DestroyAllPawnsExceptTarget
struct UCheatManager_DestroyAllPawnsExceptTarget_Params
{
};

// Function Engine.CheatManager.DestroyAll
struct UCheatManager_DestroyAll_Params
{
	class UClass* aClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.DebugCapsuleSweepSize
struct UCheatManager_DebugCapsuleSweepSize_Params
{
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.DebugCapsuleSweepPawn
struct UCheatManager_DebugCapsuleSweepPawn_Params
{
};

// Function Engine.CheatManager.DebugCapsuleSweepComplex
struct UCheatManager_DebugCapsuleSweepComplex_Params
{
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.DebugCapsuleSweepClear
struct UCheatManager_DebugCapsuleSweepClear_Params
{
};

// Function Engine.CheatManager.DebugCapsuleSweepChannel
struct UCheatManager_DebugCapsuleSweepChannel_Params
{
	TEnumAsByte<enum ECollisionChannel> Channel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.DebugCapsuleSweepCapture
struct UCheatManager_DebugCapsuleSweepCapture_Params
{
};

// Function Engine.CheatManager.DebugCapsuleSweep
struct UCheatManager_DebugCapsuleSweep_Params
{
};

// Function Engine.CheatManager.DamageTarget
struct UCheatManager_DamageTarget_Params
{
	float DamageAmount; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.CheatScript
struct UCheatManager_CheatScript_Params
{
	struct FString ScriptName; // (Parm, ZeroConstructor)
};

// Function Engine.CheatManager.ChangeSize
struct UCheatManager_ChangeSize_Params
{
	float F; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.BugItStringCreator
struct UCheatManager_BugItStringCreator_Params
{
	struct FVector ViewLocation; // (Parm, IsPlainOldData)
	struct FRotator ViewRotation; // (Parm, IsPlainOldData)
	struct FString GoString; // (Parm, OutParm, ZeroConstructor)
	struct FString LocString; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.CheatManager.BugItGo
struct UCheatManager_BugItGo_Params
{
	float X; // (Parm, ZeroConstructor, IsPlainOldData)
	float Y; // (Parm, ZeroConstructor, IsPlainOldData)
	float Z; // (Parm, ZeroConstructor, IsPlainOldData)
	float Pitch; // (Parm, ZeroConstructor, IsPlainOldData)
	float Yaw; // (Parm, ZeroConstructor, IsPlainOldData)
	float Roll; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CheatManager.BugIt
struct UCheatManager_BugIt_Params
{
	struct FString ScreenShotDescription; // (Parm, ZeroConstructor)
};

// Function Engine.ChildActorComponent.SetChildActorClass
struct UChildActorComponent_SetChildActorClass_Params
{
	class UClass* InClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameViewportClient.SSSwapControllers
struct UGameViewportClient_SSSwapControllers_Params
{
};

// Function Engine.GameViewportClient.ShowTitleSafeArea
struct UGameViewportClient_ShowTitleSafeArea_Params
{
};

// Function Engine.GameViewportClient.SetConsoleTarget
struct UGameViewportClient_SetConsoleTarget_Params
{
	int playerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameViewportClient.RemoveViewportChangeDelegate
struct UGameViewportClient_RemoveViewportChangeDelegate_Params
{
	struct FScriptDelegate Delegate; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.GameViewportClient.AddViewportChangeDelegate
struct UGameViewportClient_AddViewportChangeDelegate_Params
{
	struct FScriptDelegate Delegate; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.CurveBase.GetValueRange
struct UCurveBase_GetValueRange_Params
{
	float MinValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float MaxValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CurveBase.GetTimeRange
struct UCurveBase_GetTimeRange_Params
{
	float MinTime; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float MaxTime; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.CurveFloat.GetFloatValue
struct UCurveFloat_GetFloatValue_Params
{
	float InTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CurveLinearColor.GetLinearColorValue
struct UCurveLinearColor_GetLinearColorValue_Params
{
	float InTime; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.CurveSourceInterface.GetCurveValue
struct UCurveSourceInterface_GetCurveValue_Params
{
	struct FName CurveName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CurveSourceInterface.GetCurves
struct UCurveSourceInterface_GetCurves_Params
{
	TArray<struct FNamedCurveValue> OutValues; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.CurveSourceInterface.GetBindingName
struct UCurveSourceInterface_GetBindingName_Params
{
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.CurveVector.GetVectorValue
struct UCurveVector_GetVectorValue_Params
{
	float InTime; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.DataTableFunctionLibrary.GetDataTableRowNames
struct UDataTableFunctionLibrary_GetDataTableRowNames_Params
{
	class UDataTable* Table; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName> OutRowNames; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.DataTableFunctionLibrary.GetDataTableRowFromName
struct UDataTableFunctionLibrary_GetDataTableRowFromName_Params
{
	class UDataTable* Table; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName RowName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTableRowBase OutRow; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DataTableFunctionLibrary.EvaluateCurveTableRow
struct UDataTableFunctionLibrary_EvaluateCurveTableRow_Params
{
	class UCurveTable* CurveTable; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName RowName; // (Parm, ZeroConstructor, IsPlainOldData)
	float InXY; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EEvaluateCurveTableResult> OutResult; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutXY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FString ContextString; // (Parm, ZeroConstructor)
};

// Function Engine.DebugCameraController.ToggleDisplay
struct ADebugCameraController_ToggleDisplay_Params
{
};

// Function Engine.DebugCameraController.ShowDebugSelectedInfo
struct ADebugCameraController_ShowDebugSelectedInfo_Params
{
};

// Function Engine.DebugCameraController.SetPawnMovementSpeedScale
struct ADebugCameraController_SetPawnMovementSpeedScale_Params
{
	float NewSpeedScale; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DebugCameraController.ReceiveOnDeactivate
struct ADebugCameraController_ReceiveOnDeactivate_Params
{
	class APlayerController* RestoredPC; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DebugCameraController.ReceiveOnActorSelected
struct ADebugCameraController_ReceiveOnActorSelected_Params
{
	class AActor* NewSelectedActor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector SelectHitLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector SelectHitNormal; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FHitResult Hit; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.DebugCameraController.ReceiveOnActivate
struct ADebugCameraController_ReceiveOnActivate_Params
{
	class APlayerController* OriginalPC; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DebugCameraController.GetSelectedActor
struct ADebugCameraController_GetSelectedActor_Params
{
	class AActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalActor.SetDecalMaterial
struct ADecalActor_SetDecalMaterial_Params
{
	class UMaterialInterface* NewDecalMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalActor.GetDecalMaterial
struct ADecalActor_GetDecalMaterial_Params
{
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalActor.CreateDynamicMaterialInstance
struct ADecalActor_CreateDynamicMaterialInstance_Params
{
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingParameterComponent.GetUVScaleBias
struct UDecalBakingParameterComponent_GetUVScaleBias_Params
{
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingParameterComponent.GetDecalBounds
struct UDecalBakingParameterComponent_GetDecalBounds_Params
{
	struct FBoxSphereBounds ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalBakingParameterComponent.GetCropUVScaleBias
struct UDecalBakingParameterComponent_GetCropUVScaleBias_Params
{
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalComponent.SetSortOrder
struct UDecalComponent_SetSortOrder_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalComponent.SetFadeScreenSize
struct UDecalComponent_SetFadeScreenSize_Params
{
	float NewFadeScreenSize; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalComponent.SetFadeOut
struct UDecalComponent_SetFadeOut_Params
{
	float StartDelay; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	bool DestroyOwnerAfterFade; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalComponent.SetDecalMaterial
struct UDecalComponent_SetDecalMaterial_Params
{
	class UMaterialInterface* NewDecalMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DecalComponent.GetFadeStartDelay
struct UDecalComponent_GetFadeStartDelay_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalComponent.GetFadeDuration
struct UDecalComponent_GetFadeDuration_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalComponent.GetDecalMaterial
struct UDecalComponent_GetDecalMaterial_Params
{
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.DecalComponent.CreateDynamicMaterialInstance
struct UDecalComponent_CreateDynamicMaterialInstance_Params
{
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Light.ToggleEnabled
struct ALight_ToggleEnabled_Params
{
};

// Function Engine.Light.SetLightFunctionScale
struct ALight_SetLightFunctionScale_Params
{
	struct FVector NewLightFunctionScale; // (Parm, IsPlainOldData)
};

// Function Engine.Light.SetLightFunctionMaterial
struct ALight_SetLightFunctionMaterial_Params
{
	class UMaterialInterface* NewLightFunctionMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Light.SetLightFunctionFadeDistance
struct ALight_SetLightFunctionFadeDistance_Params
{
	float NewLightFunctionFadeDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Light.SetLightColor
struct ALight_SetLightColor_Params
{
	struct FLinearColor NewLightColor; // (Parm, IsPlainOldData)
};

// Function Engine.Light.SetEnabled
struct ALight_SetEnabled_Params
{
	bool bSetEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Light.SetCastShadows
struct ALight_SetCastShadows_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Light.SetBrightness
struct ALight_SetBrightness_Params
{
	float NewBrightness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Light.SetAffectTranslucentLighting
struct ALight_SetAffectTranslucentLighting_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Light.OnRep_bEnabled
struct ALight_OnRep_bEnabled_Params
{
};

// Function Engine.Light.IsEnabled
struct ALight_IsEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Light.GetLightColor
struct ALight_GetLightColor_Params
{
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.Light.GetBrightness
struct ALight_GetBrightness_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LightComponentBase.SetCastVolumetricShadow
struct ULightComponentBase_SetCastVolumetricShadow_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponentBase.SetCastShadows
struct ULightComponentBase_SetCastShadows_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponentBase.GetLightColor
struct ULightComponentBase_GetLightColor_Params
{
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.LightComponent.SetVolumetricScatteringIntensity
struct ULightComponent_SetVolumetricScatteringIntensity_Params
{
	float NewIntensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetTemperature
struct ULightComponent_SetTemperature_Params
{
	float NewTemperature; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetShadowBias
struct ULightComponent_SetShadowBias_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetLightPriority
struct ULightComponent_SetLightPriority_Params
{
	int Priority; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetLightFunctionScale
struct ULightComponent_SetLightFunctionScale_Params
{
	struct FVector NewLightFunctionScale; // (Parm, IsPlainOldData)
};

// Function Engine.LightComponent.SetLightFunctionMaterial
struct ULightComponent_SetLightFunctionMaterial_Params
{
	class UMaterialInterface* NewLightFunctionMaterial; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetLightFunctionFadeDistance
struct ULightComponent_SetLightFunctionFadeDistance_Params
{
	float NewLightFunctionFadeDistance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetLightFunctionDisabledBrightness
struct ULightComponent_SetLightFunctionDisabledBrightness_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetLightColor
struct ULightComponent_SetLightColor_Params
{
	struct FLinearColor NewLightColor; // (Parm, IsPlainOldData)
	bool bSRGB; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetIntensity
struct ULightComponent_SetIntensity_Params
{
	float NewIntensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetIndirectLightingIntensity
struct ULightComponent_SetIndirectLightingIntensity_Params
{
	float NewIntensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetIESTexture
struct ULightComponent_SetIESTexture_Params
{
	class UTextureLightProfile* NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetEnableLightShaftBloom
struct ULightComponent_SetEnableLightShaftBloom_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetBloomTint
struct ULightComponent_SetBloomTint_Params
{
	struct FColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.LightComponent.SetBloomThreshold
struct ULightComponent_SetBloomThreshold_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetBloomScale
struct ULightComponent_SetBloomScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetAffectTranslucentLighting
struct ULightComponent_SetAffectTranslucentLighting_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.SetAffectDynamicIndirectLighting
struct ULightComponent_SetAffectDynamicIndirectLighting_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LightComponent.ForceUpdateShadowState
struct ULightComponent_ForceUpdateShadowState_Params
{
};

// Function Engine.DirectionalLightComponent.SetShadowDistanceFadeoutFraction
struct UDirectionalLightComponent_SetShadowDistanceFadeoutFraction_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetOcclusionMaskDarkness
struct UDirectionalLightComponent_SetOcclusionMaskDarkness_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetLightShaftOverrideDirection
struct UDirectionalLightComponent_SetLightShaftOverrideDirection_Params
{
	struct FVector NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetEnableLightShaftOcclusion
struct UDirectionalLightComponent_SetEnableLightShaftOcclusion_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetDynamicShadowDistanceStationaryLight
struct UDirectionalLightComponent_SetDynamicShadowDistanceStationaryLight_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetDynamicShadowDistanceMovableLight
struct UDirectionalLightComponent_SetDynamicShadowDistanceMovableLight_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetDynamicShadowCascades
struct UDirectionalLightComponent_SetDynamicShadowCascades_Params
{
	int NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCloudShadowWinSpeed
struct UDirectionalLightComponent_SetCloudShadowWinSpeed_Params
{
	struct FVector2D InWinSpeed; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCloudShadowTileSize
struct UDirectionalLightComponent_SetCloudShadowTileSize_Params
{
	float InValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCloudShadowTexture
struct UDirectionalLightComponent_SetCloudShadowTexture_Params
{
	class UTexture* InTexture; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCloudShadowDensity
struct UDirectionalLightComponent_SetCloudShadowDensity_Params
{
	float InDensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCastsCloudShadow
struct UDirectionalLightComponent_SetCastsCloudShadow_Params
{
	bool InValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCastPhotonShadow
struct UDirectionalLightComponent_SetCastPhotonShadow_Params
{
	bool InValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCastPhotonPerObjectShadow
struct UDirectionalLightComponent_SetCastPhotonPerObjectShadow_Params
{
	bool InValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCascadeTransitionFraction
struct UDirectionalLightComponent_SetCascadeTransitionFraction_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetCascadeDistributionExponent
struct UDirectionalLightComponent_SetCascadeDistributionExponent_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.DirectionalLightComponent.SetAtmosphereSunLight
struct UDirectionalLightComponent_SetAtmosphereSunLight_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Texture2D.Blueprint_GetSizeY
struct UTexture2D_Blueprint_GetSizeY_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Texture2D.Blueprint_GetSizeX
struct UTexture2D_Blueprint_GetSizeX_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Emitter.ToggleActive
struct AEmitter_ToggleActive_Params
{
};

// Function Engine.Emitter.SetVectorParameter
struct AEmitter_SetVectorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Param; // (Parm, IsPlainOldData)
};

// Function Engine.Emitter.SetTemplate
struct AEmitter_SetTemplate_Params
{
	class UParticleSystem* NewTemplate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Emitter.SetMaterialParameter
struct AEmitter_SetMaterialParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Emitter.SetFloatParameter
struct AEmitter_SetFloatParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Emitter.SetColorParameter
struct AEmitter_SetColorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor Param; // (Parm, IsPlainOldData)
};

// Function Engine.Emitter.SetActorParameter
struct AEmitter_SetActorParameter_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class AActor* Param; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.Emitter.OnRep_bCurrentlyActive
struct AEmitter_OnRep_bCurrentlyActive_Params
{
};

// Function Engine.Emitter.OnParticleSystemFinished
struct AEmitter_OnParticleSystemFinished_Params
{
	class UParticleSystemComponent* FinishedComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.Emitter.IsActive
struct AEmitter_IsActive_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.Emitter.Deactivate
struct AEmitter_Deactivate_Params
{
};

// Function Engine.Emitter.Activate
struct AEmitter_Activate_Params
{
};

// Function Engine.ExponentialHeightFog.OnRep_bEnabled
struct AExponentialHeightFog_OnRep_bEnabled_Params
{
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogStartDistance
struct UExponentialHeightFogComponent_SetVolumetricFogStartDistance_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogScatteringDistribution
struct UExponentialHeightFogComponent_SetVolumetricFogScatteringDistribution_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogNoiseTransform
struct UExponentialHeightFogComponent_SetVolumetricFogNoiseTransform_Params
{
	struct FTransform Transform; // (Parm, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogNoiseTexture
struct UExponentialHeightFogComponent_SetVolumetricFogNoiseTexture_Params
{
	class UTexture2D* NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogExtinctionScale
struct UExponentialHeightFogComponent_SetVolumetricFogExtinctionScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogEmissive
struct UExponentialHeightFogComponent_SetVolumetricFogEmissive_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogDistance
struct UExponentialHeightFogComponent_SetVolumetricFogDistance_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFogAlbedo
struct UExponentialHeightFogComponent_SetVolumetricFogAlbedo_Params
{
	struct FColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetVolumetricFog
struct UExponentialHeightFogComponent_SetVolumetricFog_Params
{
	bool bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetStartDistance
struct UExponentialHeightFogComponent_SetStartDistance_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetNonDirectionalInscatteringColorDistance
struct UExponentialHeightFogComponent_SetNonDirectionalInscatteringColorDistance_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetInscatteringTextureTint
struct UExponentialHeightFogComponent_SetInscatteringTextureTint_Params
{
	struct FLinearColor Value; // (Parm, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetInscatteringColorCubemapAngle
struct UExponentialHeightFogComponent_SetInscatteringColorCubemapAngle_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetInscatteringColorCubemap
struct UExponentialHeightFogComponent_SetInscatteringColorCubemap_Params
{
	class UTextureCube* Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetFullyDirectionalInscatteringColorDistance
struct UExponentialHeightFogComponent_SetFullyDirectionalInscatteringColorDistance_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetFogMaxOpacity
struct UExponentialHeightFogComponent_SetFogMaxOpacity_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetFogInscatteringColor
struct UExponentialHeightFogComponent_SetFogInscatteringColor_Params
{
	struct FLinearColor Value; // (Parm, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetFogHeightFalloff
struct UExponentialHeightFogComponent_SetFogHeightFalloff_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetFogDensity
struct UExponentialHeightFogComponent_SetFogDensity_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetFogCutoffDistance
struct UExponentialHeightFogComponent_SetFogCutoffDistance_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetDirectionalInscatteringStartDistance
struct UExponentialHeightFogComponent_SetDirectionalInscatteringStartDistance_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetDirectionalInscatteringGapControl
struct UExponentialHeightFogComponent_SetDirectionalInscatteringGapControl_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetDirectionalInscatteringExponent
struct UExponentialHeightFogComponent_SetDirectionalInscatteringExponent_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetDirectionalInscatteringColor
struct UExponentialHeightFogComponent_SetDirectionalInscatteringColor_Params
{
	struct FLinearColor Value; // (Parm, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetCustomFogInscatteringColor
struct UExponentialHeightFogComponent_SetCustomFogInscatteringColor_Params
{
	struct FLinearColor Value; // (Parm, IsPlainOldData)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ExponentialHeightFogComponent.SetCustomFogDensityCoefficient
struct UExponentialHeightFogComponent_SetCustomFogDensityCoefficient_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ForceFeedbackComponent.Stop
struct UForceFeedbackComponent_Stop_Params
{
};

// Function Engine.ForceFeedbackComponent.SetIntensityMultiplier
struct UForceFeedbackComponent_SetIntensityMultiplier_Params
{
	float NewIntensityMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ForceFeedbackComponent.SetForceFeedbackEffect
struct UForceFeedbackComponent_SetForceFeedbackEffect_Params
{
	class UForceFeedbackEffect* NewForceFeedbackEffect; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ForceFeedbackComponent.Play
struct UForceFeedbackComponent_Play_Params
{
	float StartTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ForceFeedbackComponent.BP_GetAttenuationSettingsToApply
struct UForceFeedbackComponent_BP_GetAttenuationSettingsToApply_Params
{
	struct FForceFeedbackAttenuationSettings OutAttenuationSettings; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ForceFeedbackComponent.AdjustAttenuation
struct UForceFeedbackComponent_AdjustAttenuation_Params
{
	struct FForceFeedbackAttenuationSettings InAttenuationSettings; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.GameUserSettings.ValidateSettings
struct UGameUserSettings_ValidateSettings_Params
{
};

// Function Engine.GameUserSettings.SupportsHDRDisplayOutput
struct UGameUserSettings_SupportsHDRDisplayOutput_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetVSyncEnabled
struct UGameUserSettings_SetVSyncEnabled_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetVisualEffectQuality
struct UGameUserSettings_SetVisualEffectQuality_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetViewDistanceQuality
struct UGameUserSettings_SetViewDistanceQuality_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetToDefaults
struct UGameUserSettings_SetToDefaults_Params
{
};

// Function Engine.GameUserSettings.SetTextureQuality
struct UGameUserSettings_SetTextureQuality_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetShadowQuality
struct UGameUserSettings_SetShadowQuality_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetScreenResolution
struct UGameUserSettings_SetScreenResolution_Params
{
	struct FIntPoint Resolution; // (Parm, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetResolutionScaleValueEx
struct UGameUserSettings_SetResolutionScaleValueEx_Params
{
	float NewScaleValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetResolutionScaleValue
struct UGameUserSettings_SetResolutionScaleValue_Params
{
	int NewScaleValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetResolutionScaleNormalized
struct UGameUserSettings_SetResolutionScaleNormalized_Params
{
	float NewScaleNormalized; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetPostProcessingQuality
struct UGameUserSettings_SetPostProcessingQuality_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetOverallScalabilityLevel
struct UGameUserSettings_SetOverallScalabilityLevel_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetFullscreenMode
struct UGameUserSettings_SetFullscreenMode_Params
{
	TEnumAsByte<enum EWindowMode> InFullscreenMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetFrameRateLimit
struct UGameUserSettings_SetFrameRateLimit_Params
{
	float NewLimit; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetFoliageQuality
struct UGameUserSettings_SetFoliageQuality_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetBenchmarkFallbackValues
struct UGameUserSettings_SetBenchmarkFallbackValues_Params
{
};

// Function Engine.GameUserSettings.SetAudioQualityLevel
struct UGameUserSettings_SetAudioQualityLevel_Params
{
	int QualityLevel; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SetAntiAliasingQuality
struct UGameUserSettings_SetAntiAliasingQuality_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.SaveSettings
struct UGameUserSettings_SaveSettings_Params
{
};

// Function Engine.GameUserSettings.RunHardwareBenchmark
struct UGameUserSettings_RunHardwareBenchmark_Params
{
	int WorkScale; // (Parm, ZeroConstructor, IsPlainOldData)
	float CPUMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
	float GPUMultiplier; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.RevertVideoMode
struct UGameUserSettings_RevertVideoMode_Params
{
};

// Function Engine.GameUserSettings.ResetToCurrentSettings
struct UGameUserSettings_ResetToCurrentSettings_Params
{
};

// Function Engine.GameUserSettings.LoadSettings
struct UGameUserSettings_LoadSettings_Params
{
	bool bForceReload; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.IsVSyncEnabled
struct UGameUserSettings_IsVSyncEnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.IsVSyncDirty
struct UGameUserSettings_IsVSyncDirty_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.IsScreenResolutionDirty
struct UGameUserSettings_IsScreenResolutionDirty_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.IsHDREnabled
struct UGameUserSettings_IsHDREnabled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.IsFullscreenModeDirty
struct UGameUserSettings_IsFullscreenModeDirty_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.IsDirty
struct UGameUserSettings_IsDirty_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetVisualEffectQuality
struct UGameUserSettings_GetVisualEffectQuality_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetViewDistanceQuality
struct UGameUserSettings_GetViewDistanceQuality_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetTextureQuality
struct UGameUserSettings_GetTextureQuality_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetShadowQuality
struct UGameUserSettings_GetShadowQuality_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetScreenResolution
struct UGameUserSettings_GetScreenResolution_Params
{
	struct FIntPoint ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetResolutionScaleInformationEx
struct UGameUserSettings_GetResolutionScaleInformationEx_Params
{
	float CurrentScaleNormalized; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float CurrentScaleValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float MinScaleValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float MaxScaleValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetResolutionScaleInformation
struct UGameUserSettings_GetResolutionScaleInformation_Params
{
	float CurrentScaleNormalized; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int CurrentScaleValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int MinScaleValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int MaxScaleValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetRecommendedResolutionScale
struct UGameUserSettings_GetRecommendedResolutionScale_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetPreferredFullscreenMode
struct UGameUserSettings_GetPreferredFullscreenMode_Params
{
	TEnumAsByte<enum EWindowMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetPostProcessingQuality
struct UGameUserSettings_GetPostProcessingQuality_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetOverallScalabilityLevel
struct UGameUserSettings_GetOverallScalabilityLevel_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetLastConfirmedScreenResolution
struct UGameUserSettings_GetLastConfirmedScreenResolution_Params
{
	struct FIntPoint ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetLastConfirmedFullscreenMode
struct UGameUserSettings_GetLastConfirmedFullscreenMode_Params
{
	TEnumAsByte<enum EWindowMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetGameUserSettings
struct UGameUserSettings_GetGameUserSettings_Params
{
	class UGameUserSettings* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetFullscreenMode
struct UGameUserSettings_GetFullscreenMode_Params
{
	TEnumAsByte<enum EWindowMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetFrameRateLimit
struct UGameUserSettings_GetFrameRateLimit_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetFoliageQuality
struct UGameUserSettings_GetFoliageQuality_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetDesktopResolution
struct UGameUserSettings_GetDesktopResolution_Params
{
	struct FIntPoint ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetDefaultWindowPosition
struct UGameUserSettings_GetDefaultWindowPosition_Params
{
	struct FIntPoint ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetDefaultWindowMode
struct UGameUserSettings_GetDefaultWindowMode_Params
{
	TEnumAsByte<enum EWindowMode> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetDefaultResolutionScale
struct UGameUserSettings_GetDefaultResolutionScale_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetDefaultResolution
struct UGameUserSettings_GetDefaultResolution_Params
{
	struct FIntPoint ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetCurrentHDRDisplayNits
struct UGameUserSettings_GetCurrentHDRDisplayNits_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetAudioQualityLevel
struct UGameUserSettings_GetAudioQualityLevel_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.GetAntiAliasingQuality
struct UGameUserSettings_GetAntiAliasingQuality_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.GameUserSettings.EnableHDRDisplayOutput
struct UGameUserSettings_EnableHDRDisplayOutput_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
	int DisplayNits; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.ConfirmVideoMode
struct UGameUserSettings_ConfirmVideoMode_Params
{
};

// Function Engine.GameUserSettings.ApplySettings
struct UGameUserSettings_ApplySettings_Params
{
	bool bCheckForCommandLineOverrides; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.ApplyResolutionSettings
struct UGameUserSettings_ApplyResolutionSettings_Params
{
	bool bCheckForCommandLineOverrides; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.GameUserSettings.ApplyNonResolutionSettings
struct UGameUserSettings_ApplyNonResolutionSettings_Params
{
};

// Function Engine.GameUserSettings.ApplyHardwareBenchmarkResults
struct UGameUserSettings_ApplyHardwareBenchmarkResults_Params
{
};

// Function Engine.SpotLight.SetOuterConeAngle
struct ASpotLight_SetOuterConeAngle_Params
{
	float NewOuterConeAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SpotLight.SetInnerConeAngle
struct ASpotLight_SetInnerConeAngle_Params
{
	float NewInnerConeAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetVolumeResolution
struct UHeterogeneousVolumeComponent_SetVolumeResolution_Params
{
	struct FIntVector NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetStreamingMipBias
struct UHeterogeneousVolumeComponent_SetStreamingMipBias_Params
{
	int NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetStartFrame
struct UHeterogeneousVolumeComponent_SetStartFrame_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetPlaying
struct UHeterogeneousVolumeComponent_SetPlaying_Params
{
	bool NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetLooping
struct UHeterogeneousVolumeComponent_SetLooping_Params
{
	bool NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetFrameRate
struct UHeterogeneousVolumeComponent_SetFrameRate_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetFrame
struct UHeterogeneousVolumeComponent_SetFrame_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.SetEndFrame
struct UHeterogeneousVolumeComponent_SetEndFrame_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.HeterogeneousVolumeComponent.Play
struct UHeterogeneousVolumeComponent_Play_Params
{
};

// Function Engine.ColorInstancedStaticMeshComponent.UpdateInstanceTransformWithColor
struct UColorInstancedStaticMeshComponent_UpdateInstanceTransformWithColor_Params
{
	int InstanceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform NewInstanceTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FColor InColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bWorldSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMarkRenderStateDirty; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTeleport; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorInstancedStaticMeshComponent.ShowInstancesWithColor
struct UColorInstancedStaticMeshComponent_ShowInstancesWithColor_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FColor> InstanceColors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorInstancedStaticMeshComponent.ShowInstances
struct UColorInstancedStaticMeshComponent_ShowInstances_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorInstancedStaticMeshComponent.ReplaceAllInstancesWithColor
struct UColorInstancedStaticMeshComponent_ReplaceAllInstancesWithColor_Params
{
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FColor> InstanceColors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.ColorInstancedStaticMeshComponent.ReplaceAllInstances
struct UColorInstancedStaticMeshComponent_ReplaceAllInstances_Params
{
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.ColorInstancedStaticMeshComponent.RemoveInstances
struct UColorInstancedStaticMeshComponent_RemoveInstances_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorInstancedStaticMeshComponent.RemoveInstance
struct UColorInstancedStaticMeshComponent_RemoveInstance_Params
{
	int InstanceIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorInstancedStaticMeshComponent.HideInstance
struct UColorInstancedStaticMeshComponent_HideInstance_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorInstancedStaticMeshComponent.ClearInstances
struct UColorInstancedStaticMeshComponent_ClearInstances_Params
{
};

// Function Engine.ColorInstancedStaticMeshComponent.AddInstanceWorldSpace
struct UColorInstancedStaticMeshComponent_AddInstanceWorldSpace_Params
{
	struct FTransform WorldTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorInstancedStaticMeshComponent.AddInstancesWithColor
struct UColorInstancedStaticMeshComponent_AddInstancesWithColor_Params
{
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FColor> InstanceColors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMarkRenderStateDirty; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.ColorInstancedStaticMeshComponent.AddInstances
struct UColorInstancedStaticMeshComponent_AddInstances_Params
{
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMarkRenderStateDirty; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.ColorInstancedStaticMeshComponent.AddInstance
struct UColorInstancedStaticMeshComponent_AddInstance_Params
{
	struct FTransform InstanceTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorHierarchicalInstancedStaticMeshComponent.ShowInstancesWithColor
struct UColorHierarchicalInstancedStaticMeshComponent_ShowInstancesWithColor_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FColor> InstanceColors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorHierarchicalInstancedStaticMeshComponent.ShowInstances
struct UColorHierarchicalInstancedStaticMeshComponent_ShowInstances_Params
{
	TArray<int> InstanceIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorHierarchicalInstancedStaticMeshComponent.RemoveInstances
struct UColorHierarchicalInstancedStaticMeshComponent_RemoveInstances_Params
{
	TArray<int> InstancesToRemove; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ColorHierarchicalInstancedStaticMeshComponent.AddInstancesWithColor
struct UColorHierarchicalInstancedStaticMeshComponent_AddInstancesWithColor_Params
{
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FColor> InstanceColors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMarkRenderStateDirty; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.ImportanceSamplingLibrary.RandomSobolFloat
struct UImportanceSamplingLibrary_RandomSobolFloat_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int Dimension; // (Parm, ZeroConstructor, IsPlainOldData)
	float Seed; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ImportanceSamplingLibrary.RandomSobolCell3D
struct UImportanceSamplingLibrary_RandomSobolCell3D_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumCells; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector CELL; // (Parm, IsPlainOldData)
	struct FVector Seed; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.ImportanceSamplingLibrary.RandomSobolCell2D
struct UImportanceSamplingLibrary_RandomSobolCell2D_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumCells; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D CELL; // (Parm, IsPlainOldData)
	struct FVector2D Seed; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.ImportanceSamplingLibrary.NextSobolFloat
struct UImportanceSamplingLibrary_NextSobolFloat_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int Dimension; // (Parm, ZeroConstructor, IsPlainOldData)
	float PreviousValue; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ImportanceSamplingLibrary.NextSobolCell3D
struct UImportanceSamplingLibrary_NextSobolCell3D_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumCells; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector PreviousValue; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.ImportanceSamplingLibrary.NextSobolCell2D
struct UImportanceSamplingLibrary_NextSobolCell2D_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumCells; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D PreviousValue; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.ImportanceSamplingLibrary.MakeImportanceTexture
struct UImportanceSamplingLibrary_MakeImportanceTexture_Params
{
	class UTexture2D* Texture; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EImportanceWeight> WeightingFunc; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FImportanceTexture ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.ImportanceSamplingLibrary.ImportanceSample
struct UImportanceSamplingLibrary_ImportanceSample_Params
{
	struct FImportanceTexture Texture; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector2D Rand; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int Samples; // (Parm, ZeroConstructor, IsPlainOldData)
	float Intensity; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D SamplePosition; // (Parm, OutParm, IsPlainOldData)
	struct FLinearColor SampleColor; // (Parm, OutParm, IsPlainOldData)
	float SampleIntensity; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float SampleSize; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ImportanceSamplingLibrary.BreakImportanceTexture
struct UImportanceSamplingLibrary_BreakImportanceTexture_Params
{
	struct FImportanceTexture ImportanceTexture; // (ConstParm, Parm, OutParm, ReferenceParm)
	class UTexture2D* Texture; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EImportanceWeight> WeightingFunc; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InputComponent.WasControllerKeyJustReleased
struct UInputComponent_WasControllerKeyJustReleased_Params
{
	struct FKey Key; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InputComponent.WasControllerKeyJustPressed
struct UInputComponent_WasControllerKeyJustPressed_Params
{
	struct FKey Key; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InputComponent.IsControllerKeyDown
struct UInputComponent_IsControllerKeyDown_Params
{
	struct FKey Key; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InputComponent.GetTouchState
struct UInputComponent_GetTouchState_Params
{
	int FingerIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	float LocationX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float LocationY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool bIsCurrentlyPressed; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InputComponent.GetControllerVectorKeyState
struct UInputComponent_GetControllerVectorKeyState_Params
{
	struct FKey Key; // (Parm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.InputComponent.GetControllerMouseDelta
struct UInputComponent_GetControllerMouseDelta_Params
{
	float DeltaX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float DeltaY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InputComponent.GetControllerKeyTimeDown
struct UInputComponent_GetControllerKeyTimeDown_Params
{
	struct FKey Key; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InputComponent.GetControllerAnalogStickState
struct UInputComponent_GetControllerAnalogStickState_Params
{
	TEnumAsByte<enum EControllerAnalogStick> WhichStick; // (Parm, ZeroConstructor, IsPlainOldData)
	float StickX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float StickY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InputComponent.GetControllerAnalogKeyState
struct UInputComponent_GetControllerAnalogKeyState_Params
{
	struct FKey Key; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InputSettings.SaveKeyMappings
struct UInputSettings_SaveKeyMappings_Params
{
};

// Function Engine.InputSettings.RemoveAxisMapping
struct UInputSettings_RemoveAxisMapping_Params
{
	struct FInputAxisKeyMapping KeyMapping; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bForceRebuildKeymaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InputSettings.RemoveActionMapping
struct UInputSettings_RemoveActionMapping_Params
{
	struct FInputActionKeyMapping KeyMapping; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bForceRebuildKeymaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InputSettings.GetInputSettings
struct UInputSettings_GetInputSettings_Params
{
	class UInputSettings* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.InputSettings.GetAxisNames
struct UInputSettings_GetAxisNames_Params
{
	TArray<struct FName> AxisNames; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.InputSettings.GetAxisMappingByName
struct UInputSettings_GetAxisMappingByName_Params
{
	struct FName InAxisName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FInputAxisKeyMapping> OutMappings; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.InputSettings.GetActionNames
struct UInputSettings_GetActionNames_Params
{
	TArray<struct FName> ActionNames; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.InputSettings.GetActionMappingByName
struct UInputSettings_GetActionMappingByName_Params
{
	struct FName InActionName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FInputActionKeyMapping> OutMappings; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.InputSettings.ForceRebuildKeymaps
struct UInputSettings_ForceRebuildKeymaps_Params
{
};

// Function Engine.InputSettings.AddAxisMapping
struct UInputSettings_AddAxisMapping_Params
{
	struct FInputAxisKeyMapping KeyMapping; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bForceRebuildKeymaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.InputSettings.AddActionMapping
struct UInputSettings_AddActionMapping_Params
{
	struct FInputActionKeyMapping KeyMapping; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bForceRebuildKeymaps; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.SetArrayPropertyByName
struct UKismetArrayLibrary_SetArrayPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> Value; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.KismetArrayLibrary.FilterArray
struct UKismetArrayLibrary_FilterArray_Params
{
	TArray<class AActor*> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* FilterClass; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> FilteredArray; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.KismetArrayLibrary.Array_Swap
struct UKismetArrayLibrary_Array_Swap_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int FirstIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int SecondIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Shuffle
struct UKismetArrayLibrary_Array_Shuffle_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.KismetArrayLibrary.Array_Set
struct UKismetArrayLibrary_Array_Set_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int Item; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool bSizeToFit; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Resize
struct UKismetArrayLibrary_Array_Resize_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Size; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_RemoveItem
struct UKismetArrayLibrary_Array_RemoveItem_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Item; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Remove
struct UKismetArrayLibrary_Array_Remove_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexToRemove; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Length
struct UKismetArrayLibrary_Array_Length_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_LastIndex
struct UKismetArrayLibrary_Array_LastIndex_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_IsValidIndex
struct UKismetArrayLibrary_Array_IsValidIndex_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexToTest; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Insert
struct UKismetArrayLibrary_Array_Insert_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int NewItem; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Get
struct UKismetArrayLibrary_Array_Get_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int Item; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Find
struct UKismetArrayLibrary_Array_Find_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int ItemToFind; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Contains
struct UKismetArrayLibrary_Array_Contains_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int ItemToFind; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Clear
struct UKismetArrayLibrary_Array_Clear_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.KismetArrayLibrary.Array_Append
struct UKismetArrayLibrary_Array_Append_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<int> SourceArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.KismetArrayLibrary.Array_AddUnique
struct UKismetArrayLibrary_Array_AddUnique_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int NewItem; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetArrayLibrary.Array_Add
struct UKismetArrayLibrary_Array_Add_Params
{
	TArray<int> TargetArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int NewItem; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetGuidLibrary.Parse_StringToGuid
struct UKismetGuidLibrary_Parse_StringToGuid_Params
{
	struct FString GuidString; // (Parm, ZeroConstructor)
	struct FGuid OutGuid; // (Parm, OutParm, IsPlainOldData)
	bool Success; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetGuidLibrary.NotEqual_GuidGuid
struct UKismetGuidLibrary_NotEqual_GuidGuid_Params
{
	struct FGuid A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FGuid B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetGuidLibrary.NewGuid
struct UKismetGuidLibrary_NewGuid_Params
{
	struct FGuid ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetGuidLibrary.IsValid_Guid
struct UKismetGuidLibrary_IsValid_Guid_Params
{
	struct FGuid InGuid; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetGuidLibrary.Invalidate_Guid
struct UKismetGuidLibrary_Invalidate_Guid_Params
{
	struct FGuid InGuid; // (Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetGuidLibrary.EqualEqual_GuidGuid
struct UKismetGuidLibrary_EqualEqual_GuidGuid_Params
{
	struct FGuid A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FGuid B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetGuidLibrary.Conv_GuidToString
struct UKismetGuidLibrary_Conv_GuidToString_Params
{
	struct FGuid InGuid; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetInputLibrary.PointerEvent_TouchForce
struct UKismetInputLibrary_PointerEvent_TouchForce_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_IsTouchEvent
struct UKismetInputLibrary_PointerEvent_IsTouchEvent_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_IsMouseButtonDown
struct UKismetInputLibrary_PointerEvent_IsMouseButtonDown_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FKey MouseButton; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetWheelDelta
struct UKismetInputLibrary_PointerEvent_GetWheelDelta_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetUserIndex
struct UKismetInputLibrary_PointerEvent_GetUserIndex_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetTouchpadIndex
struct UKismetInputLibrary_PointerEvent_GetTouchpadIndex_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetScreenSpacePosition
struct UKismetInputLibrary_PointerEvent_GetScreenSpacePosition_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetPointerIndex
struct UKismetInputLibrary_PointerEvent_GetPointerIndex_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetLastScreenSpacePosition
struct UKismetInputLibrary_PointerEvent_GetLastScreenSpacePosition_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetGestureType
struct UKismetInputLibrary_PointerEvent_GetGestureType_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	ESlateGesture ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetGestureDelta
struct UKismetInputLibrary_PointerEvent_GetGestureDelta_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetEffectingButton
struct UKismetInputLibrary_PointerEvent_GetEffectingButton_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FKey ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetInputLibrary.PointerEvent_GetCursorDelta
struct UKismetInputLibrary_PointerEvent_GetCursorDelta_Params
{
	struct FPointerEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.Key_IsVectorAxis
struct UKismetInputLibrary_Key_IsVectorAxis_Params
{
	struct FKey Key; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.Key_IsMouseButton
struct UKismetInputLibrary_Key_IsMouseButton_Params
{
	struct FKey Key; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.Key_IsModifierKey
struct UKismetInputLibrary_Key_IsModifierKey_Params
{
	struct FKey Key; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.Key_IsKeyboardKey
struct UKismetInputLibrary_Key_IsKeyboardKey_Params
{
	struct FKey Key; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.Key_IsGamepadKey
struct UKismetInputLibrary_Key_IsGamepadKey_Params
{
	struct FKey Key; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.Key_IsFloatAxis
struct UKismetInputLibrary_Key_IsFloatAxis_Params
{
	struct FKey Key; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.Key_GetDisplayName
struct UKismetInputLibrary_Key_GetDisplayName_Params
{
	struct FKey Key; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetInputLibrary.InputEvent_IsShiftDown
struct UKismetInputLibrary_InputEvent_IsShiftDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsRightShiftDown
struct UKismetInputLibrary_InputEvent_IsRightShiftDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsRightControlDown
struct UKismetInputLibrary_InputEvent_IsRightControlDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsRightCommandDown
struct UKismetInputLibrary_InputEvent_IsRightCommandDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsRightAltDown
struct UKismetInputLibrary_InputEvent_IsRightAltDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsRepeat
struct UKismetInputLibrary_InputEvent_IsRepeat_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsLeftShiftDown
struct UKismetInputLibrary_InputEvent_IsLeftShiftDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsLeftControlDown
struct UKismetInputLibrary_InputEvent_IsLeftControlDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsLeftCommandDown
struct UKismetInputLibrary_InputEvent_IsLeftCommandDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsLeftAltDown
struct UKismetInputLibrary_InputEvent_IsLeftAltDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsControlDown
struct UKismetInputLibrary_InputEvent_IsControlDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsCommandDown
struct UKismetInputLibrary_InputEvent_IsCommandDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.InputEvent_IsAltDown
struct UKismetInputLibrary_InputEvent_IsAltDown_Params
{
	struct FInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.GetUserIndex
struct UKismetInputLibrary_GetUserIndex_Params
{
	struct FKeyEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.GetKey
struct UKismetInputLibrary_GetKey_Params
{
	struct FKeyEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FKey ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetInputLibrary.GetAnalogValue
struct UKismetInputLibrary_GetAnalogValue_Params
{
	struct FAnalogInputEvent Input; // (ConstParm, Parm, OutParm, ReferenceParm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.EqualEqual_KeyKey
struct UKismetInputLibrary_EqualEqual_KeyKey_Params
{
	struct FKey A; // (Parm)
	struct FKey B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.EqualEqual_InputChordInputChord
struct UKismetInputLibrary_EqualEqual_InputChordInputChord_Params
{
	struct FInputChord A; // (Parm)
	struct FInputChord B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInputLibrary.CalibrateTilt
struct UKismetInputLibrary_CalibrateTilt_Params
{
};

// Function Engine.KismetInternationalizationLibrary.SetCurrentLocale
struct UKismetInternationalizationLibrary_SetCurrentLocale_Params
{
	struct FString Culture; // (Parm, ZeroConstructor)
	bool SaveToConfig; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInternationalizationLibrary.SetCurrentLanguageAndLocale
struct UKismetInternationalizationLibrary_SetCurrentLanguageAndLocale_Params
{
	struct FString Culture; // (Parm, ZeroConstructor)
	bool SaveToConfig; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInternationalizationLibrary.SetCurrentLanguage
struct UKismetInternationalizationLibrary_SetCurrentLanguage_Params
{
	struct FString Culture; // (Parm, ZeroConstructor)
	bool SaveToConfig; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInternationalizationLibrary.SetCurrentCulture
struct UKismetInternationalizationLibrary_SetCurrentCulture_Params
{
	struct FString Culture; // (Parm, ZeroConstructor)
	bool SaveToConfig; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInternationalizationLibrary.SetCurrentAssetGroupCulture
struct UKismetInternationalizationLibrary_SetCurrentAssetGroupCulture_Params
{
	struct FName AssetGroup; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString Culture; // (Parm, ZeroConstructor)
	bool SaveToConfig; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetInternationalizationLibrary.GetCurrentLocale
struct UKismetInternationalizationLibrary_GetCurrentLocale_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetInternationalizationLibrary.GetCurrentLanguage
struct UKismetInternationalizationLibrary_GetCurrentLanguage_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetInternationalizationLibrary.GetCurrentCulture
struct UKismetInternationalizationLibrary_GetCurrentCulture_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetInternationalizationLibrary.GetCurrentAssetGroupCulture
struct UKismetInternationalizationLibrary_GetCurrentAssetGroupCulture_Params
{
	struct FName AssetGroup; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetInternationalizationLibrary.ClearCurrentAssetGroupCulture
struct UKismetInternationalizationLibrary_ClearCurrentAssetGroupCulture_Params
{
	struct FName AssetGroup; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool SaveToConfig; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMaterialLibrary.SetVectorParameterValue
struct UKismetMaterialLibrary_SetVectorParameterValue_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialParameterCollection* Collection; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ParameterValue; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetMaterialLibrary.SetScalarParameterValue
struct UKismetMaterialLibrary_SetScalarParameterValue_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialParameterCollection* Collection; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ParameterValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMaterialLibrary.GetVectorParameterValue
struct UKismetMaterialLibrary_GetVectorParameterValue_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialParameterCollection* Collection; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMaterialLibrary.GetScalarParameterValue
struct UKismetMaterialLibrary_GetScalarParameterValue_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialParameterCollection* Collection; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMaterialLibrary.CreateDynamicMaterialInstance
struct UKismetMaterialLibrary_CreateDynamicMaterialInstance_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Parent; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Xor_IntInt
struct UKismetMathLibrary_Xor_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VSizeSquared
struct UKismetMathLibrary_VSizeSquared_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VSize2DSquared
struct UKismetMathLibrary_VSize2DSquared_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VSize2D
struct UKismetMathLibrary_VSize2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VSize
struct UKismetMathLibrary_VSize_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VLerp
struct UKismetMathLibrary_VLerp_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VInterpTo_Constant
struct UKismetMathLibrary_VInterpTo_Constant_Params
{
	struct FVector Current; // (Parm, IsPlainOldData)
	struct FVector Target; // (Parm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VInterpTo
struct UKismetMathLibrary_VInterpTo_Params
{
	struct FVector Current; // (Parm, IsPlainOldData)
	struct FVector Target; // (Parm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VectorSpringInterp
struct UKismetMathLibrary_VectorSpringInterp_Params
{
	struct FVector Current; // (Parm, IsPlainOldData)
	struct FVector Target; // (Parm, IsPlainOldData)
	struct FVectorSpringState SpringState; // (Parm, OutParm, ReferenceParm)
	float Stiffness; // (Parm, ZeroConstructor, IsPlainOldData)
	float CriticalDampingFactor; // (Parm, ZeroConstructor, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float Mass; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Vector2DInterpTo_Constant
struct UKismetMathLibrary_Vector2DInterpTo_Constant_Params
{
	struct FVector2D Current; // (Parm, IsPlainOldData)
	struct FVector2D Target; // (Parm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Vector2DInterpTo
struct UKismetMathLibrary_Vector2DInterpTo_Params
{
	struct FVector2D Current; // (Parm, IsPlainOldData)
	struct FVector2D Target; // (Parm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.VEase
struct UKismetMathLibrary_VEase_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EEasingFunc> EasingFunc; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendExp; // (Parm, ZeroConstructor, IsPlainOldData)
	int Steps; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.UtcNow
struct UKismetMathLibrary_UtcNow_Params
{
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.TransformRotation
struct UKismetMathLibrary_TransformRotation_Params
{
	struct FTransform T; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.TransformLocation
struct UKismetMathLibrary_TransformLocation_Params
{
	struct FTransform T; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.TransformDirection
struct UKismetMathLibrary_TransformDirection_Params
{
	struct FTransform T; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Direction; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Today
struct UKismetMathLibrary_Today_Params
{
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.TLerp
struct UKismetMathLibrary_TLerp_Params
{
	struct FTransform A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ELerpInterpolationMode> InterpMode; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.TInterpTo
struct UKismetMathLibrary_TInterpTo_Params
{
	struct FTransform Current; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform Target; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.TimespanZeroValue
struct UKismetMathLibrary_TimespanZeroValue_Params
{
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.TimespanRatio
struct UKismetMathLibrary_TimespanRatio_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.TimespanMinValue
struct UKismetMathLibrary_TimespanMinValue_Params
{
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.TimespanMaxValue
struct UKismetMathLibrary_TimespanMaxValue_Params
{
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.TimespanFromString
struct UKismetMathLibrary_TimespanFromString_Params
{
	struct FString TimespanString; // (Parm, ZeroConstructor)
	struct FTimespan Result; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.TEase
struct UKismetMathLibrary_TEase_Params
{
	struct FTransform A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EEasingFunc> EasingFunc; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendExp; // (Parm, ZeroConstructor, IsPlainOldData)
	int Steps; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Tan
struct UKismetMathLibrary_Tan_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_VectorVector
struct UKismetMathLibrary_Subtract_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_VectorInt
struct UKismetMathLibrary_Subtract_VectorInt_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_VectorFloat
struct UKismetMathLibrary_Subtract_VectorFloat_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_Vector2DVector2D
struct UKismetMathLibrary_Subtract_Vector2DVector2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_Vector2DFloat
struct UKismetMathLibrary_Subtract_Vector2DFloat_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_TimespanTimespan
struct UKismetMathLibrary_Subtract_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Subtract_IntInt
struct UKismetMathLibrary_Subtract_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_FloatFloat
struct UKismetMathLibrary_Subtract_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Subtract_DateTimeTimespan
struct UKismetMathLibrary_Subtract_DateTimeTimespan_Params
{
	struct FDateTime A; // (Parm)
	struct FTimespan B; // (Parm)
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Subtract_DateTimeDateTime
struct UKismetMathLibrary_Subtract_DateTimeDateTime_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime B; // (Parm)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Subtract_ByteByte
struct UKismetMathLibrary_Subtract_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Square
struct UKismetMathLibrary_Square_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Sqrt
struct UKismetMathLibrary_Sqrt_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Sin
struct UKismetMathLibrary_Sin_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SignOfInteger
struct UKismetMathLibrary_SignOfInteger_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SignOfFloat
struct UKismetMathLibrary_SignOfFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SetRandomStreamSeed
struct UKismetMathLibrary_SetRandomStreamSeed_Params
{
	struct FRandomStream Stream; // (Parm, OutParm, ReferenceParm)
	int NewSeed; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectVector
struct UKismetMathLibrary_SelectVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	bool bPickA; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectTransform
struct UKismetMathLibrary_SelectTransform_Params
{
	struct FTransform A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bPickA; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectString
struct UKismetMathLibrary_SelectString_Params
{
	struct FString A; // (Parm, ZeroConstructor)
	struct FString B; // (Parm, ZeroConstructor)
	bool bPickA; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetMathLibrary.SelectRotator
struct UKismetMathLibrary_SelectRotator_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	bool bPickA; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectObject
struct UKismetMathLibrary_SelectObject_Params
{
	class UObject* A; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSelectA; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectInt
struct UKismetMathLibrary_SelectInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPickA; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectFloat
struct UKismetMathLibrary_SelectFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPickA; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectColor
struct UKismetMathLibrary_SelectColor_Params
{
	struct FLinearColor A; // (Parm, IsPlainOldData)
	struct FLinearColor B; // (Parm, IsPlainOldData)
	bool bPickA; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SelectClass
struct UKismetMathLibrary_SelectClass_Params
{
	class UClass* A; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSelectA; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.SeedRandomStream
struct UKismetMathLibrary_SeedRandomStream_Params
{
	struct FRandomStream Stream; // (Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetMathLibrary.Round
struct UKismetMathLibrary_Round_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RotatorFromAxisAndAngle
struct UKismetMathLibrary_RotatorFromAxisAndAngle_Params
{
	struct FVector Axis; // (Parm, IsPlainOldData)
	float Angle; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RotateAngleAxis
struct UKismetMathLibrary_RotateAngleAxis_Params
{
	struct FVector InVect; // (Parm, IsPlainOldData)
	float AngleDeg; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Axis; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RLerp
struct UKismetMathLibrary_RLerp_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bShortestPath; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RInterpTo_Constant
struct UKismetMathLibrary_RInterpTo_Constant_Params
{
	struct FRotator Current; // (Parm, IsPlainOldData)
	struct FRotator Target; // (Parm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RInterpTo
struct UKismetMathLibrary_RInterpTo_Params
{
	struct FRotator Current; // (Parm, IsPlainOldData)
	struct FRotator Target; // (Parm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RGBToHSV_Vector
struct UKismetMathLibrary_RGBToHSV_Vector_Params
{
	struct FLinearColor RGB; // (ConstParm, Parm, IsPlainOldData)
	struct FLinearColor HSV; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RGBToHSV
struct UKismetMathLibrary_RGBToHSV_Params
{
	struct FLinearColor InColor; // (ConstParm, Parm, IsPlainOldData)
	float H; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float S; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float V; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float A; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ResetVectorSpringState
struct UKismetMathLibrary_ResetVectorSpringState_Params
{
	struct FVectorSpringState SpringState; // (Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetMathLibrary.ResetRandomStream
struct UKismetMathLibrary_ResetRandomStream_Params
{
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetMathLibrary.ResetFloatSpringState
struct UKismetMathLibrary_ResetFloatSpringState_Params
{
	struct FFloatSpringState SpringState; // (Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetMathLibrary.REase
struct UKismetMathLibrary_REase_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bShortestPath; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EEasingFunc> EasingFunc; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendExp; // (Parm, ZeroConstructor, IsPlainOldData)
	int Steps; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInEllipticalConeInRadiansFromStream
struct UKismetMathLibrary_RandomUnitVectorInEllipticalConeInRadiansFromStream_Params
{
	struct FVector ConeDir; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float MaxYawInRadians; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxPitchInRadians; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInEllipticalConeInRadians
struct UKismetMathLibrary_RandomUnitVectorInEllipticalConeInRadians_Params
{
	struct FVector ConeDir; // (Parm, IsPlainOldData)
	float MaxYawInRadians; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxPitchInRadians; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInEllipticalConeInDegreesFromStream
struct UKismetMathLibrary_RandomUnitVectorInEllipticalConeInDegreesFromStream_Params
{
	struct FVector ConeDir; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float MaxYawInDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxPitchInDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInEllipticalConeInDegrees
struct UKismetMathLibrary_RandomUnitVectorInEllipticalConeInDegrees_Params
{
	struct FVector ConeDir; // (Parm, IsPlainOldData)
	float MaxYawInDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxPitchInDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInConeInRadiansFromStream
struct UKismetMathLibrary_RandomUnitVectorInConeInRadiansFromStream_Params
{
	struct FVector ConeDir; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float ConeHalfAngleInRadians; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInConeInRadians
struct UKismetMathLibrary_RandomUnitVectorInConeInRadians_Params
{
	struct FVector ConeDir; // (Parm, IsPlainOldData)
	float ConeHalfAngleInRadians; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInConeInDegreesFromStream
struct UKismetMathLibrary_RandomUnitVectorInConeInDegreesFromStream_Params
{
	struct FVector ConeDir; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float ConeHalfAngleInDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorInConeInDegrees
struct UKismetMathLibrary_RandomUnitVectorInConeInDegrees_Params
{
	struct FVector ConeDir; // (Parm, IsPlainOldData)
	float ConeHalfAngleInDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVectorFromStream
struct UKismetMathLibrary_RandomUnitVectorFromStream_Params
{
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomUnitVector
struct UKismetMathLibrary_RandomUnitVector_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomRotatorFromStream
struct UKismetMathLibrary_RandomRotatorFromStream_Params
{
	bool bRoll; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomRotator
struct UKismetMathLibrary_RandomRotator_Params
{
	bool bRoll; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomPointInBoundingBox
struct UKismetMathLibrary_RandomPointInBoundingBox_Params
{
	struct FVector Origin; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector BoxExtent; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomIntegerInRangeFromStream
struct UKismetMathLibrary_RandomIntegerInRangeFromStream_Params
{
	int Min; // (Parm, ZeroConstructor, IsPlainOldData)
	int Max; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomIntegerInRange
struct UKismetMathLibrary_RandomIntegerInRange_Params
{
	int Min; // (Parm, ZeroConstructor, IsPlainOldData)
	int Max; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomIntegerFromStream
struct UKismetMathLibrary_RandomIntegerFromStream_Params
{
	int Max; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomInteger
struct UKismetMathLibrary_RandomInteger_Params
{
	int Max; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomFloatInRangeFromStream
struct UKismetMathLibrary_RandomFloatInRangeFromStream_Params
{
	float Min; // (Parm, ZeroConstructor, IsPlainOldData)
	float Max; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomFloatInRange
struct UKismetMathLibrary_RandomFloatInRange_Params
{
	float Min; // (Parm, ZeroConstructor, IsPlainOldData)
	float Max; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomFloatFromStream
struct UKismetMathLibrary_RandomFloatFromStream_Params
{
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomFloat
struct UKismetMathLibrary_RandomFloat_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomBoolWithWeightFromStream
struct UKismetMathLibrary_RandomBoolWithWeightFromStream_Params
{
	float Weight; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream RandomStream; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomBoolWithWeight
struct UKismetMathLibrary_RandomBoolWithWeight_Params
{
	float Weight; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomBoolFromStream
struct UKismetMathLibrary_RandomBoolFromStream_Params
{
	struct FRandomStream Stream; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RandomBool
struct UKismetMathLibrary_RandomBool_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.RadiansToDegrees
struct UKismetMathLibrary_RadiansToDegrees_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ProjectVectorOnToVector
struct UKismetMathLibrary_ProjectVectorOnToVector_Params
{
	struct FVector V; // (Parm, IsPlainOldData)
	struct FVector Target; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ProjectVectorOnToPlane
struct UKismetMathLibrary_ProjectVectorOnToPlane_Params
{
	struct FVector V; // (Parm, IsPlainOldData)
	struct FVector PlaneNormal; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ProjectPointOnToPlane
struct UKismetMathLibrary_ProjectPointOnToPlane_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FVector PlaneBase; // (Parm, IsPlainOldData)
	struct FVector PlaneNormal; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.PointsAreCoplanar
struct UKismetMathLibrary_PointsAreCoplanar_Params
{
	TArray<struct FVector> Points; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	float Tolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Percent_IntInt
struct UKismetMathLibrary_Percent_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Percent_FloatFloat
struct UKismetMathLibrary_Percent_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Percent_ByteByte
struct UKismetMathLibrary_Percent_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Or_IntInt
struct UKismetMathLibrary_Or_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Now
struct UKismetMathLibrary_Now_Params
{
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.NotEqual_VectorVector
struct UKismetMathLibrary_NotEqual_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	float ErrorTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_Vector2DVector2D
struct UKismetMathLibrary_NotEqual_Vector2DVector2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	float ErrorTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_TimespanTimespan
struct UKismetMathLibrary_NotEqual_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_RotatorRotator
struct UKismetMathLibrary_NotEqual_RotatorRotator_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	float ErrorTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_ObjectObject
struct UKismetMathLibrary_NotEqual_ObjectObject_Params
{
	class UObject* A; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_NameName
struct UKismetMathLibrary_NotEqual_NameName_Params
{
	struct FName A; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_IntInt
struct UKismetMathLibrary_NotEqual_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_FloatFloat
struct UKismetMathLibrary_NotEqual_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_DateTimeDateTime
struct UKismetMathLibrary_NotEqual_DateTimeDateTime_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_ClassClass
struct UKismetMathLibrary_NotEqual_ClassClass_Params
{
	class UClass* A; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_ByteByte
struct UKismetMathLibrary_NotEqual_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NotEqual_BoolBool
struct UKismetMathLibrary_NotEqual_BoolBool_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Not_PreBool
struct UKismetMathLibrary_Not_PreBool_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Not_Int
struct UKismetMathLibrary_Not_Int_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NormalizeToRange
struct UKismetMathLibrary_NormalizeToRange_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float RangeMin; // (Parm, ZeroConstructor, IsPlainOldData)
	float RangeMax; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NormalizedDeltaRotator
struct UKismetMathLibrary_NormalizedDeltaRotator_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NormalizeAxis
struct UKismetMathLibrary_NormalizeAxis_Params
{
	float Angle; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Normal2D
struct UKismetMathLibrary_Normal2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Normal
struct UKismetMathLibrary_Normal_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NegateVector
struct UKismetMathLibrary_NegateVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NegateRotator
struct UKismetMathLibrary_NegateRotator_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NearlyEqual_TransformTransform
struct UKismetMathLibrary_NearlyEqual_TransformTransform_Params
{
	struct FTransform A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float LocationTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	float RotationTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	float Scale3DTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.NearlyEqual_FloatFloat
struct UKismetMathLibrary_NearlyEqual_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ErrorTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MultiplyMultiply_FloatFloat
struct UKismetMathLibrary_MultiplyMultiply_FloatFloat_Params
{
	float Base; // (Parm, ZeroConstructor, IsPlainOldData)
	float Exp; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MultiplyByPi
struct UKismetMathLibrary_MultiplyByPi_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_VectorVector
struct UKismetMathLibrary_Multiply_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_VectorInt
struct UKismetMathLibrary_Multiply_VectorInt_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_VectorFloat
struct UKismetMathLibrary_Multiply_VectorFloat_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_Vector2DVector2D
struct UKismetMathLibrary_Multiply_Vector2DVector2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_Vector2DFloat
struct UKismetMathLibrary_Multiply_Vector2DFloat_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_TimespanFloat
struct UKismetMathLibrary_Multiply_TimespanFloat_Params
{
	struct FTimespan A; // (Parm)
	float Scalar; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Multiply_RotatorInt
struct UKismetMathLibrary_Multiply_RotatorInt_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_RotatorFloat
struct UKismetMathLibrary_Multiply_RotatorFloat_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_LinearColorLinearColor
struct UKismetMathLibrary_Multiply_LinearColorLinearColor_Params
{
	struct FLinearColor A; // (Parm, IsPlainOldData)
	struct FLinearColor B; // (Parm, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_LinearColorFloat
struct UKismetMathLibrary_Multiply_LinearColorFloat_Params
{
	struct FLinearColor A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_IntInt
struct UKismetMathLibrary_Multiply_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_IntFloat
struct UKismetMathLibrary_Multiply_IntFloat_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_FloatFloat
struct UKismetMathLibrary_Multiply_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Multiply_ByteByte
struct UKismetMathLibrary_Multiply_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MirrorVectorByNormal
struct UKismetMathLibrary_MirrorVectorByNormal_Params
{
	struct FVector InVect; // (Parm, IsPlainOldData)
	struct FVector InNormal; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MinOfIntArray
struct UKismetMathLibrary_MinOfIntArray_Params
{
	TArray<int> IntArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexOfMinValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int MinValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MinOfFloatArray
struct UKismetMathLibrary_MinOfFloatArray_Params
{
	TArray<float> FloatArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexOfMinValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float MinValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MinOfByteArray
struct UKismetMathLibrary_MinOfByteArray_Params
{
	TArray<unsigned char> ByteArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexOfMinValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	unsigned char MinValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MinimumAreaRectangle
struct UKismetMathLibrary_MinimumAreaRectangle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FVector> InVerts; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FVector SampleSurfaceNormal; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector OutRectCenter; // (Parm, OutParm, IsPlainOldData)
	struct FRotator OutRectRotation; // (Parm, OutParm, IsPlainOldData)
	float OutSideLengthX; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float OutSideLengthY; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool bDebugDraw; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Min
struct UKismetMathLibrary_Min_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MaxOfIntArray
struct UKismetMathLibrary_MaxOfIntArray_Params
{
	TArray<int> IntArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexOfMaxValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int MaxValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MaxOfFloatArray
struct UKismetMathLibrary_MaxOfFloatArray_Params
{
	TArray<float> FloatArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexOfMaxValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float MaxValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MaxOfByteArray
struct UKismetMathLibrary_MaxOfByteArray_Params
{
	TArray<unsigned char> ByteArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	int IndexOfMaxValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	unsigned char MaxValue; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Max
struct UKismetMathLibrary_Max_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MapRangeUnclamped
struct UKismetMathLibrary_MapRangeUnclamped_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float InRangeA; // (Parm, ZeroConstructor, IsPlainOldData)
	float InRangeB; // (Parm, ZeroConstructor, IsPlainOldData)
	float OutRangeA; // (Parm, ZeroConstructor, IsPlainOldData)
	float OutRangeB; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MapRangeClamped
struct UKismetMathLibrary_MapRangeClamped_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float InRangeA; // (Parm, ZeroConstructor, IsPlainOldData)
	float InRangeB; // (Parm, ZeroConstructor, IsPlainOldData)
	float OutRangeA; // (Parm, ZeroConstructor, IsPlainOldData)
	float OutRangeB; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeVector2D
struct UKismetMathLibrary_MakeVector2D_Params
{
	float X; // (Parm, ZeroConstructor, IsPlainOldData)
	float Y; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeVector
struct UKismetMathLibrary_MakeVector_Params
{
	float X; // (Parm, ZeroConstructor, IsPlainOldData)
	float Y; // (Parm, ZeroConstructor, IsPlainOldData)
	float Z; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeTransform
struct UKismetMathLibrary_MakeTransform_Params
{
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	struct FVector Scale; // (Parm, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeTimespan2
struct UKismetMathLibrary_MakeTimespan2_Params
{
	int Days; // (Parm, ZeroConstructor, IsPlainOldData)
	int hours; // (Parm, ZeroConstructor, IsPlainOldData)
	int Minutes; // (Parm, ZeroConstructor, IsPlainOldData)
	int Seconds; // (Parm, ZeroConstructor, IsPlainOldData)
	int FractionNano; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.MakeTimespan
struct UKismetMathLibrary_MakeTimespan_Params
{
	int Days; // (Parm, ZeroConstructor, IsPlainOldData)
	int hours; // (Parm, ZeroConstructor, IsPlainOldData)
	int Minutes; // (Parm, ZeroConstructor, IsPlainOldData)
	int Seconds; // (Parm, ZeroConstructor, IsPlainOldData)
	int Milliseconds; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.MakeRotFromZY
struct UKismetMathLibrary_MakeRotFromZY_Params
{
	struct FVector Z; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Y; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromZX
struct UKismetMathLibrary_MakeRotFromZX_Params
{
	struct FVector Z; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector X; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromZ
struct UKismetMathLibrary_MakeRotFromZ_Params
{
	struct FVector Z; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromYZ
struct UKismetMathLibrary_MakeRotFromYZ_Params
{
	struct FVector Y; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Z; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromYX
struct UKismetMathLibrary_MakeRotFromYX_Params
{
	struct FVector Y; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector X; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromY
struct UKismetMathLibrary_MakeRotFromY_Params
{
	struct FVector Y; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromXZ
struct UKismetMathLibrary_MakeRotFromXZ_Params
{
	struct FVector X; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Z; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromXY
struct UKismetMathLibrary_MakeRotFromXY_Params
{
	struct FVector X; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Y; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotFromX
struct UKismetMathLibrary_MakeRotFromX_Params
{
	struct FVector X; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotator
struct UKismetMathLibrary_MakeRotator_Params
{
	float Roll; // (Parm, ZeroConstructor, IsPlainOldData)
	float Pitch; // (Parm, ZeroConstructor, IsPlainOldData)
	float Yaw; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRotationFromAxes
struct UKismetMathLibrary_MakeRotationFromAxes_Params
{
	struct FVector Forward; // (Parm, IsPlainOldData)
	struct FVector Right; // (Parm, IsPlainOldData)
	struct FVector Up; // (Parm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeRandomStream
struct UKismetMathLibrary_MakeRandomStream_Params
{
	int InitialSeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRandomStream ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.MakePulsatingValue
struct UKismetMathLibrary_MakePulsatingValue_Params
{
	float InCurrentTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPulsesPerSecond; // (Parm, ZeroConstructor, IsPlainOldData)
	float InPhase; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakePlaneFromPointAndNormal
struct UKismetMathLibrary_MakePlaneFromPointAndNormal_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FVector Normal; // (Parm, IsPlainOldData)
	struct FPlane ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeDateTime
struct UKismetMathLibrary_MakeDateTime_Params
{
	int Year; // (Parm, ZeroConstructor, IsPlainOldData)
	int Month; // (Parm, ZeroConstructor, IsPlainOldData)
	int Day; // (Parm, ZeroConstructor, IsPlainOldData)
	int Hour; // (Parm, ZeroConstructor, IsPlainOldData)
	int Minute; // (Parm, ZeroConstructor, IsPlainOldData)
	int Second; // (Parm, ZeroConstructor, IsPlainOldData)
	int Millisecond; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.MakeColor
struct UKismetMathLibrary_MakeColor_Params
{
	float R; // (Parm, ZeroConstructor, IsPlainOldData)
	float G; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.MakeBox2D
struct UKismetMathLibrary_MakeBox2D_Params
{
	struct FVector2D Min; // (Parm, IsPlainOldData)
	struct FVector2D Max; // (Parm, IsPlainOldData)
	struct FBox2D ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.MakeBox
struct UKismetMathLibrary_MakeBox_Params
{
	struct FVector Min; // (Parm, IsPlainOldData)
	struct FVector Max; // (Parm, IsPlainOldData)
	struct FBox ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Loge
struct UKismetMathLibrary_Loge_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Log
struct UKismetMathLibrary_Log_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float Base; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LinePlaneIntersection_OriginNormal
struct UKismetMathLibrary_LinePlaneIntersection_OriginNormal_Params
{
	struct FVector LineStart; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector LineEnd; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector PlaneOrigin; // (Parm, IsPlainOldData)
	struct FVector PlaneNormal; // (Parm, IsPlainOldData)
	float T; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector Intersection; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LinePlaneIntersection
struct UKismetMathLibrary_LinePlaneIntersection_Params
{
	struct FVector LineStart; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector LineEnd; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FPlane APlane; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float T; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector Intersection; // (Parm, OutParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LinearColorLerpUsingHSV
struct UKismetMathLibrary_LinearColorLerpUsingHSV_Params
{
	struct FLinearColor A; // (Parm, IsPlainOldData)
	struct FLinearColor B; // (Parm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LinearColorLerp
struct UKismetMathLibrary_LinearColorLerp_Params
{
	struct FLinearColor A; // (Parm, IsPlainOldData)
	struct FLinearColor B; // (Parm, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LessLess_VectorRotator
struct UKismetMathLibrary_LessLess_VectorRotator_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LessEqual_TimespanTimespan
struct UKismetMathLibrary_LessEqual_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LessEqual_IntInt
struct UKismetMathLibrary_LessEqual_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LessEqual_FloatFloat
struct UKismetMathLibrary_LessEqual_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LessEqual_DateTimeDateTime
struct UKismetMathLibrary_LessEqual_DateTimeDateTime_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.LessEqual_ByteByte
struct UKismetMathLibrary_LessEqual_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Less_TimespanTimespan
struct UKismetMathLibrary_Less_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Less_IntInt
struct UKismetMathLibrary_Less_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Less_FloatFloat
struct UKismetMathLibrary_Less_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Less_DateTimeDateTime
struct UKismetMathLibrary_Less_DateTimeDateTime_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Less_ByteByte
struct UKismetMathLibrary_Less_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Lerp
struct UKismetMathLibrary_Lerp_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.IsPointInBoxWithTransform
struct UKismetMathLibrary_IsPointInBoxWithTransform_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FTransform BoxWorldTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector BoxExtent; // (Parm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.IsPointInBox
struct UKismetMathLibrary_IsPointInBox_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FVector BoxOrigin; // (Parm, IsPlainOldData)
	struct FVector BoxExtent; // (Parm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.IsMorning
struct UKismetMathLibrary_IsMorning_Params
{
	struct FDateTime A; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.IsLeapYear
struct UKismetMathLibrary_IsLeapYear_Params
{
	int Year; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.IsAfternoon
struct UKismetMathLibrary_IsAfternoon_Params
{
	struct FDateTime A; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.InvertTransform
struct UKismetMathLibrary_InvertTransform_Params
{
	struct FTransform T; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.InverseTransformRotation
struct UKismetMathLibrary_InverseTransformRotation_Params
{
	struct FTransform T; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.InverseTransformLocation
struct UKismetMathLibrary_InverseTransformLocation_Params
{
	struct FTransform T; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.InverseTransformDirection
struct UKismetMathLibrary_InverseTransformDirection_Params
{
	struct FTransform T; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Direction; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.InverseLerp
struct UKismetMathLibrary_InverseLerp_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.InRange_IntInt
struct UKismetMathLibrary_InRange_IntInt_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
	int Min; // (Parm, ZeroConstructor, IsPlainOldData)
	int Max; // (Parm, ZeroConstructor, IsPlainOldData)
	bool InclusiveMin; // (Parm, ZeroConstructor, IsPlainOldData)
	bool InclusiveMax; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.InRange_FloatFloat
struct UKismetMathLibrary_InRange_FloatFloat_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float Min; // (Parm, ZeroConstructor, IsPlainOldData)
	float Max; // (Parm, ZeroConstructor, IsPlainOldData)
	bool InclusiveMin; // (Parm, ZeroConstructor, IsPlainOldData)
	bool InclusiveMax; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Hypotenuse
struct UKismetMathLibrary_Hypotenuse_Params
{
	float Width; // (Parm, ZeroConstructor, IsPlainOldData)
	float Height; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.HSVToRGB_Vector
struct UKismetMathLibrary_HSVToRGB_Vector_Params
{
	struct FLinearColor HSV; // (ConstParm, Parm, IsPlainOldData)
	struct FLinearColor RGB; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.HSVToRGB
struct UKismetMathLibrary_HSVToRGB_Params
{
	float H; // (Parm, ZeroConstructor, IsPlainOldData)
	float S; // (Parm, ZeroConstructor, IsPlainOldData)
	float V; // (Parm, ZeroConstructor, IsPlainOldData)
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GridSnap_Float
struct UKismetMathLibrary_GridSnap_Float_Params
{
	float Location; // (Parm, ZeroConstructor, IsPlainOldData)
	float GridSize; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GreaterGreater_VectorRotator
struct UKismetMathLibrary_GreaterGreater_VectorRotator_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GreaterEqual_TimespanTimespan
struct UKismetMathLibrary_GreaterEqual_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GreaterEqual_IntInt
struct UKismetMathLibrary_GreaterEqual_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GreaterEqual_FloatFloat
struct UKismetMathLibrary_GreaterEqual_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GreaterEqual_DateTimeDateTime
struct UKismetMathLibrary_GreaterEqual_DateTimeDateTime_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GreaterEqual_ByteByte
struct UKismetMathLibrary_GreaterEqual_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Greater_TimespanTimespan
struct UKismetMathLibrary_Greater_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Greater_IntInt
struct UKismetMathLibrary_Greater_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Greater_FloatFloat
struct UKismetMathLibrary_Greater_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Greater_DateTimeDateTime
struct UKismetMathLibrary_Greater_DateTimeDateTime_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Greater_ByteByte
struct UKismetMathLibrary_Greater_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetYear
struct UKismetMathLibrary_GetYear_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetYawPitchFromVector
struct UKismetMathLibrary_GetYawPitchFromVector_Params
{
	struct FVector InVec; // (Parm, IsPlainOldData)
	float Yaw; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Pitch; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetVectorArrayAverage
struct UKismetMathLibrary_GetVectorArrayAverage_Params
{
	TArray<struct FVector> Vectors; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetUpVector
struct UKismetMathLibrary_GetUpVector_Params
{
	struct FRotator InRot; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetTotalSeconds
struct UKismetMathLibrary_GetTotalSeconds_Params
{
	struct FTimespan A; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetTotalMinutes
struct UKismetMathLibrary_GetTotalMinutes_Params
{
	struct FTimespan A; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetTotalMilliseconds
struct UKismetMathLibrary_GetTotalMilliseconds_Params
{
	struct FTimespan A; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetTotalHours
struct UKismetMathLibrary_GetTotalHours_Params
{
	struct FTimespan A; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetTotalDays
struct UKismetMathLibrary_GetTotalDays_Params
{
	struct FTimespan A; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetTimeOfDay
struct UKismetMathLibrary_GetTimeOfDay_Params
{
	struct FDateTime A; // (Parm)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.GetTAU
struct UKismetMathLibrary_GetTAU_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetSeconds
struct UKismetMathLibrary_GetSeconds_Params
{
	struct FTimespan A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetSecond
struct UKismetMathLibrary_GetSecond_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetRightVector
struct UKismetMathLibrary_GetRightVector_Params
{
	struct FRotator InRot; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetReflectionVector
struct UKismetMathLibrary_GetReflectionVector_Params
{
	struct FVector Direction; // (Parm, IsPlainOldData)
	struct FVector SurfaceNormal; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetPointDistanceToSegment
struct UKismetMathLibrary_GetPointDistanceToSegment_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FVector SegmentStart; // (Parm, IsPlainOldData)
	struct FVector SegmentEnd; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetPointDistanceToLine
struct UKismetMathLibrary_GetPointDistanceToLine_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FVector LineOrigin; // (Parm, IsPlainOldData)
	struct FVector LineDirection; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetPI
struct UKismetMathLibrary_GetPI_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetMonth
struct UKismetMathLibrary_GetMonth_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetMinutes
struct UKismetMathLibrary_GetMinutes_Params
{
	struct FTimespan A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetMinute
struct UKismetMathLibrary_GetMinute_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetMinElement
struct UKismetMathLibrary_GetMinElement_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetMilliseconds
struct UKismetMathLibrary_GetMilliseconds_Params
{
	struct FTimespan A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetMillisecond
struct UKismetMathLibrary_GetMillisecond_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetMaxElement
struct UKismetMathLibrary_GetMaxElement_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetHours
struct UKismetMathLibrary_GetHours_Params
{
	struct FTimespan A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetHour12
struct UKismetMathLibrary_GetHour12_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetHour
struct UKismetMathLibrary_GetHour_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetForwardVector
struct UKismetMathLibrary_GetForwardVector_Params
{
	struct FRotator InRot; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetDuration
struct UKismetMathLibrary_GetDuration_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.GetDirectionUnitVector
struct UKismetMathLibrary_GetDirectionUnitVector_Params
{
	struct FVector From; // (Parm, IsPlainOldData)
	struct FVector To; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetDays
struct UKismetMathLibrary_GetDays_Params
{
	struct FTimespan A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetDayOfYear
struct UKismetMathLibrary_GetDayOfYear_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetDay
struct UKismetMathLibrary_GetDay_Params
{
	struct FDateTime A; // (Parm)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetDate
struct UKismetMathLibrary_GetDate_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.GetAzimuthAndElevation
struct UKismetMathLibrary_GetAzimuthAndElevation_Params
{
	struct FVector InDirection; // (Parm, IsPlainOldData)
	struct FTransform ReferenceFrame; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	float Azimuth; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Elevation; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.GetAxes
struct UKismetMathLibrary_GetAxes_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FVector X; // (Parm, OutParm, IsPlainOldData)
	struct FVector Y; // (Parm, OutParm, IsPlainOldData)
	struct FVector Z; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FTruncVector
struct UKismetMathLibrary_FTruncVector_Params
{
	struct FVector InVector; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FIntVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FTrunc
struct UKismetMathLibrary_FTrunc_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FromSeconds
struct UKismetMathLibrary_FromSeconds_Params
{
	float Seconds; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.FromMinutes
struct UKismetMathLibrary_FromMinutes_Params
{
	float Minutes; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.FromMilliseconds
struct UKismetMathLibrary_FromMilliseconds_Params
{
	float Milliseconds; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.FromHours
struct UKismetMathLibrary_FromHours_Params
{
	float hours; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.FromDays
struct UKismetMathLibrary_FromDays_Params
{
	float Days; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Fraction
struct UKismetMathLibrary_Fraction_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FMod
struct UKismetMathLibrary_FMod_Params
{
	float Dividend; // (Parm, ZeroConstructor, IsPlainOldData)
	float Divisor; // (Parm, ZeroConstructor, IsPlainOldData)
	float Remainder; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FMin
struct UKismetMathLibrary_FMin_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FMax
struct UKismetMathLibrary_FMax_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FloatSpringInterp
struct UKismetMathLibrary_FloatSpringInterp_Params
{
	float Current; // (Parm, ZeroConstructor, IsPlainOldData)
	float Target; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FFloatSpringState SpringState; // (Parm, OutParm, ReferenceParm)
	float Stiffness; // (Parm, ZeroConstructor, IsPlainOldData)
	float CriticalDampingFactor; // (Parm, ZeroConstructor, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float Mass; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FixedTurn
struct UKismetMathLibrary_FixedTurn_Params
{
	float InCurrent; // (Parm, ZeroConstructor, IsPlainOldData)
	float InDesired; // (Parm, ZeroConstructor, IsPlainOldData)
	float InDeltaRate; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FInterpTo_Constant
struct UKismetMathLibrary_FInterpTo_Constant_Params
{
	float Current; // (Parm, ZeroConstructor, IsPlainOldData)
	float Target; // (Parm, ZeroConstructor, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FInterpTo
struct UKismetMathLibrary_FInterpTo_Params
{
	float Current; // (Parm, ZeroConstructor, IsPlainOldData)
	float Target; // (Parm, ZeroConstructor, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FInterpEaseInOut
struct UKismetMathLibrary_FInterpEaseInOut_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	float Exponent; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FindNearestPointsOnLineSegments
struct UKismetMathLibrary_FindNearestPointsOnLineSegments_Params
{
	struct FVector Segment1Start; // (Parm, IsPlainOldData)
	struct FVector Segment1End; // (Parm, IsPlainOldData)
	struct FVector Segment2Start; // (Parm, IsPlainOldData)
	struct FVector Segment2End; // (Parm, IsPlainOldData)
	struct FVector Segment1Point; // (Parm, OutParm, IsPlainOldData)
	struct FVector Segment2Point; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FindLookAtRotation
struct UKismetMathLibrary_FindLookAtRotation_Params
{
	struct FVector Start; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Target; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FindClosestPointOnSegment
struct UKismetMathLibrary_FindClosestPointOnSegment_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FVector SegmentStart; // (Parm, IsPlainOldData)
	struct FVector SegmentEnd; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FindClosestPointOnLine
struct UKismetMathLibrary_FindClosestPointOnLine_Params
{
	struct FVector Point; // (Parm, IsPlainOldData)
	struct FVector LineOrigin; // (Parm, IsPlainOldData)
	struct FVector LineDirection; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FFloor
struct UKismetMathLibrary_FFloor_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FClamp
struct UKismetMathLibrary_FClamp_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float Min; // (Parm, ZeroConstructor, IsPlainOldData)
	float Max; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.FCeil
struct UKismetMathLibrary_FCeil_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Exp
struct UKismetMathLibrary_Exp_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_VectorVector
struct UKismetMathLibrary_EqualEqual_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	float ErrorTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_Vector2DVector2D
struct UKismetMathLibrary_EqualEqual_Vector2DVector2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	float ErrorTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_TransformTransform
struct UKismetMathLibrary_EqualEqual_TransformTransform_Params
{
	struct FTransform A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_TimespanTimespan
struct UKismetMathLibrary_EqualEqual_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_RotatorRotator
struct UKismetMathLibrary_EqualEqual_RotatorRotator_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	float ErrorTolerance; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_ObjectObject
struct UKismetMathLibrary_EqualEqual_ObjectObject_Params
{
	class UObject* A; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_NameName
struct UKismetMathLibrary_EqualEqual_NameName_Params
{
	struct FName A; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_IntInt
struct UKismetMathLibrary_EqualEqual_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_FloatFloat
struct UKismetMathLibrary_EqualEqual_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_DateTimeDateTime
struct UKismetMathLibrary_EqualEqual_DateTimeDateTime_Params
{
	struct FDateTime A; // (Parm)
	struct FDateTime B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_ClassClass
struct UKismetMathLibrary_EqualEqual_ClassClass_Params
{
	class UClass* A; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_ByteByte
struct UKismetMathLibrary_EqualEqual_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.EqualEqual_BoolBool
struct UKismetMathLibrary_EqualEqual_BoolBool_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Ease
struct UKismetMathLibrary_Ease_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EEasingFunc> EasingFunc; // (Parm, ZeroConstructor, IsPlainOldData)
	float BlendExp; // (Parm, ZeroConstructor, IsPlainOldData)
	int Steps; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DotProduct2D
struct UKismetMathLibrary_DotProduct2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Dot_VectorVector
struct UKismetMathLibrary_Dot_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_VectorVector
struct UKismetMathLibrary_Divide_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_VectorInt
struct UKismetMathLibrary_Divide_VectorInt_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_VectorFloat
struct UKismetMathLibrary_Divide_VectorFloat_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_Vector2DVector2D
struct UKismetMathLibrary_Divide_Vector2DVector2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_Vector2DFloat
struct UKismetMathLibrary_Divide_Vector2DFloat_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_TimespanFloat
struct UKismetMathLibrary_Divide_TimespanFloat_Params
{
	struct FTimespan A; // (Parm)
	float Scalar; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Divide_IntInt
struct UKismetMathLibrary_Divide_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_FloatFloat
struct UKismetMathLibrary_Divide_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Divide_ByteByte
struct UKismetMathLibrary_Divide_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegTan
struct UKismetMathLibrary_DegTan_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegSin
struct UKismetMathLibrary_DegSin_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegreesToRadians
struct UKismetMathLibrary_DegreesToRadians_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegCos
struct UKismetMathLibrary_DegCos_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegAtan2
struct UKismetMathLibrary_DegAtan2_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegAtan
struct UKismetMathLibrary_DegAtan_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegAsin
struct UKismetMathLibrary_DegAsin_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DegAcos
struct UKismetMathLibrary_DegAcos_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DaysInYear
struct UKismetMathLibrary_DaysInYear_Params
{
	int Year; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DaysInMonth
struct UKismetMathLibrary_DaysInMonth_Params
{
	int Year; // (Parm, ZeroConstructor, IsPlainOldData)
	int Month; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DateTimeMinValue
struct UKismetMathLibrary_DateTimeMinValue_Params
{
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.DateTimeMaxValue
struct UKismetMathLibrary_DateTimeMaxValue_Params
{
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.DateTimeFromString
struct UKismetMathLibrary_DateTimeFromString_Params
{
	struct FString DateTimeString; // (Parm, ZeroConstructor)
	struct FDateTime Result; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.DateTimeFromIsoString
struct UKismetMathLibrary_DateTimeFromIsoString_Params
{
	struct FString IsoString; // (Parm, ZeroConstructor)
	struct FDateTime Result; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.CrossProduct2D
struct UKismetMathLibrary_CrossProduct2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Cross_VectorVector
struct UKismetMathLibrary_Cross_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.CreateVectorFromYawPitch
struct UKismetMathLibrary_CreateVectorFromYawPitch_Params
{
	float Yaw; // (Parm, ZeroConstructor, IsPlainOldData)
	float Pitch; // (Parm, ZeroConstructor, IsPlainOldData)
	float Length; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Cos
struct UKismetMathLibrary_Cos_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ConvertTransformToRelative
struct UKismetMathLibrary_ConvertTransformToRelative_Params
{
	struct FTransform Transform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform ParentTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_VectorToVector2D
struct UKismetMathLibrary_Conv_VectorToVector2D_Params
{
	struct FVector InVector; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_VectorToTransform
struct UKismetMathLibrary_Conv_VectorToTransform_Params
{
	struct FVector InLocation; // (Parm, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_VectorToRotator
struct UKismetMathLibrary_Conv_VectorToRotator_Params
{
	struct FVector InVec; // (Parm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_VectorToLinearColor
struct UKismetMathLibrary_Conv_VectorToLinearColor_Params
{
	struct FVector InVec; // (Parm, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_Vector2DToVector
struct UKismetMathLibrary_Conv_Vector2DToVector_Params
{
	struct FVector2D InVector2D; // (Parm, IsPlainOldData)
	float Z; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_RotatorToVector
struct UKismetMathLibrary_Conv_RotatorToVector_Params
{
	struct FRotator InRot; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_LinearColorToVector
struct UKismetMathLibrary_Conv_LinearColorToVector_Params
{
	struct FLinearColor InLinearColor; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_LinearColorToColor
struct UKismetMathLibrary_Conv_LinearColorToColor_Params
{
	struct FLinearColor InLinearColor; // (Parm, IsPlainOldData)
	struct FColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_IntVectorToVector
struct UKismetMathLibrary_Conv_IntVectorToVector_Params
{
	struct FIntVector InIntVector; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_IntToIntVector
struct UKismetMathLibrary_Conv_IntToIntVector_Params
{
	int inInt; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FIntVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_IntToFloat
struct UKismetMathLibrary_Conv_IntToFloat_Params
{
	int inInt; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_IntToByte
struct UKismetMathLibrary_Conv_IntToByte_Params
{
	int inInt; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_IntToBool
struct UKismetMathLibrary_Conv_IntToBool_Params
{
	int inInt; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_FloatToVector
struct UKismetMathLibrary_Conv_FloatToVector_Params
{
	float InFloat; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_FloatToLinearColor
struct UKismetMathLibrary_Conv_FloatToLinearColor_Params
{
	float InFloat; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_ColorToLinearColor
struct UKismetMathLibrary_Conv_ColorToLinearColor_Params
{
	struct FColor InColor; // (Parm, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_ByteToInt
struct UKismetMathLibrary_Conv_ByteToInt_Params
{
	unsigned char InByte; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_ByteToFloat
struct UKismetMathLibrary_Conv_ByteToFloat_Params
{
	unsigned char InByte; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_BoolToInt
struct UKismetMathLibrary_Conv_BoolToInt_Params
{
	bool InBool; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_BoolToFloat
struct UKismetMathLibrary_Conv_BoolToFloat_Params
{
	bool InBool; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Conv_BoolToByte
struct UKismetMathLibrary_Conv_BoolToByte_Params
{
	bool InBool; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ComposeTransforms
struct UKismetMathLibrary_ComposeTransforms_Params
{
	struct FTransform A; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform B; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ComposeRotators
struct UKismetMathLibrary_ComposeRotators_Params
{
	struct FRotator A; // (Parm, IsPlainOldData)
	struct FRotator B; // (Parm, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ClassIsChildOf
struct UKismetMathLibrary_ClassIsChildOf_Params
{
	class UClass* TestClass; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* ParentClass; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ClampVectorSize
struct UKismetMathLibrary_ClampVectorSize_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float Min; // (Parm, ZeroConstructor, IsPlainOldData)
	float Max; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ClampAxis
struct UKismetMathLibrary_ClampAxis_Params
{
	float Angle; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.ClampAngle
struct UKismetMathLibrary_ClampAngle_Params
{
	float AngleDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	float MinAngleDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	float MaxAngleDegrees; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Clamp
struct UKismetMathLibrary_Clamp_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
	int Min; // (Parm, ZeroConstructor, IsPlainOldData)
	int Max; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.CInterpTo
struct UKismetMathLibrary_CInterpTo_Params
{
	struct FLinearColor Current; // (Parm, IsPlainOldData)
	struct FLinearColor Target; // (Parm, IsPlainOldData)
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakVector2D
struct UKismetMathLibrary_BreakVector2D_Params
{
	struct FVector2D InVec; // (Parm, IsPlainOldData)
	float X; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Y; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakVector
struct UKismetMathLibrary_BreakVector_Params
{
	struct FVector InVec; // (Parm, IsPlainOldData)
	float X; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Y; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Z; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakTransform
struct UKismetMathLibrary_BreakTransform_Params
{
	struct FTransform InTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Location; // (Parm, OutParm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, OutParm, IsPlainOldData)
	struct FVector Scale; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakTimespan2
struct UKismetMathLibrary_BreakTimespan2_Params
{
	struct FTimespan InTimespan; // (Parm)
	int Days; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int hours; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Minutes; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Seconds; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int FractionNano; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakTimespan
struct UKismetMathLibrary_BreakTimespan_Params
{
	struct FTimespan InTimespan; // (Parm)
	int Days; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int hours; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Minutes; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Seconds; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Milliseconds; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakRotIntoAxes
struct UKismetMathLibrary_BreakRotIntoAxes_Params
{
	struct FRotator InRot; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector X; // (Parm, OutParm, IsPlainOldData)
	struct FVector Y; // (Parm, OutParm, IsPlainOldData)
	struct FVector Z; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakRotator
struct UKismetMathLibrary_BreakRotator_Params
{
	struct FRotator InRot; // (Parm, IsPlainOldData)
	float Roll; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Pitch; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float Yaw; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakRandomStream
struct UKismetMathLibrary_BreakRandomStream_Params
{
	struct FRandomStream InRandomStream; // (ConstParm, Parm, OutParm, ReferenceParm)
	int InitialSeed; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakDateTime
struct UKismetMathLibrary_BreakDateTime_Params
{
	struct FDateTime InDateTime; // (Parm)
	int Year; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Month; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Day; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Hour; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Minute; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Second; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Millisecond; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BreakColor
struct UKismetMathLibrary_BreakColor_Params
{
	struct FLinearColor InColor; // (ConstParm, Parm, IsPlainOldData)
	float R; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float G; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float A; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BooleanXOR
struct UKismetMathLibrary_BooleanXOR_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BooleanOR
struct UKismetMathLibrary_BooleanOR_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BooleanNOR
struct UKismetMathLibrary_BooleanNOR_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BooleanNAND
struct UKismetMathLibrary_BooleanNAND_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BooleanAND
struct UKismetMathLibrary_BooleanAND_Params
{
	bool A; // (Parm, ZeroConstructor, IsPlainOldData)
	bool B; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BMin
struct UKismetMathLibrary_BMin_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.BMax
struct UKismetMathLibrary_BMax_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Atan2
struct UKismetMathLibrary_Atan2_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Atan
struct UKismetMathLibrary_Atan_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Asin
struct UKismetMathLibrary_Asin_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.And_IntInt
struct UKismetMathLibrary_And_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_VectorVector
struct UKismetMathLibrary_Add_VectorVector_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	struct FVector B; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_VectorInt
struct UKismetMathLibrary_Add_VectorInt_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_VectorFloat
struct UKismetMathLibrary_Add_VectorFloat_Params
{
	struct FVector A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_Vector2DVector2D
struct UKismetMathLibrary_Add_Vector2DVector2D_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	struct FVector2D B; // (Parm, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_Vector2DFloat
struct UKismetMathLibrary_Add_Vector2DFloat_Params
{
	struct FVector2D A; // (Parm, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_TimespanTimespan
struct UKismetMathLibrary_Add_TimespanTimespan_Params
{
	struct FTimespan A; // (Parm)
	struct FTimespan B; // (Parm)
	struct FTimespan ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Add_IntInt
struct UKismetMathLibrary_Add_IntInt_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int B; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_FloatFloat
struct UKismetMathLibrary_Add_FloatFloat_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float B; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Add_DateTimeTimespan
struct UKismetMathLibrary_Add_DateTimeTimespan_Params
{
	struct FDateTime A; // (Parm)
	struct FTimespan B; // (Parm)
	struct FDateTime ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetMathLibrary.Add_ByteByte
struct UKismetMathLibrary_Add_ByteByte_Params
{
	unsigned char A; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char B; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Acos
struct UKismetMathLibrary_Acos_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Abs_Int
struct UKismetMathLibrary_Abs_Int_Params
{
	int A; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetMathLibrary.Abs
struct UKismetMathLibrary_Abs_Params
{
	float A; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.MarkBit
struct UKismetNodeHelperLibrary_MarkBit_Params
{
	int Data; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.HasUnmarkedBit
struct UKismetNodeHelperLibrary_HasUnmarkedBit_Params
{
	int Data; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumBits; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.HasMarkedBit
struct UKismetNodeHelperLibrary_HasMarkedBit_Params
{
	int Data; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumBits; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.GetValidValue
struct UKismetNodeHelperLibrary_GetValidValue_Params
{
	class UEnum* Enum; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	unsigned char EnumeratorValue; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.GetUnmarkedBit
struct UKismetNodeHelperLibrary_GetUnmarkedBit_Params
{
	int Data; // (Parm, ZeroConstructor, IsPlainOldData)
	int StartIdx; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumBits; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bRandom; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.GetRandomUnmarkedBit
struct UKismetNodeHelperLibrary_GetRandomUnmarkedBit_Params
{
	int Data; // (Parm, ZeroConstructor, IsPlainOldData)
	int StartIdx; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumBits; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.GetFirstUnmarkedBit
struct UKismetNodeHelperLibrary_GetFirstUnmarkedBit_Params
{
	int Data; // (Parm, ZeroConstructor, IsPlainOldData)
	int StartIdx; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumBits; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.GetEnumeratorValueFromIndex
struct UKismetNodeHelperLibrary_GetEnumeratorValueFromIndex_Params
{
	class UEnum* Enum; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	unsigned char EnumeratorIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.GetEnumeratorUserFriendlyName
struct UKismetNodeHelperLibrary_GetEnumeratorUserFriendlyName_Params
{
	class UEnum* Enum; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	unsigned char EnumeratorValue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetNodeHelperLibrary.GetEnumeratorName
struct UKismetNodeHelperLibrary_GetEnumeratorName_Params
{
	class UEnum* Enum; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	unsigned char EnumeratorValue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.ClearBit
struct UKismetNodeHelperLibrary_ClearBit_Params
{
	int Data; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.ClearAllBits
struct UKismetNodeHelperLibrary_ClearAllBits_Params
{
	int Data; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetNodeHelperLibrary.BitIsMarked
struct UKismetNodeHelperLibrary_BitIsMarked_Params
{
	int Data; // (Parm, ZeroConstructor, IsPlainOldData)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.RenderTargetCreateStaticTexture2DEditorOnly
struct UKismetRenderingLibrary_RenderTargetCreateStaticTexture2DEditorOnly_Params
{
	class UTextureRenderTarget2D* RenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Name; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ETextureCompressionSettings> CompressionSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETextureMipGenSettings> MipSettings; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture2D* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.ReleaseRenderTarget2D
struct UKismetRenderingLibrary_ReleaseRenderTarget2D_Params
{
	class UTextureRenderTarget2D* TextureRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.ReadRenderTargetRawUV
struct UKismetRenderingLibrary_ReadRenderTargetRawUV_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* TextureRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	float U; // (Parm, ZeroConstructor, IsPlainOldData)
	float V; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.ReadRenderTargetRawPixel
struct UKismetRenderingLibrary_ReadRenderTargetRawPixel_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* TextureRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	int X; // (Parm, ZeroConstructor, IsPlainOldData)
	int Y; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.MakeSkinWeightInfo
struct UKismetRenderingLibrary_MakeSkinWeightInfo_Params
{
	int Bone0; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight0; // (Parm, ZeroConstructor, IsPlainOldData)
	int Bone1; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight1; // (Parm, ZeroConstructor, IsPlainOldData)
	int Bone2; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight2; // (Parm, ZeroConstructor, IsPlainOldData)
	int Bone3; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight3; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FSkelMeshSkinWeightInfo ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.ExportTexture2D
struct UKismetRenderingLibrary_ExportTexture2D_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture2D* Texture; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FilePath; // (Parm, ZeroConstructor)
	struct FString Filename; // (Parm, ZeroConstructor)
};

// Function Engine.KismetRenderingLibrary.ExportRenderTarget
struct UKismetRenderingLibrary_ExportRenderTarget_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* TextureRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FilePath; // (Parm, ZeroConstructor)
	struct FString Filename; // (Parm, ZeroConstructor)
};

// Function Engine.KismetRenderingLibrary.EndDrawCanvasToRenderTarget
struct UKismetRenderingLibrary_EndDrawCanvasToRenderTarget_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDrawToRenderTargetContext Context; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetRenderingLibrary.DrawMaterialToRenderTarget
struct UKismetRenderingLibrary_DrawMaterialToRenderTarget_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* TextureRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.CreateRenderTarget2D
struct UKismetRenderingLibrary_CreateRenderTarget2D_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	int Width; // (Parm, ZeroConstructor, IsPlainOldData)
	int Height; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETextureRenderTargetFormat> Format; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.ConvertRenderTargetToTexture2DEditorOnly
struct UKismetRenderingLibrary_ConvertRenderTargetToTexture2DEditorOnly_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* RenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture2D* Texture; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.ClearRenderTarget2D
struct UKismetRenderingLibrary_ClearRenderTarget2D_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* TextureRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ClearColor; // (Parm, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.BreakSkinWeightInfo
struct UKismetRenderingLibrary_BreakSkinWeightInfo_Params
{
	struct FSkelMeshSkinWeightInfo InWeight; // (Parm, IsPlainOldData)
	int Bone0; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight0; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Bone1; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight1; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Bone2; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight2; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	int Bone3; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	unsigned char Weight3; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetRenderingLibrary.BeginDrawCanvasToRenderTarget
struct UKismetRenderingLibrary_BeginDrawCanvasToRenderTarget_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureRenderTarget2D* TextureRenderTarget; // (Parm, ZeroConstructor, IsPlainOldData)
	class UCanvas* Canvas; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FVector2D Size; // (Parm, OutParm, IsPlainOldData)
	struct FDrawToRenderTargetContext Context; // (Parm, OutParm)
};

// Function Engine.KismetStringLibrary.TrimTrailing
struct UKismetStringLibrary_TrimTrailing_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Trim
struct UKismetStringLibrary_Trim_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.ToUpper
struct UKismetStringLibrary_ToUpper_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.ToLower
struct UKismetStringLibrary_ToLower_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.TimeSecondsToString
struct UKismetStringLibrary_TimeSecondsToString_Params
{
	float InSeconds; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.StartsWith
struct UKismetStringLibrary_StartsWith_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString InPrefix; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ESearchCase> SearchCase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Split
struct UKismetStringLibrary_Split_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString InStr; // (Parm, ZeroConstructor)
	struct FString LeftS; // (Parm, OutParm, ZeroConstructor)
	struct FString RightS; // (Parm, OutParm, ZeroConstructor)
	TEnumAsByte<enum ESearchCase> SearchCase; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ESearchDir> SearchDir; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.RightPad
struct UKismetStringLibrary_RightPad_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int ChCount; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.RightChop
struct UKismetStringLibrary_RightChop_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int Count; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Right
struct UKismetStringLibrary_Right_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int Count; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Reverse
struct UKismetStringLibrary_Reverse_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.ReplaceInline
struct UKismetStringLibrary_ReplaceInline_Params
{
	struct FString sourceString; // (Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FString SearchText; // (Parm, ZeroConstructor)
	struct FString ReplacementText; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ESearchCase> SearchCase; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Replace
struct UKismetStringLibrary_Replace_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString From; // (Parm, ZeroConstructor)
	struct FString To; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ESearchCase> SearchCase; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.ParseIntoArray
struct UKismetStringLibrary_ParseIntoArray_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString Delimiter; // (Parm, ZeroConstructor)
	bool CullEmptyStrings; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FString> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.NotEqual_StrStr
struct UKismetStringLibrary_NotEqual_StrStr_Params
{
	struct FString A; // (Parm, ZeroConstructor)
	struct FString B; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.NotEqual_StriStri
struct UKismetStringLibrary_NotEqual_StriStri_Params
{
	struct FString A; // (Parm, ZeroConstructor)
	struct FString B; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Mid
struct UKismetStringLibrary_Mid_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int Start; // (Parm, ZeroConstructor, IsPlainOldData)
	int Count; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.MatchesWildcard
struct UKismetStringLibrary_MatchesWildcard_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString Wildcard; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ESearchCase> SearchCase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Len
struct UKismetStringLibrary_Len_Params
{
	struct FString S; // (Parm, ZeroConstructor)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.LeftPad
struct UKismetStringLibrary_LeftPad_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int ChCount; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.LeftChop
struct UKismetStringLibrary_LeftChop_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int Count; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Left
struct UKismetStringLibrary_Left_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int Count; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.JoinStringArray
struct UKismetStringLibrary_JoinStringArray_Params
{
	TArray<struct FString> SourceArray; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	struct FString Separator; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.IsNumeric
struct UKismetStringLibrary_IsNumeric_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.GetSubstring
struct UKismetStringLibrary_GetSubstring_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int StartIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int Length; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.GetCharacterAsNumber
struct UKismetStringLibrary_GetCharacterAsNumber_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.GetCharacterArrayFromString
struct UKismetStringLibrary_GetCharacterArrayFromString_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	TArray<struct FString> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.FindSubstring
struct UKismetStringLibrary_FindSubstring_Params
{
	struct FString SearchIn; // (Parm, ZeroConstructor)
	struct FString Substring; // (Parm, ZeroConstructor)
	bool bUseCase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSearchFromEnd; // (Parm, ZeroConstructor, IsPlainOldData)
	int StartPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.EqualEqual_StrStr
struct UKismetStringLibrary_EqualEqual_StrStr_Params
{
	struct FString A; // (Parm, ZeroConstructor)
	struct FString B; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.EqualEqual_StriStri
struct UKismetStringLibrary_EqualEqual_StriStri_Params
{
	struct FString A; // (Parm, ZeroConstructor)
	struct FString B; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.EndsWith
struct UKismetStringLibrary_EndsWith_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	struct FString InSuffix; // (Parm, ZeroConstructor)
	TEnumAsByte<enum ESearchCase> SearchCase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.CullArray
struct UKismetStringLibrary_CullArray_Params
{
	struct FString sourceString; // (Parm, ZeroConstructor)
	TArray<struct FString> inArray; // (Parm, OutParm, ZeroConstructor)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_VectorToString
struct UKismetStringLibrary_Conv_VectorToString_Params
{
	struct FVector InVec; // (Parm, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_Vector2dToString
struct UKismetStringLibrary_Conv_Vector2dToString_Params
{
	struct FVector2D InVec; // (Parm, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_TransformToString
struct UKismetStringLibrary_Conv_TransformToString_Params
{
	struct FTransform InTrans; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_StringToVector2D
struct UKismetStringLibrary_Conv_StringToVector2D_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	struct FVector2D OutConvertedVector2D; // (Parm, OutParm, IsPlainOldData)
	bool OutIsValid; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_StringToVector
struct UKismetStringLibrary_Conv_StringToVector_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	struct FVector OutConvertedVector; // (Parm, OutParm, IsPlainOldData)
	bool OutIsValid; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_StringToRotator
struct UKismetStringLibrary_Conv_StringToRotator_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	struct FRotator OutConvertedRotator; // (Parm, OutParm, IsPlainOldData)
	bool OutIsValid; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_StringToName
struct UKismetStringLibrary_Conv_StringToName_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_StringToInt
struct UKismetStringLibrary_Conv_StringToInt_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_StringToFloat
struct UKismetStringLibrary_Conv_StringToFloat_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_StringToColor
struct UKismetStringLibrary_Conv_StringToColor_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	struct FLinearColor OutConvertedColor; // (Parm, OutParm, IsPlainOldData)
	bool OutIsValid; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Conv_RotatorToString
struct UKismetStringLibrary_Conv_RotatorToString_Params
{
	struct FRotator InRot; // (Parm, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_ObjectToString
struct UKismetStringLibrary_Conv_ObjectToString_Params
{
	class UObject* InObj; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_NameToString
struct UKismetStringLibrary_Conv_NameToString_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_IntVectorToString
struct UKismetStringLibrary_Conv_IntVectorToString_Params
{
	struct FIntVector InIntVec; // (Parm, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_IntToString
struct UKismetStringLibrary_Conv_IntToString_Params
{
	int inInt; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_FloatToString
struct UKismetStringLibrary_Conv_FloatToString_Params
{
	float InFloat; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_ColorToString
struct UKismetStringLibrary_Conv_ColorToString_Params
{
	struct FLinearColor InColor; // (Parm, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_ByteToString
struct UKismetStringLibrary_Conv_ByteToString_Params
{
	unsigned char InByte; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Conv_BoolToString
struct UKismetStringLibrary_Conv_BoolToString_Params
{
	bool InBool; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.Contains
struct UKismetStringLibrary_Contains_Params
{
	struct FString SearchIn; // (Parm, ZeroConstructor)
	struct FString Substring; // (Parm, ZeroConstructor)
	bool bUseCase; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSearchFromEnd; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringLibrary.Concat_StrStr
struct UKismetStringLibrary_Concat_StrStr_Params
{
	struct FString A; // (Parm, ZeroConstructor)
	struct FString B; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Vector2d
struct UKismetStringLibrary_BuildString_Vector2d_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	struct FVector2D InVector2D; // (Parm, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Vector
struct UKismetStringLibrary_BuildString_Vector_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	struct FVector InVector; // (Parm, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Rotator
struct UKismetStringLibrary_BuildString_Rotator_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	struct FRotator InRot; // (Parm, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Object
struct UKismetStringLibrary_BuildString_Object_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	class UObject* InObj; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Name
struct UKismetStringLibrary_BuildString_Name_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_IntVector
struct UKismetStringLibrary_BuildString_IntVector_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	struct FIntVector InIntVector; // (Parm, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Int
struct UKismetStringLibrary_BuildString_Int_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	int inInt; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Float
struct UKismetStringLibrary_BuildString_Float_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	float InFloat; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Color
struct UKismetStringLibrary_BuildString_Color_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	struct FLinearColor InColor; // (Parm, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringLibrary.BuildString_Bool
struct UKismetStringLibrary_BuildString_Bool_Params
{
	struct FString AppendTo; // (Parm, ZeroConstructor)
	struct FString Prefix; // (Parm, ZeroConstructor)
	bool InBool; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Suffix; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringTableLibrary.IsRegisteredTableId
struct UKismetStringTableLibrary_IsRegisteredTableId_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringTableLibrary.IsRegisteredTableEntry
struct UKismetStringTableLibrary_IsRegisteredTableEntry_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString Key; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetStringTableLibrary.GetTableNamespace
struct UKismetStringTableLibrary_GetTableNamespace_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringTableLibrary.GetTableEntrySourceString
struct UKismetStringTableLibrary_GetTableEntrySourceString_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString Key; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringTableLibrary.GetTableEntryMetaData
struct UKismetStringTableLibrary_GetTableEntryMetaData_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString Key; // (Parm, ZeroConstructor)
	struct FName MetaDataId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringTableLibrary.GetRegisteredStringTables
struct UKismetStringTableLibrary_GetRegisteredStringTables_Params
{
	TArray<struct FName> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringTableLibrary.GetMetaDataIdsFromStringTableEntry
struct UKismetStringTableLibrary_GetMetaDataIdsFromStringTableEntry_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString Key; // (Parm, ZeroConstructor)
	TArray<struct FName> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetStringTableLibrary.GetKeysFromStringTable
struct UKismetStringTableLibrary_GetKeysFromStringTable_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FString> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.UnregisterForRemoteNotifications
struct UKismetSystemLibrary_UnregisterForRemoteNotifications_Params
{
};

// Function Engine.KismetSystemLibrary.UnloadPrimaryAssetList
struct UKismetSystemLibrary_UnloadPrimaryAssetList_Params
{
	TArray<struct FPrimaryAssetId> PrimaryAssetIdList; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.KismetSystemLibrary.UnloadPrimaryAsset
struct UKismetSystemLibrary_UnloadPrimaryAsset_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
};

// Function Engine.KismetSystemLibrary.StackTrace
struct UKismetSystemLibrary_StackTrace_Params
{
};

// Function Engine.KismetSystemLibrary.SphereTraceSingleForObjects
struct UKismetSystemLibrary_SphereTraceSingleForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SphereTraceSingleByProfile
struct UKismetSystemLibrary_SphereTraceSingleByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SphereTraceSingle
struct UKismetSystemLibrary_SphereTraceSingle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SphereTraceMultiForObjects
struct UKismetSystemLibrary_SphereTraceMultiForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SphereTraceMultiByProfile
struct UKismetSystemLibrary_SphereTraceMultiByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SphereTraceMulti
struct UKismetSystemLibrary_SphereTraceMulti_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SphereOverlapComponents
struct UKismetSystemLibrary_SphereOverlapComponents_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector SpherePos; // (ConstParm, Parm, IsPlainOldData)
	float SphereRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ComponentClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class UPrimitiveComponent*> OutComponents; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SphereOverlapActors
struct UKismetSystemLibrary_SphereOverlapActors_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector SpherePos; // (ConstParm, Parm, IsPlainOldData)
	float SphereRadius; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ActorClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ShowPlatformSpecificLeaderboardScreen
struct UKismetSystemLibrary_ShowPlatformSpecificLeaderboardScreen_Params
{
	struct FString CategoryName; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.ShowPlatformSpecificAchievementsScreen
struct UKismetSystemLibrary_ShowPlatformSpecificAchievementsScreen_Params
{
	class APlayerController* SpecificPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ShowInterstitialAd
struct UKismetSystemLibrary_ShowInterstitialAd_Params
{
};

// Function Engine.KismetSystemLibrary.ShowAdBanner
struct UKismetSystemLibrary_ShowAdBanner_Params
{
	int AdIdIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bShowOnBottomOfScreen; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetWindowTitle
struct UKismetSystemLibrary_SetWindowTitle_Params
{
	struct FText Title; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetSystemLibrary.SetVolumeButtonsHandledBySystem
struct UKismetSystemLibrary_SetVolumeButtonsHandledBySystem_Params
{
	bool bEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetVectorPropertyByName
struct UKismetSystemLibrary_SetVectorPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Value; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetUserActivity
struct UKismetSystemLibrary_SetUserActivity_Params
{
	struct FUserActivity UserActivity; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetSystemLibrary.SetTransformPropertyByName
struct UKismetSystemLibrary_SetTransformPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform Value; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetTextPropertyByName
struct UKismetSystemLibrary_SetTextPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText Value; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetSystemLibrary.SetSuppressViewportTransitionMessage
struct UKismetSystemLibrary_SetSuppressViewportTransitionMessage_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bState; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetStructurePropertyByName
struct UKismetSystemLibrary_SetStructurePropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FGenericStruct Value; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetStringPropertyByName
struct UKismetSystemLibrary_SetStringPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Value; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.SetSoftObjectPropertyByName
struct UKismetSystemLibrary_SetSoftObjectPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetSoftClassPropertyByName
struct UKismetSystemLibrary_SetSoftClassPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetRotatorPropertyByName
struct UKismetSystemLibrary_SetRotatorPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator Value; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetObjectPropertyByName
struct UKismetSystemLibrary_SetObjectPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UObject* Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetNamePropertyByName
struct UKismetSystemLibrary_SetNamePropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName Value; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetLinearColorPropertyByName
struct UKismetSystemLibrary_SetLinearColorPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor Value; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetIntPropertyByName
struct UKismetSystemLibrary_SetIntPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetInterfacePropertyByName
struct UKismetSystemLibrary_SetInterfacePropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	TScriptInterface<class UInterface> Value; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetFloatPropertyByName
struct UKismetSystemLibrary_SetFloatPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetCollisionProfileNameProperty
struct UKismetSystemLibrary_SetCollisionProfileNameProperty_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FCollisionProfileName Value; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetSystemLibrary.SetClassPropertyByName
struct UKismetSystemLibrary_SetClassPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetBytePropertyByName
struct UKismetSystemLibrary_SetBytePropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.SetBoolPropertyByName
struct UKismetSystemLibrary_SetBoolPropertyByName_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName PropertyName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.RetriggerableDelay
struct UKismetSystemLibrary_RetriggerableDelay_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.KismetSystemLibrary.ResetGamepadAssignmentToController
struct UKismetSystemLibrary_ResetGamepadAssignmentToController_Params
{
	int ControllerId; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ResetGamepadAssignments
struct UKismetSystemLibrary_ResetGamepadAssignments_Params
{
};

// Function Engine.KismetSystemLibrary.RegisterForRemoteNotifications
struct UKismetSystemLibrary_RegisterForRemoteNotifications_Params
{
};

// Function Engine.KismetSystemLibrary.RedirectSoftObjectPaths
struct UKismetSystemLibrary_RedirectSoftObjectPaths_Params
{
	TArray<struct FSoftObjectPath> Paths; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FSoftObjectPath> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.QuitGame
struct UKismetSystemLibrary_QuitGame_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class APlayerController* SpecificPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EQuitPreference> QuitPreference; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.PrintWarning
struct UKismetSystemLibrary_PrintWarning_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.PrintText
struct UKismetSystemLibrary_PrintText_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText InText; // (ConstParm, Parm)
	bool bPrintToScreen; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPrintToLog; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TextColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.PrintString
struct UKismetSystemLibrary_PrintString_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString inString; // (Parm, ZeroConstructor)
	bool bPrintToScreen; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPrintToLog; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TextColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.PrintShippingString
struct UKismetSystemLibrary_PrintShippingString_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString inString; // (Parm, ZeroConstructor)
	bool bPrintToScreen; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bPrintToLog; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TextColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Engine.KismetSystemLibrary.OnAssetLoaded__DelegateSignature
struct UKismetSystemLibrary_OnAssetLoaded__DelegateSignature_Params
{
	class UObject* Loaded; // (Parm, ZeroConstructor, IsPlainOldData)
};

// DelegateFunction Engine.KismetSystemLibrary.OnAssetClassLoaded__DelegateSignature
struct UKismetSystemLibrary_OnAssetClassLoaded__DelegateSignature_Params
{
	class UClass* Loaded; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.NotEqual_SoftObjectReference
struct UKismetSystemLibrary_NotEqual_SoftObjectReference_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.NotEqual_SoftClassReference
struct UKismetSystemLibrary_NotEqual_SoftClassReference_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.NotEqual_PrimaryAssetType
struct UKismetSystemLibrary_NotEqual_PrimaryAssetType_Params
{
	struct FPrimaryAssetType A; // (Parm)
	struct FPrimaryAssetType B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.NotEqual_PrimaryAssetId
struct UKismetSystemLibrary_NotEqual_PrimaryAssetId_Params
{
	struct FPrimaryAssetId A; // (Parm)
	struct FPrimaryAssetId B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.MoveComponentTo
struct UKismetSystemLibrary_MoveComponentTo_Params
{
	class USceneComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector TargetRelativeLocation; // (Parm, IsPlainOldData)
	struct FRotator TargetRelativeRotation; // (Parm, IsPlainOldData)
	bool bEaseOut; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEaseIn; // (Parm, ZeroConstructor, IsPlainOldData)
	float OverTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bForceShortestRotationPath; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EMoveComponentAction> MoveAction; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.KismetSystemLibrary.MakeSoftObjectPath
struct UKismetSystemLibrary_MakeSoftObjectPath_Params
{
	struct FString PathString; // (Parm, ZeroConstructor)
	struct FSoftObjectPath ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.MakeLiteralText
struct UKismetSystemLibrary_MakeLiteralText_Params
{
	struct FText Value; // (Parm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.MakeLiteralString
struct UKismetSystemLibrary_MakeLiteralString_Params
{
	struct FString Value; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.MakeLiteralName
struct UKismetSystemLibrary_MakeLiteralName_Params
{
	struct FName Value; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.MakeLiteralInt
struct UKismetSystemLibrary_MakeLiteralInt_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.MakeLiteralFloat
struct UKismetSystemLibrary_MakeLiteralFloat_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.MakeLiteralByte
struct UKismetSystemLibrary_MakeLiteralByte_Params
{
	unsigned char Value; // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.MakeLiteralBool
struct UKismetSystemLibrary_MakeLiteralBool_Params
{
	bool Value; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LoadInterstitialAd
struct UKismetSystemLibrary_LoadInterstitialAd_Params
{
	int AdIdIndex; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LoadAssetClass
struct UKismetSystemLibrary_LoadAssetClass_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate OnLoaded; // (Parm, ZeroConstructor)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.KismetSystemLibrary.LoadAsset
struct UKismetSystemLibrary_LoadAsset_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FScriptDelegate OnLoaded; // (Parm, ZeroConstructor)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.KismetSystemLibrary.LineTraceSingleForObjects
struct UKismetSystemLibrary_LineTraceSingleForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LineTraceSingleByProfile
struct UKismetSystemLibrary_LineTraceSingleByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LineTraceSingle
struct UKismetSystemLibrary_LineTraceSingle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LineTraceMultiForObjects
struct UKismetSystemLibrary_LineTraceMultiForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LineTraceMultiByProfile
struct UKismetSystemLibrary_LineTraceMultiByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LineTraceMulti
struct UKismetSystemLibrary_LineTraceMulti_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.LaunchUrl
struct UKismetSystemLibrary_LaunchUrl_Params
{
	struct FString URL; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.K2_UnPauseTimerHandle
struct UKismetSystemLibrary_K2_UnPauseTimerHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
};

// Function Engine.KismetSystemLibrary.K2_UnPauseTimerDelegate
struct UKismetSystemLibrary_K2_UnPauseTimerDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.K2_UnPauseTimer
struct UKismetSystemLibrary_K2_UnPauseTimer_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.K2_TimerExistsHandle
struct UKismetSystemLibrary_K2_TimerExistsHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_TimerExistsDelegate
struct UKismetSystemLibrary_K2_TimerExistsDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_TimerExists
struct UKismetSystemLibrary_K2_TimerExists_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_SetTimerDelegate
struct UKismetSystemLibrary_K2_SetTimerDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.K2_SetTimer
struct UKismetSystemLibrary_K2_SetTimer_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
	float Time; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bLooping; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.K2_PauseTimerHandle
struct UKismetSystemLibrary_K2_PauseTimerHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
};

// Function Engine.KismetSystemLibrary.K2_PauseTimerDelegate
struct UKismetSystemLibrary_K2_PauseTimerDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.K2_PauseTimer
struct UKismetSystemLibrary_K2_PauseTimer_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.K2_IsValidTimerHandle
struct UKismetSystemLibrary_K2_IsValidTimerHandle_Params
{
	struct FTimerHandle Handle; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_IsTimerPausedHandle
struct UKismetSystemLibrary_K2_IsTimerPausedHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_IsTimerPausedDelegate
struct UKismetSystemLibrary_K2_IsTimerPausedDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_IsTimerPaused
struct UKismetSystemLibrary_K2_IsTimerPaused_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_IsTimerActiveHandle
struct UKismetSystemLibrary_K2_IsTimerActiveHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_IsTimerActiveDelegate
struct UKismetSystemLibrary_K2_IsTimerActiveDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_IsTimerActive
struct UKismetSystemLibrary_K2_IsTimerActive_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_InvalidateTimerHandle
struct UKismetSystemLibrary_K2_InvalidateTimerHandle_Params
{
	struct FTimerHandle Handle; // (Parm, OutParm, ReferenceParm)
	struct FTimerHandle ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.K2_GetTimerRemainingTimeHandle
struct UKismetSystemLibrary_K2_GetTimerRemainingTimeHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_GetTimerRemainingTimeDelegate
struct UKismetSystemLibrary_K2_GetTimerRemainingTimeDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_GetTimerRemainingTime
struct UKismetSystemLibrary_K2_GetTimerRemainingTime_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_GetTimerElapsedTimeHandle
struct UKismetSystemLibrary_K2_GetTimerElapsedTimeHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_GetTimerElapsedTimeDelegate
struct UKismetSystemLibrary_K2_GetTimerElapsedTimeDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_GetTimerElapsedTime
struct UKismetSystemLibrary_K2_GetTimerElapsedTime_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.K2_ClearTimerHandle
struct UKismetSystemLibrary_K2_ClearTimerHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm)
};

// Function Engine.KismetSystemLibrary.K2_ClearTimerDelegate
struct UKismetSystemLibrary_K2_ClearTimerDelegate_Params
{
	struct FScriptDelegate Delegate; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.K2_ClearTimer
struct UKismetSystemLibrary_K2_ClearTimer_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString FunctionName; // (Parm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.K2_ClearAndInvalidateTimerHandle
struct UKismetSystemLibrary_K2_ClearAndInvalidateTimerHandle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTimerHandle Handle; // (Parm, OutParm, ReferenceParm)
};

// Function Engine.KismetSystemLibrary.IsValidSoftObjectReference
struct UKismetSystemLibrary_IsValidSoftObjectReference_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsValidSoftClassReference
struct UKismetSystemLibrary_IsValidSoftClassReference_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsValidPrimaryAssetType
struct UKismetSystemLibrary_IsValidPrimaryAssetType_Params
{
	struct FPrimaryAssetType PrimaryAssetType; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsValidPrimaryAssetId
struct UKismetSystemLibrary_IsValidPrimaryAssetId_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsValidClass
struct UKismetSystemLibrary_IsValidClass_Params
{
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsValid
struct UKismetSystemLibrary_IsValid_Params
{
	class UObject* Object; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsStandalone
struct UKismetSystemLibrary_IsStandalone_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsServer
struct UKismetSystemLibrary_IsServer_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsPackagedForDistribution
struct UKismetSystemLibrary_IsPackagedForDistribution_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsLoggedIn
struct UKismetSystemLibrary_IsLoggedIn_Params
{
	class APlayerController* SpecificPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsInterstitialAdRequested
struct UKismetSystemLibrary_IsInterstitialAdRequested_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsInterstitialAdAvailable
struct UKismetSystemLibrary_IsInterstitialAdAvailable_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsDedicatedServer
struct UKismetSystemLibrary_IsDedicatedServer_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.IsControllerAssignedToGamepad
struct UKismetSystemLibrary_IsControllerAssignedToGamepad_Params
{
	int ControllerId; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.HideAdBanner
struct UKismetSystemLibrary_HideAdBanner_Params
{
};

// Function Engine.KismetSystemLibrary.GetVolumeButtonsHandledBySystem
struct UKismetSystemLibrary_GetVolumeButtonsHandledBySystem_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetUxCode
struct UKismetSystemLibrary_GetUxCode_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetUniqueDeviceId
struct UKismetSystemLibrary_GetUniqueDeviceId_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetSupportedFullscreenResolutions
struct UKismetSystemLibrary_GetSupportedFullscreenResolutions_Params
{
	TArray<struct FIntPoint> Resolutions; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetSoftObjectReferenceFromPrimaryAssetId
struct UKismetSystemLibrary_GetSoftObjectReferenceFromPrimaryAssetId_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
};

// Function Engine.KismetSystemLibrary.GetSoftClassReferenceFromPrimaryAssetId
struct UKismetSystemLibrary_GetSoftClassReferenceFromPrimaryAssetId_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
};

// Function Engine.KismetSystemLibrary.GetRenderingMaterialQualityLevel
struct UKismetSystemLibrary_GetRenderingMaterialQualityLevel_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetRenderingDetailMode
struct UKismetSystemLibrary_GetRenderingDetailMode_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetRedirectedPackageName
struct UKismetSystemLibrary_GetRedirectedPackageName_Params
{
	struct FString Path; // (Parm, ZeroConstructor)
	bool bInFilePath; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetRedirectedFilePathString
struct UKismetSystemLibrary_GetRedirectedFilePathString_Params
{
	struct FString Path; // (Parm, ZeroConstructor)
	bool bInFilePath; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bReplaceExt; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetRedirectedAssetPathString
struct UKismetSystemLibrary_GetRedirectedAssetPathString_Params
{
	struct FString Path; // (Parm, ZeroConstructor)
	bool bInFilePath; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetPrimaryAssetsWithBundleState
struct UKismetSystemLibrary_GetPrimaryAssetsWithBundleState_Params
{
	TArray<struct FName> RequiredBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FName> ExcludedBundles; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FPrimaryAssetType> ValidTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bForceCurrentState; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FPrimaryAssetId> OutPrimaryAssetIdList; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.GetPrimaryAssetIdList
struct UKismetSystemLibrary_GetPrimaryAssetIdList_Params
{
	struct FPrimaryAssetType PrimaryAssetType; // (Parm)
	TArray<struct FPrimaryAssetId> OutPrimaryAssetIdList; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.GetPrimaryAssetIdFromSoftObjectReference
struct UKismetSystemLibrary_GetPrimaryAssetIdFromSoftObjectReference_Params
{
	struct FPrimaryAssetId ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetPrimaryAssetIdFromSoftClassReference
struct UKismetSystemLibrary_GetPrimaryAssetIdFromSoftClassReference_Params
{
	struct FPrimaryAssetId ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetPrimaryAssetIdFromObject
struct UKismetSystemLibrary_GetPrimaryAssetIdFromObject_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FPrimaryAssetId ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetPrimaryAssetIdFromClass
struct UKismetSystemLibrary_GetPrimaryAssetIdFromClass_Params
{
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FPrimaryAssetId ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetPreferredLanguages
struct UKismetSystemLibrary_GetPreferredLanguages_Params
{
	TArray<struct FString> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetPlatformUserName
struct UKismetSystemLibrary_GetPlatformUserName_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetPathName
struct UKismetSystemLibrary_GetPathName_Params
{
	class UObject* Object; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetObjectName
struct UKismetSystemLibrary_GetObjectName_Params
{
	class UObject* Object; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetObjectFromPrimaryAssetId
struct UKismetSystemLibrary_GetObjectFromPrimaryAssetId_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
	class UObject* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetMinYResolutionForUI
struct UKismetSystemLibrary_GetMinYResolutionForUI_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetMinYResolutionFor3DView
struct UKismetSystemLibrary_GetMinYResolutionFor3DView_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetLocalCurrencySymbol
struct UKismetSystemLibrary_GetLocalCurrencySymbol_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetLocalCurrencyCode
struct UKismetSystemLibrary_GetLocalCurrencyCode_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetGameTimeInSeconds
struct UKismetSystemLibrary_GetGameTimeInSeconds_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetGameName
struct UKismetSystemLibrary_GetGameName_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetGameBundleId
struct UKismetSystemLibrary_GetGameBundleId_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetEngineVersion
struct UKismetSystemLibrary_GetEngineVersion_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetDisplayName
struct UKismetSystemLibrary_GetDisplayName_Params
{
	class UObject* Object; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetDeviceId
struct UKismetSystemLibrary_GetDeviceId_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetDefaultLocale
struct UKismetSystemLibrary_GetDefaultLocale_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetDefaultLanguage
struct UKismetSystemLibrary_GetDefaultLanguage_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetCurrentBundleState
struct UKismetSystemLibrary_GetCurrentBundleState_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
	bool bForceCurrentState; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FName> OutBundles; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetConvenientWindowedResolutions
struct UKismetSystemLibrary_GetConvenientWindowedResolutions_Params
{
	TArray<struct FIntPoint> Resolutions; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetConsoleVariableValue
struct UKismetSystemLibrary_GetConsoleVariableValue_Params
{
	struct FString VariableName; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetConsoleVariableIntValue
struct UKismetSystemLibrary_GetConsoleVariableIntValue_Params
{
	struct FString VariableName; // (Parm, ZeroConstructor)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetConsoleVariableFloatValue
struct UKismetSystemLibrary_GetConsoleVariableFloatValue_Params
{
	struct FString VariableName; // (Parm, ZeroConstructor)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetConsoleVariableBoolValue
struct UKismetSystemLibrary_GetConsoleVariableBoolValue_Params
{
	struct FString VariableName; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetComponentBounds
struct UKismetSystemLibrary_GetComponentBounds_Params
{
	class USceneComponent* Component; // (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector Origin; // (Parm, OutParm, IsPlainOldData)
	struct FVector BoxExtent; // (Parm, OutParm, IsPlainOldData)
	float SphereRadius; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetCommandLine
struct UKismetSystemLibrary_GetCommandLine_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetClassPathName
struct UKismetSystemLibrary_GetClassPathName_Params
{
	class UObject* Object; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetClassName
struct UKismetSystemLibrary_GetClassName_Params
{
	class UObject* Object; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetClassFromPrimaryAssetId
struct UKismetSystemLibrary_GetClassFromPrimaryAssetId_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
	class UClass* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetClassDisplayName
struct UKismetSystemLibrary_GetClassDisplayName_Params
{
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetBUoCode
struct UKismetSystemLibrary_GetBUoCode_Params
{
	TArray<struct FString> SxArray; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.GetAUxCode
struct UKismetSystemLibrary_GetAUxCode_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.GetAUoCode
struct UKismetSystemLibrary_GetAUoCode_Params
{
	TArray<struct FString> SxArray; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.GetAdIDCount
struct UKismetSystemLibrary_GetAdIDCount_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.GetActorListFromComponentList
struct UKismetSystemLibrary_GetActorListFromComponentList_Params
{
	TArray<class UPrimitiveComponent*> ComponentList; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ActorClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> OutActorList; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.GetActorBounds
struct UKismetSystemLibrary_GetActorBounds_Params
{
	class AActor* Actor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (Parm, OutParm, IsPlainOldData)
	struct FVector BoxExtent; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ForceCloseAdBanner
struct UKismetSystemLibrary_ForceCloseAdBanner_Params
{
};

// Function Engine.KismetSystemLibrary.FlushPersistentDebugLines
struct UKismetSystemLibrary_FlushPersistentDebugLines_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.FlushDebugStrings
struct UKismetSystemLibrary_FlushDebugStrings_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ExecuteConsoleCommand
struct UKismetSystemLibrary_ExecuteConsoleCommand_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Command; // (Parm, ZeroConstructor)
	class APlayerController* SpecificPlayer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.EqualEqual_SoftObjectReference
struct UKismetSystemLibrary_EqualEqual_SoftObjectReference_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.EqualEqual_SoftClassReference
struct UKismetSystemLibrary_EqualEqual_SoftClassReference_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.EqualEqual_PrimaryAssetType
struct UKismetSystemLibrary_EqualEqual_PrimaryAssetType_Params
{
	struct FPrimaryAssetType A; // (Parm)
	struct FPrimaryAssetType B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.EqualEqual_PrimaryAssetId
struct UKismetSystemLibrary_EqualEqual_PrimaryAssetId_Params
{
	struct FPrimaryAssetId A; // (Parm)
	struct FPrimaryAssetId B; // (Parm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugString
struct UKismetSystemLibrary_DrawDebugString_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector TextLocation; // (ConstParm, Parm, IsPlainOldData)
	struct FString Text; // (Parm, ZeroConstructor)
	class AActor* TestBaseActor; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TextColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugSphere
struct UKismetSystemLibrary_DrawDebugSphere_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Center; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	int Segments; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugPoint
struct UKismetSystemLibrary_DrawDebugPoint_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Position; // (ConstParm, Parm, IsPlainOldData)
	float Size; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor PointColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugPlane
struct UKismetSystemLibrary_DrawDebugPlane_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FPlane PlaneCoordinates; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector Location; // (ConstParm, Parm, IsPlainOldData)
	float Size; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor PlaneColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugLine
struct UKismetSystemLibrary_DrawDebugLine_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector LineStart; // (ConstParm, Parm, IsPlainOldData)
	struct FVector LineEnd; // (ConstParm, Parm, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugFrustum
struct UKismetSystemLibrary_DrawDebugFrustum_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform FrustumTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FLinearColor FrustumColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugFloatHistoryTransform
struct UKismetSystemLibrary_DrawDebugFloatHistoryTransform_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDebugFloatHistory FloatHistory; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FTransform DrawTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector2D DrawSize; // (Parm, IsPlainOldData)
	struct FLinearColor DrawColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugFloatHistoryLocation
struct UKismetSystemLibrary_DrawDebugFloatHistoryLocation_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDebugFloatHistory FloatHistory; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FVector DrawLocation; // (Parm, IsPlainOldData)
	struct FVector2D DrawSize; // (Parm, IsPlainOldData)
	struct FLinearColor DrawColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugCylinder
struct UKismetSystemLibrary_DrawDebugCylinder_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	int Segments; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugCoordinateSystem
struct UKismetSystemLibrary_DrawDebugCoordinateSystem_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector AxisLoc; // (ConstParm, Parm, IsPlainOldData)
	struct FRotator AxisRot; // (ConstParm, Parm, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugConeInDegrees
struct UKismetSystemLibrary_DrawDebugConeInDegrees_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, IsPlainOldData)
	struct FVector Direction; // (ConstParm, Parm, IsPlainOldData)
	float Length; // (Parm, ZeroConstructor, IsPlainOldData)
	float AngleWidth; // (Parm, ZeroConstructor, IsPlainOldData)
	float AngleHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumSides; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugCone
struct UKismetSystemLibrary_DrawDebugCone_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Origin; // (ConstParm, Parm, IsPlainOldData)
	struct FVector Direction; // (ConstParm, Parm, IsPlainOldData)
	float Length; // (Parm, ZeroConstructor, IsPlainOldData)
	float AngleWidth; // (Parm, ZeroConstructor, IsPlainOldData)
	float AngleHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumSides; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugCircle
struct UKismetSystemLibrary_DrawDebugCircle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Center; // (Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumSegments; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector YAxis; // (Parm, IsPlainOldData)
	struct FVector ZAxis; // (Parm, IsPlainOldData)
	bool bDrawAxis; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugCapsule
struct UKismetSystemLibrary_DrawDebugCapsule_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Center; // (ConstParm, Parm, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator Rotation; // (ConstParm, Parm, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugCamera
struct UKismetSystemLibrary_DrawDebugCamera_Params
{
	class ACameraActor* CameraActor; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor CameraColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugBox
struct UKismetSystemLibrary_DrawDebugBox_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Center; // (ConstParm, Parm, IsPlainOldData)
	struct FVector Extent; // (Parm, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (ConstParm, Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DrawDebugArrow
struct UKismetSystemLibrary_DrawDebugArrow_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector LineStart; // (ConstParm, Parm, IsPlainOldData)
	struct FVector LineEnd; // (ConstParm, Parm, IsPlainOldData)
	float ArrowSize; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor LineColor; // (Parm, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	float Thickness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DoesImplementInterface
struct UKismetSystemLibrary_DoesImplementInterface_Params
{
	class UObject* TestObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Interface; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.DelayForFrames
struct UKismetSystemLibrary_DelayForFrames_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	int NumFrames; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.KismetSystemLibrary.Delay
struct UKismetSystemLibrary_Delay_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	float Duration; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLatentActionInfo LatentInfo; // (Parm)
};

// Function Engine.KismetSystemLibrary.CreateCopyForUndoBuffer
struct UKismetSystemLibrary_CreateCopyForUndoBuffer_Params
{
	class UObject* ObjectToModify; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.Conv_SoftObjectReferenceToString
struct UKismetSystemLibrary_Conv_SoftObjectReferenceToString_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.Conv_SoftObjectReferenceToObject
struct UKismetSystemLibrary_Conv_SoftObjectReferenceToObject_Params
{
	class UObject* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.Conv_SoftClassReferenceToString
struct UKismetSystemLibrary_Conv_SoftClassReferenceToString_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.Conv_SoftClassReferenceToClass
struct UKismetSystemLibrary_Conv_SoftClassReferenceToClass_Params
{
	class UClass* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.Conv_PrimaryAssetTypeToString
struct UKismetSystemLibrary_Conv_PrimaryAssetTypeToString_Params
{
	struct FPrimaryAssetType PrimaryAssetType; // (Parm)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.Conv_PrimaryAssetIdToString
struct UKismetSystemLibrary_Conv_PrimaryAssetIdToString_Params
{
	struct FPrimaryAssetId PrimaryAssetId; // (Parm)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetSystemLibrary.Conv_ObjectToSoftObjectReference
struct UKismetSystemLibrary_Conv_ObjectToSoftObjectReference_Params
{
	class UObject* Object; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.Conv_InterfaceToObject
struct UKismetSystemLibrary_Conv_InterfaceToObject_Params
{
	TScriptInterface<class UInterface> Interface; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	class UObject* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.Conv_ClassToSoftClassReference
struct UKismetSystemLibrary_Conv_ClassToSoftClassReference_Params
{
	class UClass* Class; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ControlScreensaver
struct UKismetSystemLibrary_ControlScreensaver_Params
{
	bool bAllowScreenSaver; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ComponentOverlapComponents
struct UKismetSystemLibrary_ComponentOverlapComponents_Params
{
	class UPrimitiveComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FTransform ComponentTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ComponentClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class UPrimitiveComponent*> OutComponents; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.ComponentOverlapActors
struct UKismetSystemLibrary_ComponentOverlapActors_Params
{
	class UPrimitiveComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FTransform ComponentTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ActorClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CollectGarbage
struct UKismetSystemLibrary_CollectGarbage_Params
{
};

// Function Engine.KismetSystemLibrary.ClearPkgRedirectMap
struct UKismetSystemLibrary_ClearPkgRedirectMap_Params
{
};

// Function Engine.KismetSystemLibrary.CapsuleTraceSingleForObjects
struct UKismetSystemLibrary_CapsuleTraceSingleForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CapsuleTraceSingleByProfile
struct UKismetSystemLibrary_CapsuleTraceSingleByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CapsuleTraceSingle
struct UKismetSystemLibrary_CapsuleTraceSingle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CapsuleTraceMultiForObjects
struct UKismetSystemLibrary_CapsuleTraceMultiForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CapsuleTraceMultiByProfile
struct UKismetSystemLibrary_CapsuleTraceMultiByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CapsuleTraceMulti
struct UKismetSystemLibrary_CapsuleTraceMulti_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CapsuleOverlapComponents
struct UKismetSystemLibrary_CapsuleOverlapComponents_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector CapsulePos; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ComponentClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class UPrimitiveComponent*> OutComponents; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CapsuleOverlapActors
struct UKismetSystemLibrary_CapsuleOverlapActors_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector CapsulePos; // (ConstParm, Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ActorClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.CanLaunchURL
struct UKismetSystemLibrary_CanLaunchURL_Params
{
	struct FString URL; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BreakSoftObjectPath
struct UKismetSystemLibrary_BreakSoftObjectPath_Params
{
	struct FSoftObjectPath InSoftObjectPath; // (Parm)
	struct FString PathString; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.KismetSystemLibrary.BoxTraceSingleForObjects
struct UKismetSystemLibrary_BoxTraceSingleForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FVector HalfSize; // (ConstParm, Parm, IsPlainOldData)
	struct FRotator Orientation; // (ConstParm, Parm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BoxTraceSingleByProfile
struct UKismetSystemLibrary_BoxTraceSingleByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FVector HalfSize; // (ConstParm, Parm, IsPlainOldData)
	struct FRotator Orientation; // (ConstParm, Parm, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BoxTraceSingle
struct UKismetSystemLibrary_BoxTraceSingle_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FVector HalfSize; // (ConstParm, Parm, IsPlainOldData)
	struct FRotator Orientation; // (ConstParm, Parm, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult OutHit; // (Parm, OutParm, IsPlainOldData)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BoxTraceMultiForObjects
struct UKismetSystemLibrary_BoxTraceMultiForObjects_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FVector HalfSize; // (ConstParm, Parm, IsPlainOldData)
	struct FRotator Orientation; // (ConstParm, Parm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BoxTraceMultiByProfile
struct UKismetSystemLibrary_BoxTraceMultiByProfile_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FVector HalfSize; // (Parm, IsPlainOldData)
	struct FRotator Orientation; // (ConstParm, Parm, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BoxTraceMulti
struct UKismetSystemLibrary_BoxTraceMulti_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Start; // (ConstParm, Parm, IsPlainOldData)
	struct FVector End; // (ConstParm, Parm, IsPlainOldData)
	struct FVector HalfSize; // (Parm, IsPlainOldData)
	struct FRotator Orientation; // (ConstParm, Parm, IsPlainOldData)
	TEnumAsByte<enum ETraceTypeQuery> TraceChannel; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bTraceComplex; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum EDrawDebugTrace> DrawDebugType; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult> OutHits; // (Parm, OutParm, ZeroConstructor)
	bool bIgnoreSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor TraceColor; // (Parm, IsPlainOldData)
	struct FLinearColor TraceHitColor; // (Parm, IsPlainOldData)
	float DrawTime; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BoxOverlapComponents
struct UKismetSystemLibrary_BoxOverlapComponents_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector BoxPos; // (ConstParm, Parm, IsPlainOldData)
	struct FVector Extent; // (Parm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ComponentClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class UPrimitiveComponent*> OutComponents; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.BoxOverlapActors
struct UKismetSystemLibrary_BoxOverlapActors_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector BoxPos; // (ConstParm, Parm, IsPlainOldData)
	struct FVector BoxExtent; // (Parm, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	class UClass* ActorClassFilter; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*> ActorsToIgnore; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<class AActor*> OutActors; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetSystemLibrary.AddFloatHistorySample
struct UKismetSystemLibrary_AddFloatHistorySample_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FDebugFloatHistory FloatHistory; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FDebugFloatHistory ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.TextTrimTrailing
struct UKismetTextLibrary_TextTrimTrailing_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.TextTrimPrecedingAndTrailing
struct UKismetTextLibrary_TextTrimPrecedingAndTrailing_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.TextTrimPreceding
struct UKismetTextLibrary_TextTrimPreceding_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.TextToUpper
struct UKismetTextLibrary_TextToUpper_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.TextToLower
struct UKismetTextLibrary_TextToLower_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.TextIsTransient
struct UKismetTextLibrary_TextIsTransient_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.TextIsFromStringTable
struct UKismetTextLibrary_TextIsFromStringTable_Params
{
	struct FText Text; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.TextIsEmpty
struct UKismetTextLibrary_TextIsEmpty_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.TextIsCultureInvariant
struct UKismetTextLibrary_TextIsCultureInvariant_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.TextFromStringTable
struct UKismetTextLibrary_TextFromStringTable_Params
{
	struct FName TableId; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString Key; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.StringTableIdAndKeyFromText
struct UKismetTextLibrary_StringTableIdAndKeyFromText_Params
{
	struct FText Text; // (Parm)
	struct FName OutTableId; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	struct FString OutKey; // (Parm, OutParm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.NotEqual_TextText
struct UKismetTextLibrary_NotEqual_TextText_Params
{
	struct FText A; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText B; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.NotEqual_IgnoreCase_TextText
struct UKismetTextLibrary_NotEqual_IgnoreCase_TextText_Params
{
	struct FText A; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText B; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.GetEmptyText
struct UKismetTextLibrary_GetEmptyText_Params
{
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Format
struct UKismetTextLibrary_Format_Params
{
	struct FText InPattern; // (Parm)
	TArray<struct FFormatArgumentData> InArgs; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.FindTextInLocalizationTable
struct UKismetTextLibrary_FindTextInLocalizationTable_Params
{
	struct FString Namespace; // (Parm, ZeroConstructor)
	struct FString Key; // (Parm, ZeroConstructor)
	struct FText OutText; // (Parm, OutParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.EqualEqual_TextText
struct UKismetTextLibrary_EqualEqual_TextText_Params
{
	struct FText A; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText B; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.EqualEqual_IgnoreCase_TextText
struct UKismetTextLibrary_EqualEqual_IgnoreCase_TextText_Params
{
	struct FText A; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText B; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.KismetTextLibrary.Conv_VectorToText
struct UKismetTextLibrary_Conv_VectorToText_Params
{
	struct FVector InVec; // (Parm, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_Vector2dToText
struct UKismetTextLibrary_Conv_Vector2dToText_Params
{
	struct FVector2D InVec; // (Parm, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_TransformToText
struct UKismetTextLibrary_Conv_TransformToText_Params
{
	struct FTransform InTrans; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_TextToString
struct UKismetTextLibrary_Conv_TextToString_Params
{
	struct FText InText; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_StringToText
struct UKismetTextLibrary_Conv_StringToText_Params
{
	struct FString inString; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_RotatorToText
struct UKismetTextLibrary_Conv_RotatorToText_Params
{
	struct FRotator InRot; // (Parm, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_ObjectToText
struct UKismetTextLibrary_Conv_ObjectToText_Params
{
	class UObject* InObj; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_NameToText
struct UKismetTextLibrary_Conv_NameToText_Params
{
	struct FName InName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_IntToText
struct UKismetTextLibrary_Conv_IntToText_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseGrouping; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_Int64ToText
struct UKismetTextLibrary_Conv_Int64ToText_Params
{
	int64_t Value; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseGrouping; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_FloatToText
struct UKismetTextLibrary_Conv_FloatToText_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ERoundingMode> RoundingMode; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseGrouping; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_ColorToText
struct UKismetTextLibrary_Conv_ColorToText_Params
{
	struct FLinearColor InColor; // (Parm, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_ByteToText
struct UKismetTextLibrary_Conv_ByteToText_Params
{
	unsigned char Value; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.Conv_BoolToText
struct UKismetTextLibrary_Conv_BoolToText_Params
{
	bool InBool; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsTimeZoneTime_DateTime
struct UKismetTextLibrary_AsTimeZoneTime_DateTime_Params
{
	struct FDateTime InDateTime; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString InTimeZone; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsTimeZoneDateTime_DateTime
struct UKismetTextLibrary_AsTimeZoneDateTime_DateTime_Params
{
	struct FDateTime InDateTime; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString InTimeZone; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsTimeZoneDate_DateTime
struct UKismetTextLibrary_AsTimeZoneDate_DateTime_Params
{
	struct FDateTime InDateTime; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FString InTimeZone; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsTimespan_Timespan
struct UKismetTextLibrary_AsTimespan_Timespan_Params
{
	struct FTimespan InTimespan; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsTime_DateTime
struct UKismetTextLibrary_AsTime_DateTime_Params
{
	struct FDateTime In; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsPercent_Float
struct UKismetTextLibrary_AsPercent_Float_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ERoundingMode> RoundingMode; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseGrouping; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsDateTime_DateTime
struct UKismetTextLibrary_AsDateTime_DateTime_Params
{
	struct FDateTime In; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsDate_DateTime
struct UKismetTextLibrary_AsDate_DateTime_Params
{
	struct FDateTime InDateTime; // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsCurrencyBase
struct UKismetTextLibrary_AsCurrencyBase_Params
{
	int baseValue; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString CurrencyCode; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsCurrency_Integer
struct UKismetTextLibrary_AsCurrency_Integer_Params
{
	int Value; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ERoundingMode> RoundingMode; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseGrouping; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString CurrencyCode; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.KismetTextLibrary.AsCurrency_Float
struct UKismetTextLibrary_AsCurrency_Float_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ERoundingMode> RoundingMode; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bUseGrouping; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumIntegralDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MinimumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	int MaximumFractionalDigits; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString CurrencyCode; // (Parm, ZeroConstructor)
	struct FText ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.LevelStreaming.SetDisableByReason
struct ULevelStreaming_SetDisableByReason_Params
{
	ELevelDisableReason Reason; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDisabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LevelStreaming.IsStreamingStatePending
struct ULevelStreaming_IsStreamingStatePending_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreaming.IsLevelVisible
struct ULevelStreaming_IsLevelVisible_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreaming.IsLevelLoaded
struct ULevelStreaming_IsLevelLoaded_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreaming.HasDisableFlag
struct ULevelStreaming_HasDisableFlag_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreaming.GetWorldAssetPackageFName
struct ULevelStreaming_GetWorldAssetPackageFName_Params
{
	struct FName ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreaming.GetLoadedLevel
struct ULevelStreaming_GetLoadedLevel_Params
{
	class ULevel* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreaming.GetLevelScriptActor
struct ULevelStreaming_GetLevelScriptActor_Params
{
	class ALevelScriptActor* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreaming.CreateInstance
struct ULevelStreaming_CreateInstance_Params
{
	struct FString UniqueInstanceName; // (Parm, ZeroConstructor)
	class ULevelStreaming* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LevelStreamingKismet.LoadLevelInstance
struct ULevelStreamingKismet_LoadLevelInstance_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString LevelName; // (Parm, ZeroConstructor)
	struct FVector Location; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator Rotation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bOutSuccess; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class ULevelStreamingKismet* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LiteComponent.SetIsReplicated
struct ULiteComponent_SetIsReplicated_Params
{
	bool ShouldReplicate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LiteComponent.ReceiveTick
struct ULiteComponent_ReceiveTick_Params
{
	float DeltaSeconds; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.LiteComponent.ReceivePostBeginPlay
struct ULiteComponent_ReceivePostBeginPlay_Params
{
};

// Function Engine.LiteComponent.ReceiveEndPlay
struct ULiteComponent_ReceiveEndPlay_Params
{
};

// Function Engine.LiteComponent.ReceiveBeginPlay
struct ULiteComponent_ReceiveBeginPlay_Params
{
};

// Function Engine.LiteComponent.IsDedicatedServer
struct ULiteComponent_IsDedicatedServer_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LiteComponent.HasAuthority
struct ULiteComponent_HasAuthority_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.LiteComponent.GetOwner
struct ULiteComponent_GetOwner_Params
{
	class UObject* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MaterialBillboardComponent.SetElements
struct UMaterialBillboardComponent_SetElements_Params
{
	TArray<struct FMaterialSpriteElement> NewElements; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function Engine.MaterialBillboardComponent.AddElement
struct UMaterialBillboardComponent_AddElement_Params
{
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* DistanceToOpacityCurve; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bSizeIsInScreenSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	float BaseSizeX; // (Parm, ZeroConstructor, IsPlainOldData)
	float BaseSizeY; // (Parm, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* DistanceToSizeCurve; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.SetVectorParameterValue
struct UMaterialInstanceDynamic_SetVectorParameterValue_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor Value; // (Parm, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.SetTextureParameterValue
struct UMaterialInstanceDynamic_SetTextureParameterValue_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.SetSparseVolumeTextureParameterValue
struct UMaterialInstanceDynamic_SetSparseVolumeTextureParameterValue_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class USparseVolumeTexture* Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.SetScalarParameterValue
struct UMaterialInstanceDynamic_SetScalarParameterValue_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.K2_InterpolateMaterialInstanceParams
struct UMaterialInstanceDynamic_K2_InterpolateMaterialInstanceParams_Params
{
	class UMaterialInstance* SourceA; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInstance* SourceB; // (Parm, ZeroConstructor, IsPlainOldData)
	float Alpha; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.K2_GetVectorParameterValue
struct UMaterialInstanceDynamic_K2_GetVectorParameterValue_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.K2_GetTextureParameterValue
struct UMaterialInstanceDynamic_K2_GetTextureParameterValue_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTexture* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.K2_GetScalarParameterValue
struct UMaterialInstanceDynamic_K2_GetScalarParameterValue_Params
{
	struct FName ParameterName; // (Parm, ZeroConstructor, IsPlainOldData)
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.K2_CopyMaterialInstanceParameters
struct UMaterialInstanceDynamic_K2_CopyMaterialInstanceParameters_Params
{
	class UMaterialInterface* Source; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.CopyParameterOverrides
struct UMaterialInstanceDynamic_CopyParameterOverrides_Params
{
	class UMaterialInstance* MaterialInstance; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MaterialInstanceDynamic.CopyInterpParameters
struct UMaterialInstanceDynamic_CopyInterpParameters_Params
{
	class UMaterialInstance* Source; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MatineeActor.Stop
struct AMatineeActor_Stop_Params
{
};

// Function Engine.MatineeActor.SetPosition
struct AMatineeActor_SetPosition_Params
{
	float NewPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bJump; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MatineeActor.SetLoopingState
struct AMatineeActor_SetLoopingState_Params
{
	bool bNewLooping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MatineeActor.Reverse
struct AMatineeActor_Reverse_Params
{
};

// Function Engine.MatineeActor.Play
struct AMatineeActor_Play_Params
{
};

// Function Engine.MatineeActor.Pause
struct AMatineeActor_Pause_Params
{
};

// Function Engine.MatineeActor.EnableGroupByName
struct AMatineeActor_EnableGroupByName_Params
{
	struct FString GroupName; // (Parm, ZeroConstructor)
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MatineeActor.ChangePlaybackDirection
struct AMatineeActor_ChangePlaybackDirection_Params
{
};

// Function Engine.MeshVertexPainterKismetLibrary.RemovePaintedVertices
struct UMeshVertexPainterKismetLibrary_RemovePaintedVertices_Params
{
	class UStaticMeshComponent* StaticMeshComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.MeshVertexPainterKismetLibrary.PaintVerticesSingleColor
struct UMeshVertexPainterKismetLibrary_PaintVerticesSingleColor_Params
{
	class UStaticMeshComponent* StaticMeshComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FLinearColor FillColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	bool bConvertToSRGB; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.MeshVertexPainterKismetLibrary.PaintVerticesLerpAlongAxis
struct UMeshVertexPainterKismetLibrary_PaintVerticesLerpAlongAxis_Params
{
	class UStaticMeshComponent* StaticMeshComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FLinearColor StartColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FLinearColor EndColor; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	EVertexPaintAxis Axis; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bConvertToSRGB; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationPath.IsValid
struct UNavigationPath_IsValid_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationPath.IsStringPulled
struct UNavigationPath_IsStringPulled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationPath.IsPartial
struct UNavigationPath_IsPartial_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationPath.GetPathLength
struct UNavigationPath_GetPathLength_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationPath.GetPathCost
struct UNavigationPath_GetPathCost_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NavigationPath.GetDebugString
struct UNavigationPath_GetDebugString_Params
{
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.NavigationPath.EnableRecalculationOnInvalidation
struct UNavigationPath_EnableRecalculationOnInvalidation_Params
{
	TEnumAsByte<enum ENavigationOptionFlag> DoRecalculation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavigationPath.EnableDebugDrawing
struct UNavigationPath_EnableDebugDrawing_Params
{
	bool bShouldDrawDebugData; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FLinearColor PathColor; // (Parm, IsPlainOldData)
};

// Function Engine.NavRelevantComponent.SetNavigationRelevancy
struct UNavRelevantComponent_SetNavigationRelevancy_Params
{
	bool bRelevant; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavModifierComponent.SetAreaClass
struct UNavModifierComponent_SetAreaClass_Params
{
	class UClass* NewAreaClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NavModifierVolume.SetAreaClass
struct ANavModifierVolume_SetAreaClass_Params
{
	class UClass* NewAreaClass; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NetObjectPathNameMappingManager.OnMappingTableAsyncLoad
struct UNetObjectPathNameMappingManager_OnMappingTableAsyncLoad_Params
{
	struct FSoftObjectPath MappingTableObj; // (Parm)
};

// Function Engine.NewObjectPoolSystem.SwitcherCheckByClassType
struct UNewObjectPoolSystem_SwitcherCheckByClassType_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.SwitcherCheck
struct UNewObjectPoolSystem_SwitcherCheck_Params
{
	struct FObjectPoolConfig PoolConfig; // (Parm, OutParm, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.RemoveFence
struct UNewObjectPoolSystem_RemoveFence_Params
{
	EObjectPoolFenceType FenceType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName FenceName; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.Remove
struct UNewObjectPoolSystem_Remove_Params
{
};

// Function Engine.NewObjectPoolSystem.Recycle
struct UNewObjectPoolSystem_Recycle_Params
{
	class UObject* RecycleObject; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.IsAvailableChildClass
struct UNewObjectPoolSystem_IsAvailableChildClass_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.GetInited
struct UNewObjectPoolSystem_GetInited_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.ExistingFences
struct UNewObjectPoolSystem_ExistingFences_Params
{
	EObjectPoolFenceType FenceType; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.CreateFence
struct UNewObjectPoolSystem_CreateFence_Params
{
	EObjectPoolFenceType FenceType; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName FenceName; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.ClearAll
struct UNewObjectPoolSystem_ClearAll_Params
{
	bool CollectGarbage; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.Clear
struct UNewObjectPoolSystem_Clear_Params
{
	bool CollectGarbage; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.NewObjectPoolSystem.AddDefault
struct UNewObjectPoolSystem_AddDefault_Params
{
};

// Function Engine.NewObjectPoolSystem.Add
struct UNewObjectPoolSystem_Add_Params
{
	struct FObjectPoolConfig PoolConfig; // (Parm, OutParm, ReferenceParm)
};

// Function Engine.ObjectPoolInterface.UseUnLimitObjectPool
struct UObjectPoolInterface_UseUnLimitObjectPool_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ObjectPoolInterface.ResetPropsNormally
struct UObjectPoolInterface_ResetPropsNormally_Params
{
	class UObject* CDO; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ObjectPoolInterface.ReceiveOnRespawned
struct UObjectPoolInterface_ReceiveOnRespawned_Params
{
};

// Function Engine.ObjectPoolInterface.ReceiveOnRecycled
struct UObjectPoolInterface_ReceiveOnRecycled_Params
{
};

// Function Engine.ObjectPoolInterface.ReceiveOnNetRespawned
struct UObjectPoolInterface_ReceiveOnNetRespawned_Params
{
};

// Function Engine.ObjectPoolInterface.OnRespawned
struct UObjectPoolInterface_OnRespawned_Params
{
};

// Function Engine.ObjectPoolInterface.OnRecycled
struct UObjectPoolInterface_OnRecycled_Params
{
};

// Function Engine.ObjectPoolInterface.OnNetRespawned
struct UObjectPoolInterface_OnNetRespawned_Params
{
};

// Function Engine.ObjectPoolInterface.GetUnLimitObjectPoolSize
struct UObjectPoolInterface_GetUnLimitObjectPoolSize_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ObjectPoolInterface.GetUnLimitObjectPoolLifePeriodTime
struct UObjectPoolInterface_GetUnLimitObjectPoolLifePeriodTime_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ObjectPoolInterface.GetDynamicRecyclePoolSize
struct UObjectPoolInterface_GetDynamicRecyclePoolSize_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ObjectPoolInterface.EnableDynamicRecycle
struct UObjectPoolInterface_EnableDynamicRecycle_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ObjectPoolInterface.CheckIsRespawned
struct UObjectPoolInterface_CheckIsRespawned_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ObjectPoolInterface.CheckIsRecycled
struct UObjectPoolInterface_CheckIsRecycled_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.OceanFFTComponent.Update
struct UOceanFFTComponent_Update_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.OnlineBlueprintCallProxyBase.Activate
struct UOnlineBlueprintCallProxyBase_Activate_Params
{
};

// Function Engine.ParallelWorldSubsystem.AddWorlds
struct UParallelWorldSubsystem_AddWorlds_Params
{
	TArray<int> InWorldIds; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystem.GetBounds
struct UParticleSystem_GetBounds_Params
{
	struct FBoxSphereBounds ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystem.GetBoundingBox
struct UParticleSystem_GetBoundingBox_Params
{
	struct FBox ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.ParticleSystem.ContainsEmitterType
struct UParticleSystem_ContainsEmitterType_Params
{
	class UClass* TypeData; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PawnNoiseEmitterComponent.MakeNoise
struct UPawnNoiseEmitterComponent_MakeNoise_Params
{
	class AActor* NoiseMaker; // (Parm, ZeroConstructor, IsPlainOldData)
	float Loudness; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector NoiseLocation; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicalAnimationComponent.SetStrengthMultiplyer
struct UPhysicalAnimationComponent_SetStrengthMultiplyer_Params
{
	float InStrengthMultiplyer; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicalAnimationComponent.SetSkeletalMeshComponent
struct UPhysicalAnimationComponent_SetSkeletalMeshComponent_Params
{
	class USkeletalMeshComponent* InSkeletalMeshComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.PhysicalAnimationComponent.GetBodyTargetTransform
struct UPhysicalAnimationComponent_GetBodyTargetTransform_Params
{
	struct FName BodyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicalAnimationComponent.ApplyPhysicalAnimationSettingsBelow
struct UPhysicalAnimationComponent_ApplyPhysicalAnimationSettingsBelow_Params
{
	struct FName BodyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FPhysicalAnimationData PhysicalAnimationData; // (ConstParm, Parm, OutParm, ReferenceParm)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicalAnimationComponent.ApplyPhysicalAnimationSettings
struct UPhysicalAnimationComponent_ApplyPhysicalAnimationSettings_Params
{
	struct FName BodyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FPhysicalAnimationData PhysicalAnimationData; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.PhysicalAnimationComponent.ApplyPhysicalAnimationProfileBelow
struct UPhysicalAnimationComponent_ApplyPhysicalAnimationProfileBelow_Params
{
	struct FName BodyName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName ProfileName; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bIncludeSelf; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bClearNotFound; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetOrientationDriveTwistAndSwing
struct UPhysicsConstraintComponent_SetOrientationDriveTwistAndSwing_Params
{
	bool bEnableTwistDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableSwingDrive; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetOrientationDriveSLERP
struct UPhysicsConstraintComponent_SetOrientationDriveSLERP_Params
{
	bool bEnableSLERP; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearZLimit
struct UPhysicsConstraintComponent_SetLinearZLimit_Params
{
	TEnumAsByte<enum ELinearConstraintMotion> ConstraintType; // (Parm, ZeroConstructor, IsPlainOldData)
	float LimitSize; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearYLimit
struct UPhysicsConstraintComponent_SetLinearYLimit_Params
{
	TEnumAsByte<enum ELinearConstraintMotion> ConstraintType; // (Parm, ZeroConstructor, IsPlainOldData)
	float LimitSize; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearXLimit
struct UPhysicsConstraintComponent_SetLinearXLimit_Params
{
	TEnumAsByte<enum ELinearConstraintMotion> ConstraintType; // (Parm, ZeroConstructor, IsPlainOldData)
	float LimitSize; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearVelocityTarget
struct UPhysicsConstraintComponent_SetLinearVelocityTarget_Params
{
	struct FVector InVelTarget; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearVelocityDrive
struct UPhysicsConstraintComponent_SetLinearVelocityDrive_Params
{
	bool bEnableDriveX; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableDriveY; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableDriveZ; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearPositionTarget
struct UPhysicsConstraintComponent_SetLinearPositionTarget_Params
{
	struct FVector InPosTarget; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearPositionDrive
struct UPhysicsConstraintComponent_SetLinearPositionDrive_Params
{
	bool bEnableDriveX; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableDriveY; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableDriveZ; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearDriveParams
struct UPhysicsConstraintComponent_SetLinearDriveParams_Params
{
	float PositionStrength; // (Parm, ZeroConstructor, IsPlainOldData)
	float VelocityStrength; // (Parm, ZeroConstructor, IsPlainOldData)
	float InForceLimit; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetLinearBreakable
struct UPhysicsConstraintComponent_SetLinearBreakable_Params
{
	bool bLinearBreakable; // (Parm, ZeroConstructor, IsPlainOldData)
	float LinearBreakThreshold; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetDisableCollision
struct UPhysicsConstraintComponent_SetDisableCollision_Params
{
	bool bDisableCollision; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetConstraintReferencePosition
struct UPhysicsConstraintComponent_SetConstraintReferencePosition_Params
{
	TEnumAsByte<enum EConstraintFrame> Frame; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector RefPosition; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetConstraintReferenceOrientation
struct UPhysicsConstraintComponent_SetConstraintReferenceOrientation_Params
{
	TEnumAsByte<enum EConstraintFrame> Frame; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector PriAxis; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector SecAxis; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetConstraintReferenceFrame
struct UPhysicsConstraintComponent_SetConstraintReferenceFrame_Params
{
	TEnumAsByte<enum EConstraintFrame> Frame; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform RefFrame; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetConstrainedComponents
struct UPhysicsConstraintComponent_SetConstrainedComponents_Params
{
	class UPrimitiveComponent* Component1; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName BoneName1; // (Parm, ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* Component2; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName BoneName2; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularVelocityTarget
struct UPhysicsConstraintComponent_SetAngularVelocityTarget_Params
{
	struct FVector InVelTarget; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularVelocityDriveTwistAndSwing
struct UPhysicsConstraintComponent_SetAngularVelocityDriveTwistAndSwing_Params
{
	bool bEnableTwistDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableSwingDrive; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularVelocityDriveSLERP
struct UPhysicsConstraintComponent_SetAngularVelocityDriveSLERP_Params
{
	bool bEnableSLERP; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularVelocityDrive
struct UPhysicsConstraintComponent_SetAngularVelocityDrive_Params
{
	bool bEnableSwingDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableTwistDrive; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularTwistLimit
struct UPhysicsConstraintComponent_SetAngularTwistLimit_Params
{
	TEnumAsByte<enum EAngularConstraintMotion> ConstraintType; // (Parm, ZeroConstructor, IsPlainOldData)
	float TwistLimitAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularSwing2Limit
struct UPhysicsConstraintComponent_SetAngularSwing2Limit_Params
{
	TEnumAsByte<enum EAngularConstraintMotion> MotionType; // (Parm, ZeroConstructor, IsPlainOldData)
	float Swing2LimitAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularSwing1Limit
struct UPhysicsConstraintComponent_SetAngularSwing1Limit_Params
{
	TEnumAsByte<enum EAngularConstraintMotion> MotionType; // (Parm, ZeroConstructor, IsPlainOldData)
	float Swing1LimitAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularOrientationTarget
struct UPhysicsConstraintComponent_SetAngularOrientationTarget_Params
{
	struct FRotator InPosTarget; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularOrientationDrive
struct UPhysicsConstraintComponent_SetAngularOrientationDrive_Params
{
	bool bEnableSwingDrive; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bEnableTwistDrive; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularDriveParams
struct UPhysicsConstraintComponent_SetAngularDriveParams_Params
{
	float PositionStrength; // (Parm, ZeroConstructor, IsPlainOldData)
	float VelocityStrength; // (Parm, ZeroConstructor, IsPlainOldData)
	float InForceLimit; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularDriveMode
struct UPhysicsConstraintComponent_SetAngularDriveMode_Params
{
	TEnumAsByte<enum EAngularDriveMode> DriveMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.SetAngularBreakable
struct UPhysicsConstraintComponent_SetAngularBreakable_Params
{
	bool bAngularBreakable; // (Parm, ZeroConstructor, IsPlainOldData)
	float AngularBreakThreshold; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.IsBroken
struct UPhysicsConstraintComponent_IsBroken_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.GetCurrentTwist
struct UPhysicsConstraintComponent_GetCurrentTwist_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.GetCurrentSwing2
struct UPhysicsConstraintComponent_GetCurrentSwing2_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.GetCurrentSwing1
struct UPhysicsConstraintComponent_GetCurrentSwing1_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.GetConstraintWorldTransform
struct UPhysicsConstraintComponent_GetConstraintWorldTransform_Params
{
	TEnumAsByte<enum EConstraintFrame> Frame; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.GetConstraintForce
struct UPhysicsConstraintComponent_GetConstraintForce_Params
{
	struct FVector OutLinearForce; // (Parm, OutParm, IsPlainOldData)
	struct FVector OutAngularForce; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.PhysicsConstraintComponent.BreakConstraint
struct UPhysicsConstraintComponent_BreakConstraint_Params
{
};

// Function Engine.PhysicsHandleComponent.SetTargetRotation
struct UPhysicsHandleComponent_SetTargetRotation_Params
{
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.SetTargetLocationAndRotation
struct UPhysicsHandleComponent_SetTargetLocationAndRotation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
	struct FRotator NewRotation; // (Parm, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.SetTargetLocation
struct UPhysicsHandleComponent_SetTargetLocation_Params
{
	struct FVector NewLocation; // (Parm, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.SetLinearStiffness
struct UPhysicsHandleComponent_SetLinearStiffness_Params
{
	float NewLinearStiffness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.SetLinearDamping
struct UPhysicsHandleComponent_SetLinearDamping_Params
{
	float NewLinearDamping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.SetInterpolationSpeed
struct UPhysicsHandleComponent_SetInterpolationSpeed_Params
{
	float NewInterpolationSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.SetAngularStiffness
struct UPhysicsHandleComponent_SetAngularStiffness_Params
{
	float NewAngularStiffness; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.SetAngularDamping
struct UPhysicsHandleComponent_SetAngularDamping_Params
{
	float NewAngularDamping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.ReleaseComponent
struct UPhysicsHandleComponent_ReleaseComponent_Params
{
};

// Function Engine.PhysicsHandleComponent.GrabComponentAtLocationWithRotation
struct UPhysicsHandleComponent_GrabComponentAtLocationWithRotation_Params
{
	class UPrimitiveComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName InBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FRotator Rotation; // (Parm, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.GrabComponentAtLocation
struct UPhysicsHandleComponent_GrabComponentAtLocation_Params
{
	class UPrimitiveComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName InBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector GrabLocation; // (Parm, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.GrabComponent
struct UPhysicsHandleComponent_GrabComponent_Params
{
	class UPrimitiveComponent* Component; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FName InBoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector GrabLocation; // (Parm, IsPlainOldData)
	bool bConstrainRotation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.GetTargetLocationAndRotation
struct UPhysicsHandleComponent_GetTargetLocationAndRotation_Params
{
	struct FVector TargetLocation; // (Parm, OutParm, IsPlainOldData)
	struct FRotator TargetRotation; // (Parm, OutParm, IsPlainOldData)
};

// Function Engine.PhysicsHandleComponent.GetGrabbedComponent
struct UPhysicsHandleComponent_GetGrabbedComponent_Params
{
	class UPrimitiveComponent* ReturnValue; // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function Engine.PhysicsSpringComponent.GetSpringRestingPoint
struct UPhysicsSpringComponent_GetSpringRestingPoint_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsSpringComponent.GetSpringDirection
struct UPhysicsSpringComponent_GetSpringDirection_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsSpringComponent.GetSpringCurrentEndPoint
struct UPhysicsSpringComponent_GetSpringCurrentEndPoint_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PhysicsSpringComponent.GetNormalizedCompressionScalar
struct UPhysicsSpringComponent_GetNormalizedCompressionScalar_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PixelProjectedReflection.OnInterpToggle
struct APixelProjectedReflection_OnInterpToggle_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.ShowOnlyComponent
struct USceneCaptureComponent_ShowOnlyComponent_Params
{
	class UPrimitiveComponent* InComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.ShowOnlyActorComponents
struct USceneCaptureComponent_ShowOnlyActorComponents_Params
{
	class AActor* InActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.SetCaptureSortPriority
struct USceneCaptureComponent_SetCaptureSortPriority_Params
{
	int NewCaptureSortPriority; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.RemoveShowOnlyComponent
struct USceneCaptureComponent_RemoveShowOnlyComponent_Params
{
	class UPrimitiveComponent* InComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.RemoveShowOnlyActorComponents
struct USceneCaptureComponent_RemoveShowOnlyActorComponents_Params
{
	class AActor* InActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.HideComponent
struct USceneCaptureComponent_HideComponent_Params
{
	class UPrimitiveComponent* InComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.HideActorComponents
struct USceneCaptureComponent_HideActorComponents_Params
{
	class AActor* InActor; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.ClearShowOnlyComponents
struct USceneCaptureComponent_ClearShowOnlyComponents_Params
{
	class UPrimitiveComponent* InComponent; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent.ClearHiddenComponents
struct USceneCaptureComponent_ClearHiddenComponents_Params
{
};

// Function Engine.PlanarReflection.OnInterpToggle
struct APlanarReflection_OnInterpToggle_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlatformEventsComponent.SupportsConvertibleLaptops
struct UPlatformEventsComponent_SupportsConvertibleLaptops_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// DelegateFunction Engine.PlatformEventsComponent.PlatformEventDelegate__DelegateSignature
struct UPlatformEventsComponent_PlatformEventDelegate__DelegateSignature_Params
{
};

// Function Engine.PlatformEventsComponent.IsInTabletMode
struct UPlatformEventsComponent_IsInTabletMode_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlatformEventsComponent.IsInLaptopMode
struct UPlatformEventsComponent_IsInLaptopMode_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlatformInterfaceWebResponse.GetNumHeaders
struct UPlatformInterfaceWebResponse_GetNumHeaders_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.PlatformInterfaceWebResponse.GetHeaderValue
struct UPlatformInterfaceWebResponse_GetHeaderValue_Params
{
	struct FString HeaderName; // (Parm, ZeroConstructor)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.PlatformInterfaceWebResponse.GetHeader
struct UPlatformInterfaceWebResponse_GetHeader_Params
{
	int HeaderIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Header; // (Parm, OutParm, ZeroConstructor)
	struct FString Value; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.PlayerInput.SetMouseSensitivity
struct UPlayerInput_SetMouseSensitivity_Params
{
	float Sensitivity; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerInput.SetBind
struct UPlayerInput_SetBind_Params
{
	struct FName BindName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Command; // (Parm, ZeroConstructor)
};

// Function Engine.PlayerInput.InvertAxisKey
struct UPlayerInput_InvertAxisKey_Params
{
	struct FKey AxisKey; // (ConstParm, Parm)
};

// Function Engine.PlayerInput.InvertAxis
struct UPlayerInput_InvertAxis_Params
{
	struct FName AxisName; // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PlayerInput.ClearSmoothing
struct UPlayerInput_ClearSmoothing_Params
{
};

// Function Engine.PointLight.SetRadius
struct APointLight_SetRadius_Params
{
	float NewRadius; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLight.SetLightFalloffExponent
struct APointLight_SetLightFalloffExponent_Params
{
	float NewLightFalloffExponent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetSourceRadius
struct UPointLightComponent_SetSourceRadius_Params
{
	float bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetSourceLength
struct UPointLightComponent_SetSourceLength_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetSoftSourceRadius
struct UPointLightComponent_SetSoftSourceRadius_Params
{
	float bNewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetSimulateRectLight
struct UPointLightComponent_SetSimulateRectLight_Params
{
	bool NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetSimulatePortalLight
struct UPointLightComponent_SetSimulatePortalLight_Params
{
	bool NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetRectLightSourceWidth
struct UPointLightComponent_SetRectLightSourceWidth_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetRectLightSourceHeight
struct UPointLightComponent_SetRectLightSourceHeight_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetLightFalloffExponent
struct UPointLightComponent_SetLightFalloffExponent_Params
{
	float NewLightFalloffExponent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PointLightComponent.SetAttenuationRadius
struct UPointLightComponent_SetAttenuationRadius_Params
{
	float NewRadius; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.SetBoneTransformByName
struct UPoseableMeshComponent_SetBoneTransformByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform InTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.SetBoneScaleByName
struct UPoseableMeshComponent_SetBoneScaleByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InScale3D; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.SetBoneRotationByName
struct UPoseableMeshComponent_SetBoneRotationByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator InRotation; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.SetBoneLocationByName
struct UPoseableMeshComponent_SetBoneLocationByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector InLocation; // (Parm, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.ResetBoneTransformByName
struct UPoseableMeshComponent_ResetBoneTransformByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.GetBoneTransformByName
struct UPoseableMeshComponent_GetBoneTransformByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.GetBoneScaleByName
struct UPoseableMeshComponent_GetBoneScaleByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.GetBoneRotationByName
struct UPoseableMeshComponent_GetBoneRotationByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FRotator ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.GetBoneLocationByName
struct UPoseableMeshComponent_GetBoneLocationByName_Params
{
	struct FName BoneName; // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneSpaces> BoneSpace; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.PoseableMeshComponent.CopyPoseFromSkeletalComponent
struct UPoseableMeshComponent_CopyPoseFromSkeletalComponent_Params
{
	class USkeletalMeshComponent* InComponentToCopy; // (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function Engine.PostProcessComponent.AddOrUpdateBlendable
struct UPostProcessComponent_AddOrUpdateBlendable_Params
{
	TScriptInterface<class UBlendableInterface> InBlendableObject; // (Parm, ZeroConstructor, IsPlainOldData)
	float InWeight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PostProcessVolume.RemoveBlendable
struct APostProcessVolume_RemoveBlendable_Params
{
	TScriptInterface<class UBlendableInterface> InBlendableObject; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.PostProcessVolume.AddOrUpdateBlendable
struct APostProcessVolume_AddOrUpdateBlendable_Params
{
	TScriptInterface<class UBlendableInterface> InBlendableObject; // (Parm, ZeroConstructor, IsPlainOldData)
	float InWeight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.RadialForceActor.ToggleForce
struct ARadialForceActor_ToggleForce_Params
{
};

// Function Engine.RadialForceActor.FireImpulse
struct ARadialForceActor_FireImpulse_Params
{
};

// Function Engine.RadialForceActor.EnableForce
struct ARadialForceActor_EnableForce_Params
{
};

// Function Engine.RadialForceActor.DisableForce
struct ARadialForceActor_DisableForce_Params
{
};

// Function Engine.RadialForceComponent.RemoveObjectTypeToAffect
struct URadialForceComponent_RemoveObjectTypeToAffect_Params
{
	TEnumAsByte<enum EObjectTypeQuery> ObjectType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.RadialForceComponent.FireImpulse
struct URadialForceComponent_FireImpulse_Params
{
};

// Function Engine.RadialForceComponent.AddObjectTypeToAffect
struct URadialForceComponent_AddObjectTypeToAffect_Params
{
	TEnumAsByte<enum EObjectTypeQuery> ObjectType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.ResetableInReplayInterface.ResetInReplay
struct UResetableInReplayInterface_ResetInReplay_Params
{
};

// Function Engine.Reusable.ReceiveOnSpawn
struct UReusable_ReceiveOnSpawn_Params
{
};

// Function Engine.Reusable.ReceiveOnRecycle
struct UReusable_ReceiveOnRecycle_Params
{
};

// Function Engine.Reusable.ReceiveOnPoolCreate
struct UReusable_ReceiveOnPoolCreate_Params
{
};

// Function Engine.Reusable.OnSpawn
struct UReusable_OnSpawn_Params
{
};

// Function Engine.Reusable.OnRecycle
struct UReusable_OnRecycle_Params
{
};

// Function Engine.SceneCapture2D.OnInterpToggle
struct ASceneCapture2D_OnInterpToggle_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneCaptureComponent2D.CaptureScene
struct USceneCaptureComponent2D_CaptureScene_Params
{
};

// Function Engine.SceneCaptureComponent2D.AddOrUpdateBlendable
struct USceneCaptureComponent2D_AddOrUpdateBlendable_Params
{
	TScriptInterface<class UBlendableInterface> InBlendableObject; // (Parm, ZeroConstructor, IsPlainOldData)
	float InWeight; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SceneCaptureComponentCube.CaptureScene
struct USceneCaptureComponentCube_CaptureScene_Params
{
};

// Function Engine.SceneCaptureCube.OnInterpToggle
struct ASceneCaptureCube_OnInterpToggle_Params
{
	bool bEnable; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkeletalMesh.RestoreSpecificLOD
struct USkeletalMesh_RestoreSpecificLOD_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	ELODDropResult ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.RestoreAllDroppedLODs
struct USkeletalMesh_RestoreAllDroppedLODs_Params
{
};

// Function Engine.SkeletalMesh.NumSockets
struct USkeletalMesh_NumSockets_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.IsSectionUsingCloth
struct USkeletalMesh_IsSectionUsingCloth_Params
{
	int InSectionIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bCheckCorrespondingSections; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.IsLODDropped
struct USkeletalMesh_IsLODDropped_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.HasPendingDropRelease
struct USkeletalMesh_HasPendingDropRelease_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.GetSocketByIndex
struct USkeletalMesh_GetSocketByIndex_Params
{
	int Index; // (Parm, ZeroConstructor, IsPlainOldData)
	class USkeletalMeshSocket* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.GetNodeMappingContainer
struct USkeletalMesh_GetNodeMappingContainer_Params
{
	class UBlueprint* SourceAsset; // (Parm, ZeroConstructor, IsPlainOldData)
	class UNodeMappingContainer* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.GetLODVRAMFootprint
struct USkeletalMesh_GetLODVRAMFootprint_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.GetImportedBounds
struct USkeletalMesh_GetImportedBounds_Params
{
	struct FBoxSphereBounds ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.GetDroppedLODs
struct USkeletalMesh_GetDroppedLODs_Params
{
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.SkeletalMesh.GetBounds
struct USkeletalMesh_GetBounds_Params
{
	struct FBoxSphereBounds ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.FindSocketAndIndex
struct USkeletalMesh_FindSocketAndIndex_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	int OutIndex; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class USkeletalMeshSocket* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.FindSocket
struct USkeletalMesh_FindSocket_Params
{
	struct FName InSocketName; // (Parm, ZeroConstructor, IsPlainOldData)
	class USkeletalMeshSocket* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.DropSpecificLOD
struct USkeletalMesh_DropSpecificLOD_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	ELODDropResult ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SkeletalMesh.DropLODs
struct USkeletalMesh_DropLODs_Params
{
	TArray<int> LODIndices; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<ELODDropResult> OutResults; // (Parm, OutParm, ZeroConstructor)
};

// Function Engine.SkeletalMesh.CommitPendingDropReleases
struct USkeletalMesh_CommitPendingDropReleases_Params
{
};

// Function Engine.SkeletalMeshActor.OnRep_ReplicatedPhysAsset
struct ASkeletalMeshActor_OnRep_ReplicatedPhysAsset_Params
{
};

// Function Engine.SkeletalMeshActor.OnRep_ReplicatedMesh
struct ASkeletalMeshActor_OnRep_ReplicatedMesh_Params
{
};

// Function Engine.SkeletalMeshActor.OnRep_ReplicatedMaterial1
struct ASkeletalMeshActor_OnRep_ReplicatedMaterial1_Params
{
};

// Function Engine.SkeletalMeshActor.OnRep_ReplicatedMaterial0
struct ASkeletalMeshActor_OnRep_ReplicatedMaterial0_Params
{
};

// Function Engine.SkeletalMeshSocket.InitializeSocketFromLocation
struct USkeletalMeshSocket_InitializeSocketFromLocation_Params
{
	class USkeletalMeshComponent* SkelComp; // (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector WorldLocation; // (Parm, IsPlainOldData)
	struct FVector WorldNormal; // (Parm, IsPlainOldData)
};

// Function Engine.SkeletalMeshSocket.GetSocketLocation
struct USkeletalMeshSocket_GetSocketLocation_Params
{
	class USkeletalMeshComponent* SkelComp; // (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetSkyLuminanceFactor
struct USkyAtmosphereComponent_SetSkyLuminanceFactor_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetRayleighScatteringScale
struct USkyAtmosphereComponent_SetRayleighScatteringScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetRayleighScattering
struct USkyAtmosphereComponent_SetRayleighScattering_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetRayleighExponentialDistribution
struct USkyAtmosphereComponent_SetRayleighExponentialDistribution_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetOtherAbsorptionScale
struct USkyAtmosphereComponent_SetOtherAbsorptionScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetOtherAbsorption
struct USkyAtmosphereComponent_SetOtherAbsorption_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetMieScatteringScale
struct USkyAtmosphereComponent_SetMieScatteringScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetMieScattering
struct USkyAtmosphereComponent_SetMieScattering_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetMieExponentialDistribution
struct USkyAtmosphereComponent_SetMieExponentialDistribution_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetMieAnisotropy
struct USkyAtmosphereComponent_SetMieAnisotropy_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetMieAbsorptionScale
struct USkyAtmosphereComponent_SetMieAbsorptionScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetMieAbsorption
struct USkyAtmosphereComponent_SetMieAbsorption_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetHeightFogContribution
struct USkyAtmosphereComponent_SetHeightFogContribution_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.SetAerialPespectiveViewDistanceScale
struct USkyAtmosphereComponent_SetAerialPespectiveViewDistanceScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyAtmosphereComponent.OverrideAtmosphereLightDirection
struct USkyAtmosphereComponent_OverrideAtmosphereLightDirection_Params
{
	int AtmosphereLightIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector LightDirection; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SkyLight.OnRep_bEnabled
struct ASkyLight_OnRep_bEnabled_Params
{
};

// Function Engine.SkyLightComponent.SetVolumetricScatteringIntensity
struct USkyLightComponent_SetVolumetricScatteringIntensity_Params
{
	float NewIntensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetOcclusionTint
struct USkyLightComponent_SetOcclusionTint_Params
{
	struct FColor InTint; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetOcclusionExponent
struct USkyLightComponent_SetOcclusionExponent_Params
{
	float InOcclusionExponent; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetOcclusionContrast
struct USkyLightComponent_SetOcclusionContrast_Params
{
	float InOcclusionContrast; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetMinOcclusion
struct USkyLightComponent_SetMinOcclusion_Params
{
	float InMinOcclusion; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetLightColor
struct USkyLightComponent_SetLightColor_Params
{
	struct FLinearColor NewLightColor; // (Parm, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetIntensity
struct USkyLightComponent_SetIntensity_Params
{
	float NewIntensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetIndirectLightingIntensity
struct USkyLightComponent_SetIndirectLightingIntensity_Params
{
	float NewIntensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetCubemapBlend
struct USkyLightComponent_SetCubemapBlend_Params
{
	class UTextureCube* SourceCubemap; // (Parm, ZeroConstructor, IsPlainOldData)
	class UTextureCube* DestinationCubemap; // (Parm, ZeroConstructor, IsPlainOldData)
	float InBlendFraction; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.SetCubemap
struct USkyLightComponent_SetCubemap_Params
{
	class UTextureCube* NewCubemap; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SkyLightComponent.RecaptureSky
struct USkyLightComponent_RecaptureSky_Params
{
};

// Function Engine.SparseVolumeTexture.GetSizeZ
struct USparseVolumeTexture_GetSizeZ_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SparseVolumeTexture.GetSizeY
struct USparseVolumeTexture_GetSizeY_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SparseVolumeTexture.GetSizeX
struct USparseVolumeTexture_GetSizeX_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SparseVolumeTexture.GetNumMipLevels
struct USparseVolumeTexture_GetNumMipLevels_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SparseVolumeTexture.GetNumFrames
struct USparseVolumeTexture_GetNumFrames_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SparseVolumeTexture.GetFrameTransform
struct USparseVolumeTexture_GetFrameTransform_Params
{
	struct FTransform ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimatedSparseVolumeTextureController.Update
struct UAnimatedSparseVolumeTextureController_Update_Params
{
	float DeltaTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimatedSparseVolumeTextureController.Stop
struct UAnimatedSparseVolumeTextureController_Stop_Params
{
};

// Function Engine.AnimatedSparseVolumeTextureController.Play
struct UAnimatedSparseVolumeTextureController_Play_Params
{
};

// Function Engine.AnimatedSparseVolumeTextureController.Pause
struct UAnimatedSparseVolumeTextureController_Pause_Params
{
};

// Function Engine.AnimatedSparseVolumeTextureController.GetFrameByIndex
struct UAnimatedSparseVolumeTextureController_GetFrameByIndex_Params
{
	int FrameIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class USparseVolumeTextureFrame* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimatedSparseVolumeTextureController.GetFractionalFrameIndex
struct UAnimatedSparseVolumeTextureController_GetFractionalFrameIndex_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimatedSparseVolumeTextureController.GetDuration
struct UAnimatedSparseVolumeTextureController_GetDuration_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.AnimatedSparseVolumeTextureController.GetCurrentFramesForInterpolation
struct UAnimatedSparseVolumeTextureController_GetCurrentFramesForInterpolation_Params
{
	class USparseVolumeTextureFrame* Frame0; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class USparseVolumeTextureFrame* Frame1; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float LerpAlpha; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.AnimatedSparseVolumeTextureController.GetCurrentFrame
struct UAnimatedSparseVolumeTextureController_GetCurrentFrame_Params
{
	class USparseVolumeTextureFrame* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SplineComponentEditorModifer.ModifyPostion
struct USplineComponentEditorModifer_ModifyPostion_Params
{
	struct FVector InPosition; // (Parm, IsPlainOldData)
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.SpotLightComponent.SetOuterConeAngle
struct USpotLightComponent_SetOuterConeAngle_Params
{
	float NewOuterConeAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SpotLightComponent.SetInnerConeAngle
struct USpotLightComponent_SetInnerConeAngle_Params
{
	float NewInnerConeAngle; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMesh.RemoveVertexColors
struct UStaticMesh_RemoveVertexColors_Params
{
};

// Function Engine.StaticMesh.RemoveTextureCoord
struct UStaticMesh_RemoveTextureCoord_Params
{
	int ReserveTexCoordNum; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StaticMesh.GetNumVertices
struct UStaticMesh_GetNumVertices_Params
{
	int LODIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMesh.GetNumSections
struct UStaticMesh_GetNumSections_Params
{
	int InLOD; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMesh.GetNumLODs
struct UStaticMesh_GetNumLODs_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMesh.GetMaterialIndex
struct UStaticMesh_GetMaterialIndex_Params
{
	struct FName MaterialSlotName; // (Parm, ZeroConstructor, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMesh.GetMaterial
struct UStaticMesh_GetMaterial_Params
{
	int MaterialIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMesh.GetBounds
struct UStaticMesh_GetBounds_Params
{
	struct FBoxSphereBounds ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.StaticMesh.GetBoundingBox
struct UStaticMesh_GetBoundingBox_Params
{
	struct FBox ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.StatLabelFunctionLibrary.StatStop
struct UStatLabelFunctionLibrary_StatStop_Params
{
};

// Function Engine.StatLabelFunctionLibrary.StatStart
struct UStatLabelFunctionLibrary_StatStart_Params
{
	bool IsScreenshotEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
	bool IsStatLogEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
	bool IsStatLabelEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StatLabelFunctionLibrary.SetStatLabel
struct UStatLabelFunctionLibrary_SetStatLabel_Params
{
	struct FString LabelName; // (Parm, ZeroConstructor)
};

// Function Engine.StereoLayerComponent.SetUVRect
struct UStereoLayerComponent_SetUVRect_Params
{
	struct FBox2D InUVRect; // (Parm)
};

// Function Engine.StereoLayerComponent.SetTexture
struct UStereoLayerComponent_SetTexture_Params
{
	class UTexture* InTexture; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StereoLayerComponent.SetQuadSize
struct UStereoLayerComponent_SetQuadSize_Params
{
	struct FVector2D InQuadSize; // (Parm, IsPlainOldData)
};

// Function Engine.StereoLayerComponent.SetPriority
struct UStereoLayerComponent_SetPriority_Params
{
	int InPriority; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StereoLayerComponent.MarkTextureForUpdate
struct UStereoLayerComponent_MarkTextureForUpdate_Params
{
};

// Function Engine.StereoLayerComponent.GetUVRect
struct UStereoLayerComponent_GetUVRect_Params
{
	struct FBox2D ReturnValue; // (Parm, OutParm, ReturnParm)
};

// Function Engine.StereoLayerComponent.GetTexture
struct UStereoLayerComponent_GetTexture_Params
{
	class UTexture* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StereoLayerComponent.GetQuadSize
struct UStereoLayerComponent_GetQuadSize_Params
{
	struct FVector2D ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.StereoLayerComponent.GetPriority
struct UStereoLayerComponent_GetPriority_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.StereoLayerFunctionLibrary.ShowSplashScreen
struct UStereoLayerFunctionLibrary_ShowSplashScreen_Params
{
};

// Function Engine.StereoLayerFunctionLibrary.SetSplashScreen
struct UStereoLayerFunctionLibrary_SetSplashScreen_Params
{
	class UTexture* Texture; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector2D Scale; // (Parm, IsPlainOldData)
	struct FVector2D Offset; // (Parm, IsPlainOldData)
	bool bShowLoadingMovie; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bShowOnSet; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.StereoLayerFunctionLibrary.HideSplashScreen
struct UStereoLayerFunctionLibrary_HideSplashScreen_Params
{
};

// Function Engine.StereoLayerFunctionLibrary.EnableAutoLoadingSplashScreen
struct UStereoLayerFunctionLibrary_EnableAutoLoadingSplashScreen_Params
{
	bool InAutoShowEnabled; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.SubsystemBlueprintLibrary.GetWorldSubsystem
struct USubsystemBlueprintLibrary_GetWorldSubsystem_Params
{
	class UObject* ContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	class UWorldSubsystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SubsystemBlueprintLibrary.GetLocalPlayerSubSystemFromPlayerController
struct USubsystemBlueprintLibrary_GetLocalPlayerSubSystemFromPlayerController_Params
{
	class APlayerController* PlayerController; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	class ULocalPlayerSubsystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SubsystemBlueprintLibrary.GetLocalPlayerSubsystem
struct USubsystemBlueprintLibrary_GetLocalPlayerSubsystem_Params
{
	class UObject* ContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	class ULocalPlayerSubsystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SubsystemBlueprintLibrary.GetGameInstanceSubsystem
struct USubsystemBlueprintLibrary_GetGameInstanceSubsystem_Params
{
	class UObject* ContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	class UGameInstanceSubsystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.SubsystemBlueprintLibrary.GetEngineSubsystem
struct USubsystemBlueprintLibrary_GetEngineSubsystem_Params
{
	class UClass* Class; // (Parm, ZeroConstructor, IsPlainOldData)
	class UEngineSubsystem* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetYScale
struct UTextRenderComponent_SetYScale_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetXScale
struct UTextRenderComponent_SetXScale_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetWorldSize
struct UTextRenderComponent_SetWorldSize_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetVertSpacingAdjust
struct UTextRenderComponent_SetVertSpacingAdjust_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetVerticalAlignment
struct UTextRenderComponent_SetVerticalAlignment_Params
{
	TEnumAsByte<enum EVerticalTextAligment> Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetTextRenderColor
struct UTextRenderComponent_SetTextRenderColor_Params
{
	struct FColor Value; // (Parm, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetTextMaterial
struct UTextRenderComponent_SetTextMaterial_Params
{
	class UMaterialInterface* Material; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetText
struct UTextRenderComponent_SetText_Params
{
	struct FString Value; // (Parm, ZeroConstructor)
};

// Function Engine.TextRenderComponent.SetHorizSpacingAdjust
struct UTextRenderComponent_SetHorizSpacingAdjust_Params
{
	float Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetHorizontalAlignment
struct UTextRenderComponent_SetHorizontalAlignment_Params
{
	TEnumAsByte<enum EHorizTextAligment> Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.SetFont
struct UTextRenderComponent_SetFont_Params
{
	class UFont* Value; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TextRenderComponent.K2_SetText
struct UTextRenderComponent_K2_SetText_Params
{
	struct FText Value; // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function Engine.TextRenderComponent.GetTextWorldSize
struct UTextRenderComponent_GetTextWorldSize_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.TextRenderComponent.GetTextLocalSize
struct UTextRenderComponent_GetTextLocalSize_Params
{
	struct FVector ReturnValue; // (Parm, OutParm, ReturnParm, IsPlainOldData)
};

// Function Engine.TextureArrayInstancedStaticMeshComponent.SetStaticMesh
struct UTextureArrayInstancedStaticMeshComponent_SetStaticMesh_Params
{
	class UStaticMesh* NewMesh; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TextureArrayInstancedStaticMeshComponent.AddInstanceWithTextureArray
struct UTextureArrayInstancedStaticMeshComponent_AddInstanceWithTextureArray_Params
{
	class UMaterialInstance* NewInstance; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FTransform InstanceTransform; // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TextureArrayInstancedStaticMeshComponent.AddInstancesWithTextureArray
struct UTextureArrayInstancedStaticMeshComponent_AddInstancesWithTextureArray_Params
{
	class UMaterialInstance* NewInstance; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<struct FTransform> InstanceTransforms; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	bool bShouldReturnIndices; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bMarkRenderStateDirty; // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<int> ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.TimelineComponent.Stop
struct UTimelineComponent_Stop_Params
{
};

// Function Engine.TimelineComponent.SetVectorCurve
struct UTimelineComponent_SetVectorCurve_Params
{
	class UCurveVector* NewVectorCurve; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName VectorTrackName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetTimelineLengthMode
struct UTimelineComponent_SetTimelineLengthMode_Params
{
	TEnumAsByte<enum ETimelineLengthMode> NewLengthMode; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetTimelineLength
struct UTimelineComponent_SetTimelineLength_Params
{
	float NewLength; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetPlayRate
struct UTimelineComponent_SetPlayRate_Params
{
	float NewRate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetPlaybackPosition
struct UTimelineComponent_SetPlaybackPosition_Params
{
	float NewPosition; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFireEvents; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bFireUpdate; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetNewTime
struct UTimelineComponent_SetNewTime_Params
{
	float NewTime; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetLooping
struct UTimelineComponent_SetLooping_Params
{
	bool bNewLooping; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetLinearColorCurve
struct UTimelineComponent_SetLinearColorCurve_Params
{
	class UCurveLinearColor* NewLinearColorCurve; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName LinearColorTrackName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetIgnoreTimeDilation
struct UTimelineComponent_SetIgnoreTimeDilation_Params
{
	bool bNewIgnoreTimeDilation; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.SetFloatCurve
struct UTimelineComponent_SetFloatCurve_Params
{
	class UCurveFloat* NewFloatCurve; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName FloatTrackName; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.TimelineComponent.ReverseFromEnd
struct UTimelineComponent_ReverseFromEnd_Params
{
};

// Function Engine.TimelineComponent.Reverse
struct UTimelineComponent_Reverse_Params
{
};

// Function Engine.TimelineComponent.PlayFromStart
struct UTimelineComponent_PlayFromStart_Params
{
};

// Function Engine.TimelineComponent.Play
struct UTimelineComponent_Play_Params
{
};

// Function Engine.TimelineComponent.OnRep_Timeline
struct UTimelineComponent_OnRep_Timeline_Params
{
};

// Function Engine.TimelineComponent.IsReversing
struct UTimelineComponent_IsReversing_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TimelineComponent.IsPlaying
struct UTimelineComponent_IsPlaying_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TimelineComponent.IsLooping
struct UTimelineComponent_IsLooping_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TimelineComponent.GetTimelineLength
struct UTimelineComponent_GetTimelineLength_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TimelineComponent.GetPlayRate
struct UTimelineComponent_GetPlayRate_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TimelineComponent.GetPlaybackPosition
struct UTimelineComponent_GetPlaybackPosition_Params
{
	float ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TimelineComponent.GetIgnoreTimeDilation
struct UTimelineComponent_GetIgnoreTimeDilation_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TwitterIntegrationBase.TwitterRequest
struct UTwitterIntegrationBase_TwitterRequest_Params
{
	struct FString URL; // (Parm, ZeroConstructor)
	TArray<struct FString> ParamKeysAndValues; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TEnumAsByte<enum ETwitterRequestMethod> RequestMethod; // (Parm, ZeroConstructor, IsPlainOldData)
	int AccountIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TwitterIntegrationBase.ShowTweetUI
struct UTwitterIntegrationBase_ShowTweetUI_Params
{
	struct FString InitialMessage; // (Parm, ZeroConstructor)
	struct FString URL; // (Parm, ZeroConstructor)
	struct FString Picture; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TwitterIntegrationBase.Init
struct UTwitterIntegrationBase_Init_Params
{
};

// Function Engine.TwitterIntegrationBase.GetNumAccounts
struct UTwitterIntegrationBase_GetNumAccounts_Params
{
	int ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TwitterIntegrationBase.GetAccountName
struct UTwitterIntegrationBase_GetAccountName_Params
{
	int AccountIndex; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function Engine.TwitterIntegrationBase.CanShowTweetUI
struct UTwitterIntegrationBase_CanShowTweetUI_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.TwitterIntegrationBase.AuthorizeAccounts
struct UTwitterIntegrationBase_AuthorizeAccounts_Params
{
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.VectorFieldComponent.SetIntensity
struct UVectorFieldComponent_SetIntensity_Params
{
	float NewIntensity; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VisualLoggerKismetLibrary.LogText
struct UVisualLoggerKismetLibrary_LogText_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString Text; // (Parm, ZeroConstructor)
	struct FName LogCategory; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VisualLoggerKismetLibrary.LogLocation
struct UVisualLoggerKismetLibrary_LogLocation_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector Location; // (Parm, IsPlainOldData)
	struct FString Text; // (Parm, ZeroConstructor)
	struct FLinearColor ObjectColor; // (Parm, IsPlainOldData)
	float Radius; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName LogCategory; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VisualLoggerKismetLibrary.LogBox
struct UVisualLoggerKismetLibrary_LogBox_Params
{
	class UObject* WorldContextObject; // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBox BoxShape; // (Parm, IsPlainOldData)
	struct FString Text; // (Parm, ZeroConstructor)
	struct FLinearColor ObjectColor; // (Parm, IsPlainOldData)
	struct FName LogCategory; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetViewSampleCountScale
struct UVolumetricCloudComponent_SetViewSampleCountScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetTracingStartMaxDistance
struct UVolumetricCloudComponent_SetTracingStartMaxDistance_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetTracingMaxDistance
struct UVolumetricCloudComponent_SetTracingMaxDistance_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetStopTracingTransmittanceThreshold
struct UVolumetricCloudComponent_SetStopTracingTransmittanceThreshold_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetSkyLightCloudBottomOcclusion
struct UVolumetricCloudComponent_SetSkyLightCloudBottomOcclusion_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetShadowViewSampleCountScale
struct UVolumetricCloudComponent_SetShadowViewSampleCountScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetShadowTracingDistance
struct UVolumetricCloudComponent_SetShadowTracingDistance_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetShadowReflectionSampleCountScale
struct UVolumetricCloudComponent_SetShadowReflectionSampleCountScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetReflectionSampleCountScale
struct UVolumetricCloudComponent_SetReflectionSampleCountScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetPlanetRadius
struct UVolumetricCloudComponent_SetPlanetRadius_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetMaterial
struct UVolumetricCloudComponent_SetMaterial_Params
{
	class UMaterialInterface* NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetLayerHeight
struct UVolumetricCloudComponent_SetLayerHeight_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetLayerBottomAltitude
struct UVolumetricCloudComponent_SetLayerBottomAltitude_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetGroundAlbedo
struct UVolumetricCloudComponent_SetGroundAlbedo_Params
{
	struct FColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetbUsePerSampleAtmosphericLightTransmittance
struct UVolumetricCloudComponent_SetbUsePerSampleAtmosphericLightTransmittance_Params
{
	bool NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetBoxMin
struct UVolumetricCloudComponent_SetBoxMin_Params
{
	struct FVector NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.VolumetricCloudComponent.SetBoxMax
struct UVolumetricCloudComponent_SetBoxMax_Params
{
	struct FVector NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.VolumetricFogBoxComponent.SetVolumetricFogExtinctionScale
struct UVolumetricFogBoxComponent_SetVolumetricFogExtinctionScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricFogBoxComponent.SetVolumetricFogEmissive
struct UVolumetricFogBoxComponent_SetVolumetricFogEmissive_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.VolumetricFogBoxComponent.SetVolumetricFogAlbedo
struct UVolumetricFogBoxComponent_SetVolumetricFogAlbedo_Params
{
	struct FColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.VolumetricFogSphereComponent.SetVolumetricFogExtinctionScale
struct UVolumetricFogSphereComponent_SetVolumetricFogExtinctionScale_Params
{
	float NewValue; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.VolumetricFogSphereComponent.SetVolumetricFogEmissive
struct UVolumetricFogSphereComponent_SetVolumetricFogEmissive_Params
{
	struct FLinearColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.VolumetricFogSphereComponent.SetVolumetricFogAlbedo
struct UVolumetricFogSphereComponent_SetVolumetricFogAlbedo_Params
{
	struct FColor NewValue; // (Parm, IsPlainOldData)
};

// Function Engine.WindDirectionalSourceComponent.SetWindType
struct UWindDirectionalSourceComponent_SetWindType_Params
{
	EWindSourceType InNewType; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.WindDirectionalSourceComponent.SetStrength
struct UWindDirectionalSourceComponent_SetStrength_Params
{
	float InNewStrength; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.WindDirectionalSourceComponent.SetSpeed
struct UWindDirectionalSourceComponent_SetSpeed_Params
{
	float InNewSpeed; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.WindDirectionalSourceComponent.SetRadius
struct UWindDirectionalSourceComponent_SetRadius_Params
{
	float InNewRadius; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.WindDirectionalSourceComponent.SetMinimumGustAmount
struct UWindDirectionalSourceComponent_SetMinimumGustAmount_Params
{
	float InNewMinGust; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.WindDirectionalSourceComponent.SetMaximumGustAmount
struct UWindDirectionalSourceComponent_SetMaximumGustAmount_Params
{
	float InNewMaxGust; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.WorldComposition.SetStreamingDistanceScalePerLevel
struct UWorldComposition_SetStreamingDistanceScalePerLevel_Params
{
	struct FName LevelName; // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm, IsPlainOldData)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.WorldComposition.SetStreamingDistanceScaleByLayer
struct UWorldComposition_SetStreamingDistanceScaleByLayer_Params
{
	struct FString LayerName; // (Parm, ZeroConstructor)
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.WorldComposition.SetStreamingDistanceScaleAllLevel
struct UWorldComposition_SetStreamingDistanceScaleAllLevel_Params
{
	float Scale; // (Parm, ZeroConstructor, IsPlainOldData)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.WorldComposition.RemoveDynamicTile
struct UWorldComposition_RemoveDynamicTile_Params
{
	struct FString TilePackageNameStr; // (Parm, ZeroConstructor)
	bool ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.WorldComposition.GetDynamicTile
struct UWorldComposition_GetDynamicTile_Params
{
	struct FString TilePackageNameStr; // (Parm, ZeroConstructor)
	class ULevelStreaming* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.WorldComposition.AddEnableStreamingTile
struct UWorldComposition_AddEnableStreamingTile_Params
{
	int EnableTileIdx; // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function Engine.WorldComposition.AddEnableStreamingLayer
struct UWorldComposition_AddEnableStreamingLayer_Params
{
	struct FString EnableLayerName; // (Parm, ZeroConstructor)
};

// Function Engine.WorldComposition.AddDynamicTile
struct UWorldComposition_AddDynamicTile_Params
{
	struct FString TilePackageNameStr; // (Parm, ZeroConstructor)
	int X; // (Parm, ZeroConstructor, IsPlainOldData)
	int Y; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bAllowCopy; // (Parm, ZeroConstructor, IsPlainOldData)
	bool bDisableDistanceStreaming; // (Parm, ZeroConstructor, IsPlainOldData)
	class ULevelStreaming* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function Engine.WorldSettings.OnRep_WorldGravityZ
struct AWorldSettings_OnRep_WorldGravityZ_Params
{
};

}

