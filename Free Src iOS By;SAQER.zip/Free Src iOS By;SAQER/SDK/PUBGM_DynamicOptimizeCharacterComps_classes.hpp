#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass DynamicOptimizeCharacterComps.DynamicOptimizeCharacterComps_C
// 0x0000 (0x0358 - 0x0358)
class UDynamicOptimizeCharacterComps_C : public UDynamicOptimizeActorComponents
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass DynamicOptimizeCharacterComps.DynamicOptimizeCharacterComps_C");
		return pStaticClass;
	}

};


}

