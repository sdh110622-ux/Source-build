#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass BP_Lobby_VehicleLicenseComponent.BP_Lobby_VehicleLicenseComponent_C
// 0x0000 (0x0368 - 0x0368)
class UBP_Lobby_VehicleLicenseComponent_C : public UVehicleLicenseNumberComponent
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_Lobby_VehicleLicenseComponent.BP_Lobby_VehicleLicenseComponent_C");
		return pStaticClass;
	}

};


}

