#pragma once

// PUBGM SDK (4.6.0) x64Bit BY SRC HUB
// SRC HUB
// This File Was Generated at :Tue Sep  8 15:58:55 2026
 
namespace SDK
{
//===========SRC HUB==========\\
//Script Structs
//===========SRC HUB==========\\
// UserDefinedStruct BP_STRUCT_LobbyQueueControl_PostSwitchPopup_type.BP_STRUCT_LobbyQueueControl_PostSwitchPopup_type
// 0x0048
struct FBP_STRUCT_LobbyQueueControl_PostSwitchPopup_type
{
	struct FString                                     EventID_0_4514838002A4BE4A0507256002721084;               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EventType_1_0B22E8C060F38C612ADDC4D30211F215;             // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               ExecuteOnce_2_4AC4B5C030B7A4AD7508230204FC1575;           // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
	int                                                ID_3_2853A3007A64CA2241F5132B0BA48534;                    // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Order_5_74409EC04444D0CF56088D9E08683082;                 // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ModuleID_6_1DBD9C8032679F5C7BF657310E20AF34;              // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     CheckFunction_7_6E2B48C02B34A80B701D9D020D1B79DE;         // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               OnlyPostSwitch_8_604EAE405A32FA251FC46CFE0938FAE8;        // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0041(0x0003) MISSED OFFSET
	int                                                PackageLimit_9_670C6A80225162981B63AF75092EC7F4;          // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

