#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// ScriptStruct CommonGameFeatures.RepControlGroupData
// 0x0050
struct FRepControlGroupData
{
	TMap<int64_t, int> RepControlMap; // 0x0000(0x0050) (ZeroConstructor)
};

}

