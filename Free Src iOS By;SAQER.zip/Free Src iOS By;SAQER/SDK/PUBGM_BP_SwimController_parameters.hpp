#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function BP_SwimController.BP_SwimController_C.EnterWater_BluePrint
struct UBP_SwimController_C_EnterWater_BluePrint_Params
{
};

// Function BP_SwimController.BP_SwimController_C.BP_UnderWaterStateChanged
struct UBP_SwimController_C_BP_UnderWaterStateChanged_Params
{
	bool* bEnterWater; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function BP_SwimController.BP_SwimController_C.ExecuteUbergraph_BP_SwimController
struct UBP_SwimController_C_ExecuteUbergraph_BP_SwimController_Params
{
	int EntryPoint; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

