#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function BP_NewFakePlayerAIC.BP_NewFakePlayerAIC_C.UserConstructionScript
struct ABP_NewFakePlayerAIC_C_UserConstructionScript_Params
{
};

}

