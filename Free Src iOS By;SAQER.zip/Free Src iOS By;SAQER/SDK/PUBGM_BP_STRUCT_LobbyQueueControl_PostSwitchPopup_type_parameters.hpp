#pragma once

// PUBGM SDK (4.6.0) x64Bit BY SRC HUB
// SRC HUB
// This File Was Generated at :Tue Sep  8 15:58:55 2026
 
#include "../SDK.hpp"

namespace SDK
{
//===========SRC HUB==========\\
//Parameters
//===========SRC HUB==========\\
}

