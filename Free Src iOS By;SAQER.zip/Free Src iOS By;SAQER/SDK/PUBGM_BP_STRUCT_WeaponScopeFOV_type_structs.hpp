#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// UserDefinedStruct BP_STRUCT_WeaponScopeFOV_type.BP_STRUCT_WeaponScopeFOV_type
// 0x0018
struct FBP_STRUCT_WeaponScopeFOV_type
{
	struct FString ScopeGroupID_6_49CF3E400C41B18D667A9238018BF244; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float ScopeFov_f_7_6553D3C0033D7BFF701FD78D06949766; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int AimedAngle_8_3E02AB0072EDDA440E9C5E950B8A5745; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

