#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass BP_GrenadeDamageType.BP_GrenadeDamageType_C
// 0x0000 (0x0040 - 0x0040)
class UBP_GrenadeDamageType_C : public UDamageType
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_GrenadeDamageType.BP_GrenadeDamageType_C");
		return pStaticClass;
	}

};


}

