#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass LobbyAvatarFunctionLibrary.LobbyAvatarFunctionLibrary_C
// 0x0000 (0x0090 - 0x0090)
class ULobbyAvatarFunctionLibrary_C : public UBlueprintFunctionOverride
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass LobbyAvatarFunctionLibrary.LobbyAvatarFunctionLibrary_C");
		return pStaticClass;
	}


	static void OnPlayerRotate(class UCharacterAvatarComp2_BP_C* AvatarComp, class UObject* __WorldContext);
};


}

