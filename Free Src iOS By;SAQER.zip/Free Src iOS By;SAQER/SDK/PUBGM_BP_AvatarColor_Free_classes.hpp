#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass BP_AvatarColor_Free.BP_AvatarColor_Free_C
// 0x0000 (0x0058 - 0x0058)
class UBP_AvatarColor_Free_C : public UBP_AvatarColor_Base_C
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_AvatarColor_Free.BP_AvatarColor_Free_C");
		return pStaticClass;
	}

};


}

