#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// UserDefinedStruct BP_STRUCT_AvatarWeaponHitFXData_type.BP_STRUCT_AvatarWeaponHitFXData_type
// 0x0014
struct FBP_STRUCT_AvatarWeaponHitFXData_type
{
	struct FString EffectPath_0_10BE9D8007788EA45AF4C54C06DC3028; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int ID_1_5D54EA4001CDCE7777865F5B044D7534; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

