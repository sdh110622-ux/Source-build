#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass BP_NightVisionComponent.BP_NightVisionComponent_C
// 0x0000 (0x0CA0 - 0x0CA0)
class UBP_NightVisionComponent_C : public UNightVisionComponent
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_NightVisionComponent.BP_NightVisionComponent_C");
		return pStaticClass;
	}

};


}

