#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffect.GetParentCharacter
struct UAnimNotifyState_TimedNiagaraEffect_GetParentCharacter_Params
{
	class USkeletalMeshComponent* MeshComp; // (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
	class ACharacter* ReturnValue; // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

