#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Enums
//---------------------By XThrlen---------------------------

// Enum AutoRobot.EAutoRunTestFlag
enum class EAutoRunTestFlag : uint8_t
{
	Game4Win = 0,
	PVEBattleTest = 1,
	EAutoRunTestFlag_MAX = 2
};



//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// ScriptStruct AutoRobot.BulletImpactAutoTestData
// 0x001C
struct FBulletImpactAutoTestData
{
	unsigned char UnknownData00[0x1C]; // 0x0000(0x001C) MISSED OFFSET
};

}

