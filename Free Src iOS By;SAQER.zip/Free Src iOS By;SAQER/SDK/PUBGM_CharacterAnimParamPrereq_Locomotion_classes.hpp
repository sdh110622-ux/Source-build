#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass CharacterAnimParamPrereq_Locomotion.CharacterAnimParamPrereq_Locomotion_C
// 0x0000 (0x0040 - 0x0040)
class UCharacterAnimParamPrereq_Locomotion_C : public UAnimParamPrerequisiteListAsset
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass CharacterAnimParamPrereq_Locomotion.CharacterAnimParamPrereq_Locomotion_C");
		return pStaticClass;
	}

};


}

