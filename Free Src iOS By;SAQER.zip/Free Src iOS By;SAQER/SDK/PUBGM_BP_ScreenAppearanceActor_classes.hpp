#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass BP_ScreenAppearanceActor.BP_ScreenAppearanceActor_C
// 0x0000 (0x0590 - 0x0590)
class ABP_ScreenAppearanceActor_C : public AScreenAppearanceActor
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_ScreenAppearanceActor.BP_ScreenAppearanceActor_C");
		return pStaticClass;
	}

};


}

