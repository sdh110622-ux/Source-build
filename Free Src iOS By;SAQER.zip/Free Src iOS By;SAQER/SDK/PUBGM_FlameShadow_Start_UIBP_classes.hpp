#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// WidgetBlueprintGeneratedClass FlameShadow_Start_UIBP.FlameShadow_Start_UIBP_C
// 0x0000 (0x0260 - 0x0260)
class UFlameShadow_Start_UIBP_C : public UUserWidget
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("WidgetBlueprintGeneratedClass FlameShadow_Start_UIBP.FlameShadow_Start_UIBP_C");
		return pStaticClass;
	}

};


}

