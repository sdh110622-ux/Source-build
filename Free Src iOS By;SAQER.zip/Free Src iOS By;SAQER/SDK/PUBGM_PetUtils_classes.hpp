#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass PetUtils.PetUtils_C
// 0x0000 (0x0028 - 0x0028)
class UPetUtils_C : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass PetUtils.PetUtils_C");
		return pStaticClass;
	}


	static void GetPetLevelCfg(const struct FGameModePlayerPetInfo& PetInfo, class UObject* __WorldContext, struct FBP_STRUCT_PetLevelTable_type* Out_Row);
};


}

