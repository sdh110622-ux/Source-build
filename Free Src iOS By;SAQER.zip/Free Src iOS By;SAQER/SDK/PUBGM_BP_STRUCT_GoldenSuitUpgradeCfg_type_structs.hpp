#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// UserDefinedStruct BP_STRUCT_GoldenSuitUpgradeCfg_type.BP_STRUCT_GoldenSuitUpgradeCfg_type
// 0x0100
struct FBP_STRUCT_GoldenSuitUpgradeCfg_type
{
	int ItemID_1_5225E200346E8D367C280D560FD79094; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int MatID1_2_5084D30079DBD5AC313F49840FE5BC31; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int MatID2_3_5085D34079DBD5AD313F49870FE5BC32; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int MatNum1_4_578CDBC01380C24B652ADED20E5C50F1; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int MatNum2_5_578DDC001380C24C652ADED30E5C50F2; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int RelicID_6_150E7A00068CC8307BE8D3540571E324; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ShareID_7_75B17B000B6C0C2C355BC5F3043B9D24; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Star_8_29E461804C1B742032A6D59E014F77B2; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SubTabID1_9_36DB1AC0425C037B6E9E66A704B39A11; // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SubTabID2_10_36DC1B00425C037C6E9E66A404B39A12; // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString TabDesc1_29_052B6CC048F00D457ACB808F0A5B8611; // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString TabDesc2_30_052C6D0048F00D467ACB808C0A5B8612; // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int TabID_13_525124005E64272E33CB10A404F7A5C4; // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Index_14_227DD9004E4E21643303CB8C04E399D8; // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Period_15_740773C01B84CFB37A7BD5940FB1BF14; // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Effect1_18_3B80BA803C4E871C2C820DDF061FAE91; // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Effect2_19_3B81BAC03C4E871D2C820DDE061FAE92; // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ActID_20_462E64402FAE4FE73AB506F604EA7BC4; // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int NeedJump_21_752D41001982E8C86E0638E2068A55D0; // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SecondMatCount_23_60D7DCC00387AD2F7C1126460E3D6424; // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SecondMatID_24_7D683DC021B04F9110425B600087E384; // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int LimitMatID1_25_2C5BD2C0468114A35B7D71330DC7BC61; // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int LimitMatID2_26_2C5CD300468114A45B7D71340DC7BC62; // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Effect3_31_3B82BB003C4E871E2C820DDD061FAE93; // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SubTabID3_32_36DD1B40425C037D6E9E66A504B39A13; // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x007C(0x0004) MISSED OFFSET
	struct FString TabDesc3_33_052D6D4048F00D477ACB808D0A5B8613; // 0x0080(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int PoseID_34_366CC4002CBF058036DAC0B40FCBA894; // 0x0090(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SecondMatCount2_35_196789402AD904495D3834C503D64292; // 0x0094(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SecondMatID2_36_31D76A40533F25A11C1E586A087E3872; // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Effect4_37_3B83BB403C4E871F2C820DDC061FAE94; // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Effect5_38_3B84BB803C4E87202C820DDB061FAE95; // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SubTabID4_39_36DE1B80425C037E6E9E66AA04B39A14; // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SubTabID5_40_36DF1BC0425C037F6E9E66AB04B39A15; // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x00AC(0x0004) MISSED OFFSET
	struct FString TabDesc4_41_052E6D8048F00D487ACB80F20A5B8614; // 0x00B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString TabDesc5_42_052F6DC048F00D497ACB80F30A5B8615; // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int BranchId_44_4008D9C0159B0E3356FF21EB0555D2B4; // 0x00D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ActiveID1_51_16D1A1807421E3E8739CBF570A187701; // 0x00D4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ActiveID2_52_16D2A1C07421E3E9739CBF480A187702; // 0x00D8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ActiveNum1_53_675A6A4062BFB4E163E6A9B50188FDA1; // 0x00DC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ActiveNum2_54_675B6A8062BFB4E263E6A9B40188FDA2; // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int BackID1_55_0E8EC6C078275A9B0D10180C05AAE991; // 0x00E4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int BackID2_56_0E8FC70078275A9C0D10180D05AAE992; // 0x00E8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x4]; // 0x00EC(0x0004) MISSED OFFSET
	struct FString UpgradeSuccessIcon_57_1865258058871ED65E1AAEC109169AFE; // 0x00F0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

