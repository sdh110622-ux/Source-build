#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function LobbyAvatarFunctionLibrary.LobbyAvatarFunctionLibrary_C.OnPlayerRotate
struct ULobbyAvatarFunctionLibrary_C_OnPlayerRotate_Params
{
	class UCharacterAvatarComp2_BP_C* AvatarComp; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	class UObject* __WorldContext; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

