#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// UserDefinedStruct BP_STRUCT_IPCountry_type.BP_STRUCT_IPCountry_type
// 0x0018
struct FBP_STRUCT_IPCountry_type
{
	int IPRegion_0_68A5480076FE2CFA55C1C9A40B61AD5E; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	struct FString regionCountry_1_6A0CC6C04051CAD136B96925003938A9; // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

