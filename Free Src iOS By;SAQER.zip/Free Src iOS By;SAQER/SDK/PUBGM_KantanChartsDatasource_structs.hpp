#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// 0x0008
struct FKantanCartesianDatapoint
{
	struct FVector2D Coords; // 0x0000(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
};

}

