#pragma once

// PUBG MOBILE (4.6.0 -- 64bit Beta) SDK Generate By @TOPICAL_SRC
// Telegram Channel:- @TOPICAL_SRC
// Generate on Wed Sep 16 08:07:18 2026
 
namespace SDK
{
//---------------------❣︎➪ 𝗡𝗔𝗥𝗨𝗧𝗢 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥༆✈︎🇮🇳---------------------------
//Classes
//---------------------❣︎➪ 𝗡𝗔𝗥𝗨𝗧𝗢 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥༆✈︎🇮🇳---------------------------

// Class CommonUIWidget.CommonInputBox
// 0x0000 (0x02C8 - 0x02C8)
class UCommonInputBox : public ULuaUserWidget
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class CommonUIWidget.CommonInputBox");
		return pStaticClass;
	}

};


// Class CommonUIWidget.CommonPopupBox
// 0x0000 (0x02C8 - 0x02C8)
class UCommonPopupBox : public ULuaUserWidget
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class CommonUIWidget.CommonPopupBox");
		return pStaticClass;
	}

};


// Class CommonUIWidget.CommonSearchBox
// 0x0000 (0x02C8 - 0x02C8)
class UCommonSearchBox : public ULuaUserWidget
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class CommonUIWidget.CommonSearchBox");
		return pStaticClass;
	}

};


}

