#pragma once

// WE SUPPORT FUN  (4.6.0) SDKGen by @O_N_E_B_I_E_C_E | @onebiecerr 
// Send Message Me For SDKGen Tool  
// Generate on Tue Sep  8 20:35:53 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_AvatarDefaultConfig_type.BP_STRUCT_AvatarDefaultConfig_type
// 0x0048
struct FBP_STRUCT_AvatarDefaultConfig_type
{
	int                                                id_0_582DD74020EEE8C12D00E1A40C84B664;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     pant_1_00F930C0654EFFCD6B08CAF404B7FCD4;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     shirt_2_53D54E8062374FD817805CCA0B7038D4;                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     shoe_3_12522FC065073BE56B0E507104B703D5;                  // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        IngoreSlots_a_4_7117F240470C88771F536A8F0FB09CB1;         // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

