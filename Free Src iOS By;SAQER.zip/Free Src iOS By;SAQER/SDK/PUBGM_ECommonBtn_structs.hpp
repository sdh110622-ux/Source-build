#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Enums
//---------------------By XThrlen---------------------------

// UserDefinedEnum ECommonBtn.ECommonBtn
enum class ECommonBtn : uint8_t
{
	ECommonBtn__NewEnumerator1 = 0,
	ECommonBtn__NewEnumerator0 = 1,
	ECommonBtn__NewEnumerator2 = 2,
	ECommonBtn__NewEnumerator3 = 3,
	ECommonBtn__ECommonBtn_MAX = 4
};



}

