#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function SettingConfig.SettingConfig_C.ConditionSetFireGyroData
struct USettingConfig_C_ConditionSetFireGyroData_Params
{
};

// Function SettingConfig.SettingConfig_C.Init
struct USettingConfig_C_Init_Params
{
};

}

