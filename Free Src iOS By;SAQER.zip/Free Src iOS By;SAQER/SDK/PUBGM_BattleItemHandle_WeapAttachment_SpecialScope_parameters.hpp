#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function BattleItemHandle_WeapAttachment_SpecialScope.BattleItemHandle_WeapAttachment_SpecialScope_C.GetFov
struct UBattleItemHandle_WeapAttachment_SpecialScope_C_GetFov_Params
{
	float FOV; // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

}

