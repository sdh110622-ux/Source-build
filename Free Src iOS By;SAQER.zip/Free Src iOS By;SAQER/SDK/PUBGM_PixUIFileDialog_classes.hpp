#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// Class PixUIFileDialog.PxFileDialogMgr
// 0x0000 (0x0028 - 0x0028)
class UPxFileDialogMgr : public UObject
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class PixUIFileDialog.PxFileDialogMgr");
		return pStaticClass;
	}

};


}

