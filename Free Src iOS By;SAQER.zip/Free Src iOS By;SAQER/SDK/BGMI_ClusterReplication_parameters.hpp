#pragma once

// PUBG MOBILE (4.6.0 -- 64bit Beta) SDK Generate By @TOPICAL_SRC
// Telegram Channel:- @TOPICAL_SRC
// Generate on Wed Sep 16 08:07:17 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------❣︎➪ 𝗡𝗔𝗥𝗨𝗧𝗢 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥༆✈︎🇮🇳---------------------------
//Parameters
//---------------------❣︎➪ 𝗡𝗔𝗥𝗨𝗧𝗢 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥༆✈︎🇮🇳---------------------------

// Function ClusterReplication.ClusterReplicationSubsystem.SetAutoClearCache
struct UClusterReplicationSubsystem_SetAutoClearCache_Params
{
	bool                                               Val;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClusterReplication.ClusterReplicationSubsystem.SetAutoCache
struct UClusterReplicationSubsystem_SetAutoCache_Params
{
	bool                                               Val;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClusterReplication.ClusterReplicationSubsystem.RemoveAllCachedObjectData
struct UClusterReplicationSubsystem_RemoveAllCachedObjectData_Params
{
};

}

