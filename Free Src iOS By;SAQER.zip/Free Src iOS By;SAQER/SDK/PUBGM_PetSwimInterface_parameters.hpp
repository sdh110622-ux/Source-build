#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

#include "PUBGM_SRCHUB.hpp"

namespace SDK
{
//---------------------By XThrlen---------------------------
//Parameters
//---------------------By XThrlen---------------------------

// Function PetSwimInterface.PetSwimInterface_C.ISetLeaveSwimMode
struct UPetSwimInterface_C_ISetLeaveSwimMode_Params
{
};

// Function PetSwimInterface.PetSwimInterface_C.ISetEnterSwimMode
struct UPetSwimInterface_C_ISetEnterSwimMode_Params
{
	float WaterSurface; // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

