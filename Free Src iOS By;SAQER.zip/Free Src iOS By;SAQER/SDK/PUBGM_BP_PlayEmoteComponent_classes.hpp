#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Classes
//---------------------By XThrlen---------------------------

// BlueprintGeneratedClass BP_PlayEmoteComponent.BP_PlayEmoteComponent_C
// 0x0000 (0x0630 - 0x0630)
class UBP_PlayEmoteComponent_C : public UPlayEmoteComponent
{
public:

	static UClass* StaticClass() {
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_PlayEmoteComponent.BP_PlayEmoteComponent_C");
		return pStaticClass;
	}

};


}

