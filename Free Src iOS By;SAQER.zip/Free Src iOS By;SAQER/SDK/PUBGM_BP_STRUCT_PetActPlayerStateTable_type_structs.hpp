#pragma once

// PUBGM (4.6.0) x64 SDK BY SRC HUB

namespace SDK
{
//---------------------By XThrlen---------------------------
//Script Structs
//---------------------By XThrlen---------------------------

// UserDefinedStruct BP_STRUCT_PetActPlayerStateTable_type.BP_STRUCT_PetActPlayerStateTable_type
// 0x0018
struct FBP_STRUCT_PetActPlayerStateTable_type
{
	int PetID_0_7B9998C012D880D53C70B12C0D2280B4; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int PetActionID_1_26FA70406D0CF0E967A9660B078EE2C4; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString PetLimiteState_3_107B0EC027578F8F39A3C9B002BE9A85; // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

